# Export ML model results to readable TXT files
setwd("C:/Users/www18/Desktop/溃疡/05.normalize")

# Read
ml_final  <- readRDS("ML_output/ML_final.rds")
ml_results <- readRDS("ML_output/ML_results.rds")
genes <- readRDS("ML_output/LASSO_genes.rds")

# Write ML_final
sink("ML_output/ML_final.txt")
cat("======================================\n")
cat("ML Final Model Results\n")
cat("======================================\n\n")
cat(sprintf("Diagnostic genes (%d): %s\n\n", length(genes), paste(genes, collapse=", ")))

cat("=== External Validation AUC ===\n")
for (nm in sort(names(ml_final$results))) {
  cat(sprintf("  %s: AUC = %.4f\n", nm, ml_final$results[[nm]]$auc))
}
cat("\n=== Model Objects ===\n")
cat(sprintf("  RF model: %s\n", class(ml_final$rf)[1]))
cat(sprintf("  XGB model: %s\n", class(ml_final$xgb)[1]))
cat(sprintf("  RF importance top 10:\n"))
rf_imp <- importance(ml_final$rf)[,"MeanDecreaseGini"]
rf_imp <- sort(rf_imp, decreasing=TRUE)
for (i in 1:min(20, length(rf_imp))) {
  cat(sprintf("    %2d. %s = %.4f\n", i, names(rf_imp)[i], rf_imp[i]))
}
sink()

# Write ML_results
sink("ML_output/ML_results.txt")
cat("======================================\n")
cat("ML Results (Detailed)\n")
cat("======================================\n\n")

if (is.list(ml_results)) {
  for (nm in names(ml_results)) {
    cat(sprintf("\n--- %s ---\n", nm))
    if (is.list(ml_results[[nm]])) {
      for (k in names(ml_results[[nm]])) {
        v <- ml_results[[nm]][[k]]
        if (is.numeric(v) && length(v) <= 20) {
          cat(sprintf("  %s: %s\n", k, paste(round(v, 4), collapse=", ")))
        } else if (length(v) == 1) {
          cat(sprintf("  %s: %s\n", k, as.character(v)))
        } else {
          cat(sprintf("  %s: [%s, length=%d]\n", k, class(v)[1], length(v)))
        }
      }
    } else {
      cat(sprintf("  Value: %s\n", paste(ml_results[[nm]], collapse=", ")))
    }
  }
}
sink()

# Also write pure gene list
writeLines(genes, "ML_output/LASSO_genes.txt")

cat("Done. Files exported:\n")
cat("  ML_output/ML_final.txt\n")
cat("  ML_output/ML_results.txt\n")
cat("  ML_output/LASSO_genes.txt\n")
