# ============================================================
# RUNX1 UC ML 诊断模型 [v2 — Desktop输出 + TXT导出]
# 训练: GSE107597 | 验证1: GSE96698 | 验证2: GSE134025
# 算法: LASSO + RF + XGBoost (双外部验证)
# 输出: 5张图 + RDS + TXT
# ============================================================
rm(list = ls())
setwd("C:\\Users\\www18\\Desktop\\ML_output")

OUT_DIR <- "C:/Users/www18/Desktop/ML_output"
dir.create(OUT_DIR, showWarnings = FALSE)

# ============================================================
# Part 0: 包加载
# ============================================================
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")

core_pkgs <- c("limma","sva","glmnet","randomForest","e1071","xgboost",
               "pROC","dplyr","ggplot2","patchwork","viridis",
               "RColorBrewer","ggrepel","ComplexHeatmap","circlize",
               "rms","ggpubr","Seurat")

for (pkg in core_pkgs) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    if (pkg %in% c("limma","sva","ComplexHeatmap")) {
      BiocManager::install(pkg, update = FALSE, ask = FALSE)
    } else {
      tryCatch(install.packages(pkg, repos = "https://cloud.r-project.org"),
               error = function(e) NULL)
    }
    suppressPackageStartupMessages(library(pkg, character.only = TRUE))
  }
}
cat("=== Part 0 完成 ===\n")

# ============================================================
# Part 1: 加载数据
# ============================================================
cat("\n>>> 加载数据\n")

load_geo <- function(folder_name, geo_id) {
  file_path <- file.path(folder_name, paste0(geo_id, ".normalize.txt"))
  raw  <- read.table(file_path, header=TRUE, sep="\t", check.names=FALSE, row.names=1)
  samp <- gsub(".*_", "", colnames(raw))
  expr <- as.matrix(raw)
  group <- ifelse(samp == "Control", "Control", "UC")
  names(group) <- colnames(raw)
  cat(sprintf("  %s: %d genes x %d samples (Ctrl=%d, UC=%d)\n",
              geo_id, nrow(expr), ncol(expr), sum(group=="Control"), sum(group=="UC")))
  list(expr=expr, group=group)
}

train  <- load_geo("GSE107597", "GSE107597")
valid1 <- load_geo("GSE96698",  "GSE96698")
valid2 <- load_geo("GSE134025", "GSE134025")

# ============================================================
# Part 2: 基因对齐
# ============================================================
cat("\n>>> 基因对齐\n")
common_genes <- Reduce(intersect, list(rownames(train$expr),
                                        rownames(valid1$expr),
                                        rownames(valid2$expr)))
cat(sprintf("共同基因: %d\n", length(common_genes)))

t_expr  <- train$expr[common_genes, ]
t_group <- train$group
v1_expr <- valid1$expr[common_genes, ]
v1_group <- valid1$group
v2_expr <- valid2$expr[common_genes, ]
v2_group <- valid2$group

cat(sprintf("Train : %d genes x %d samples (Ctrl=%d, UC=%d)\n",
            nrow(t_expr), ncol(t_expr), sum(t_group=="Control"), sum(t_group=="UC")))
cat(sprintf("Valid1: %d genes x %d samples (Ctrl=%d, UC=%d)\n",
            nrow(v1_expr), ncol(v1_expr), sum(v1_group=="Control"), sum(v1_group=="UC")))
cat(sprintf("Valid2: %d genes x %d samples (Ctrl=%d, UC=%d)\n",
            nrow(v2_expr), ncol(v2_expr), sum(v2_group=="Control"), sum(v2_group=="UC")))

# ============================================================
# Part 3: DEG + RUNX1 候选基因
# ============================================================
cat("\n>>> DEG\n")
design  <- model.matrix(~ t_group)
fit     <- lmFit(t_expr, design) %>% eBayes()
deg_all <- topTable(fit, coef=2, number=Inf)
deg_sig <- deg_all[deg_all$adj.P.Val < 0.05 & abs(deg_all$logFC) > 0.5, ]
cat(sprintf("DEG: %d sig (Up=%d, Down=%d)\n", nrow(deg_sig),
            sum(deg_sig$logFC>0), sum(deg_sig$logFC<0)))

# ============================================================
# ============================================================
# 保存DEG结果 (TXT)
# ============================================================
deg_out <- deg_all
deg_out$Gene <- rownames(deg_out)
deg_out <- deg_out[, c("Gene","logFC","AveExpr","t","P.Value","adj.P.Val","B")]
write.table(deg_out, file.path(OUT_DIR, "DEG_results.txt"),
            sep="\t", quote=FALSE, row.names=FALSE)
saveRDS(deg_out, file.path(OUT_DIR, "DEG_results.rds"))
cat(sprintf("DEG结果已保存: %s\n", file.path(OUT_DIR, "DEG_results.txt")))
# ============================================================
# ============================================================

runx1_set <- c("RUNX1","GZMK","HINT1","ZCCHC10","C11orf73","YY1",
               "SKIL","HMGN1","FGD3","CEBPB","MRPS36")
runx1_ext <- unique(c(runx1_set,
  "TGFB1","SMAD3","ACTA2","TAGLN","COL1A1","COL1A2","COL3A1","FN1",
  "MMP1","MMP3","MKI67","TOP2A","PCNA","CCNB1","IL1B","IL6","CXCL8",
  "TNF","NFKB1","STAT3","SPP1","VEGFA","PDGFA","SERPINE1","CTGF",
  "LOX","TIMP1","CDKN1A","CCL2","CXCL1","ITGB2","CD44","ICAM1"))

cand <- intersect(unique(c(runx1_ext, rownames(deg_sig)[1:500])), common_genes)
cand_sig <- deg_all[intersect(cand, rownames(deg_all)), ]
cand_sig <- cand_sig[cand_sig$adj.P.Val < 0.05, ]
cand_sig <- cand_sig[order(abs(cand_sig$logFC), decreasing=TRUE), ]
cat(sprintf("候选基因: %d sig\n", nrow(cand_sig)))

# ============================================================
# Part 4: LASSO
# ============================================================
cat("\n>>> LASSO\n")
x_lasso <- t(t_expr[head(rownames(cand_sig), 300), ])
y_lasso <- ifelse(t_group == "UC", 1, 0)

set.seed(42)
cv_fit <- cv.glmnet(x_lasso, y_lasso, family="binomial", alpha=1, nfolds=10)

pdf(file.path(OUT_DIR, "M0_LASSO_CV.pdf"), width=7, height=5)
plot(cv_fit); title("LASSO Cross-Validation"); dev.off()

coefs <- coef(cv_fit, s="lambda.min")
lasso_genes <- setdiff(rownames(coefs)[which(coefs[,1]!=0)], "(Intercept)")
if(!"RUNX1" %in% lasso_genes) lasso_genes <- unique(c("RUNX1", lasso_genes))
lasso_genes <- intersect(lasso_genes, common_genes)
cat(sprintf("LASSO genes: %d\n", length(lasso_genes)))
cat(paste(lasso_genes, collapse=", "), "\n")

lasso_genes <- as.character(lasso_genes)
if(!"RUNX1" %in% lasso_genes) lasso_genes <- c("RUNX1", lasso_genes)
lasso_genes <- intersect(lasso_genes, rownames(t_expr))
cat(sprintf("FINAL genes (with RUNX1): %d\n", length(lasso_genes)))
cat(paste(lasso_genes, collapse=", "), "\n")

# ============================================================
# ============================================================
# 保存LASSO基因 (TXT + RDS)
# ============================================================
writeLines(lasso_genes, file.path(OUT_DIR, "LASSO_genes.txt"))
saveRDS(lasso_genes, file.path(OUT_DIR, "LASSO_genes.rds"))
# ============================================================
# ============================================================

# ============================================================
# Part 5: ML 建模 — 双验证集
# ============================================================
cat("\n>>> ML 建模\n")

x_tr <- t(t_expr[lasso_genes, ])
x_v1 <- t(v1_expr[lasso_genes, ])
x_v2 <- t(v2_expr[lasso_genes, ])
y_tr <- ifelse(t_group=="UC", 1, 0)
y_v1 <- ifelse(v1_group=="UC", 1, 0)
y_v2 <- ifelse(v2_group=="UC", 1, 0)

cat(sprintf("Train: %dx%d  V1: %dx%d  V2: %dx%d\n",
            nrow(x_tr),ncol(x_tr), nrow(x_v1),ncol(x_v1), nrow(x_v2),ncol(x_v2)))

results <- list()

# RF
set.seed(42)
rf <- randomForest(x=x_tr, y=as.factor(y_tr), ntree=500)
for(nm in c("V1","V2")) {
  xv <- if(nm=="V1") x_v1 else x_v2; yv <- if(nm=="V1") y_v1 else y_v2
  pr <- predict(rf, xv, type="prob")[,2]
  rc <- roc(yv, pr, quiet=TRUE)
  results[[paste0("RF_",nm)]] <- list(auc=rc$auc, roc=rc)
  cat(sprintf("  RF   %s AUC=%.3f\n", nm, rc$auc))
}

# XGBoost
set.seed(42)
dtrain <- xgb.DMatrix(x_tr, label=y_tr)
xgb <- xgb.train(params=list(objective="binary:logistic", max_depth=3, eta=0.1, nthread=4),
                  data=dtrain, nrounds=100, verbose=0)
for(nm in c("V1","V2")) {
  xv <- if(nm=="V1") x_v1 else x_v2; yv <- if(nm=="V1") y_v1 else y_v2
  dv <- xgb.DMatrix(xv, label=yv)
  pr <- predict(xgb, dv)
  rc <- roc(yv, pr, quiet=TRUE)
  results[[paste0("XGB_",nm)]] <- list(auc=rc$auc, roc=rc)
  cat(sprintf("  XGB  %s AUC=%.3f\n", nm, rc$auc))
}

# ============================================================
# ============================================================
# 保存 ML 结果 (TXT + RDS)
# ============================================================

# --- ML_final.rds + ML_final.txt ---
saveRDS(list(results=results, genes=lasso_genes, rf=rf, xgb=xgb),
        file.path(OUT_DIR, "ML_final.rds"))

con <- file(file.path(OUT_DIR, "ML_final.txt"), open="w", encoding="UTF-8")
cat("ML Final Model Results\n", file=con)
cat("=======================\n\n", file=con)
cat(sprintf("Diagnostic genes (%d): %s\n\n", length(lasso_genes),
            paste(lasso_genes, collapse=", ")), file=con)
cat("External Validation AUC:\n", file=con)
for (nm in sort(names(results))) {
  cat(sprintf("  %s: AUC = %.4f\n", nm, results[[nm]]$auc), file=con)
}
cat("\nRF Feature Importance:\n", file=con)
rf_imp <- importance(rf)[,"MeanDecreaseGini"]
rf_imp <- sort(rf_imp, decreasing=TRUE)
for (i in seq_along(rf_imp)) {
  cat(sprintf("  %2d. %-15s = %.4f\n", i, names(rf_imp)[i], rf_imp[i]), file=con)
}
close(con)

# --- ML_results.rds + ML_results.txt ---
saveRDS(results, file.path(OUT_DIR, "ML_results.rds"))

con <- file(file.path(OUT_DIR, "ML_results.txt"), open="w", encoding="UTF-8")
cat("ML Results (Detailed AUC)\n", file=con)
cat("=========================\n\n", file=con)
for (nm in names(results)) {
  cat(sprintf("%s: AUC = %.4f\n", nm, results[[nm]]$auc), file=con)
}
close(con)

cat("ML结果TXT+RDS已保存到", OUT_DIR, "\n")
# ============================================================
# ============================================================

# ============================================================
# Part 6: Fig M1 — ROC + 特征重要性
# ============================================================
cat("\n>>> Fig M1\n")

roc_df <- do.call(rbind, lapply(names(results), function(nm) {
  r <- results[[nm]]$roc
  a <- results[[nm]]$auc
  data.frame(fpr=1-r$specificities, tpr=r$sensitivities,
             label=paste0(sub("_.*","",nm)," (",sub(".*_","",nm)," AUC=",round(a,3),")"),
             stringsAsFactors=FALSE)
}))

# 动态颜色映射
auc_labels <- unique(roc_df$label)
auc_colors <- setNames(
  colorRampPalette(c("#4DBBD5","#00A087","#E64B35","#F39B7F"))(length(auc_labels)),
  auc_labels)

p1a <- ggplot(roc_df, aes(fpr, tpr, color=label)) +
  geom_line(linewidth=1) + geom_abline(slope=1, lty="dashed", color="grey50") +
  scale_color_manual(values=auc_colors) +
  labs(title="Fig M1A: ROC — Dual External Validation", x="1-Specificity", y="Sensitivity") +
  theme_bw(11) + theme(plot.title=element_text(face="bold"), legend.position=c(0.7,0.25))

rf_imp <- importance(rf)[,"MeanDecreaseGini"]
rf_imp <- rf_imp[!is.na(names(rf_imp)) & nchar(names(rf_imp))>0]
rf_imp <- sort(rf_imp, decreasing=TRUE)
top_n  <- min(20, length(rf_imp))
imp_df <- data.frame(
  Gene = factor(names(rf_imp)[1:top_n], levels=rev(names(rf_imp)[1:top_n])),
  Importance = rf_imp[1:top_n])
imp_df$fill <- ifelse(imp_df$Gene=="RUNX1", "#E64B35", "#4DBBD5")

p1b <- ggplot(imp_df, aes(Gene, Importance)) +
  geom_bar(stat="identity", fill=imp_df$fill) + coord_flip() +
  labs(title="Fig M1B: RF Feature Importance", x="", y="MeanDecreaseGini") + theme_bw(10)

ggsave(file.path(OUT_DIR, "Fig_M1_ROC_Importance.pdf"), p1a|p1b, width=16, height=7)

# ============================================================
# Part 7: Fig M2 — Nomogram + Calibration
# ============================================================
cat(">>> Fig M2\n")

nom_genes <- head(intersect(names(rf_imp), rownames(t_expr)), 5)
if(!"RUNX1" %in% nom_genes && "RUNX1" %in% rownames(t_expr))
  nom_genes <- unique(c("RUNX1", nom_genes))[1:6]

x_nom <- as.data.frame(t(t_expr[nom_genes,,drop=FALSE]))
x_nom$UC <- y_tr
dd <<- datadist(x_nom); options(datadist="dd")
nom_mod <- lrm(UC ~ ., data=x_nom, x=TRUE, y=TRUE)

pdf(file.path(OUT_DIR, "Fig_M2_Nomogram_Calibration.pdf"), width=12, height=5)
par(mfrow=c(1,2))
plot(nomogram(nom_mod, fun=function(x)1/(1+exp(-x)),
              fun.at=c(0.1,0.3,0.5,0.7,0.9), lp=FALSE), xfrac=0.35)
plot(calibrate(nom_mod, method="boot", B=500),
     xlab="Predicted", ylab="Observed", main="Calibration (B=500)", subtitles=FALSE)
dev.off()

# ============================================================
# Part 8: Fig M3 — scRNA 单细胞验证
# ============================================================
cat(">>> Fig M3: scRNA\n")

sc <- tryCatch({
  load("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析/Seurat.Rdata")
  obj <- get(ls()[sapply(ls(), function(x) inherits(get(x),"Seurat"))][1])
  ann <- read.table("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析/04.cellAnn.txt",
                    header=TRUE, row.names=1, sep="\t")
  obj$celltype <- ann[colnames(obj), "labels"]
  Idents(obj) <- "celltype"; DefaultAssay(obj) <- "RNA"
  obj
}, error=function(e) NULL)

if(!is.null(sc)) {
  dg <- intersect(lasso_genes, rownames(sc))
  cat(sprintf("scRNA genes: %d/%d\n", length(dg), length(lasso_genes)))
  if(length(dg) >= 3) {
    p3a <- DotPlot(sc, features=dg, group.by="celltype") + RotatedAxis() +
      labs(title="Fig M3A: Diagnostic Genes by Cell Type") + theme_bw()
    p3b <- VlnPlot(sc, features="RUNX1", group.by="celltype", pt.size=0) +
      labs(title="Fig M3B: RUNX1 Expression") + theme_bw() +
      theme(axis.text.x=element_text(angle=30, hjust=1))
    ggsave(file.path(OUT_DIR, "Fig_M3_scRNA_Validation.pdf"), p3a/p3b, width=14, height=10)
  }
}

# ============================================================
# Part 9: Fig M4 — 诊断基因热图
# ============================================================
cat(">>> Fig M4\n")

dg <- intersect(lasso_genes, common_genes)
all_expr <- cbind(t_expr[dg,,drop=FALSE], v1_expr[dg,,drop=FALSE], v2_expr[dg,,drop=FALSE])
all_grp  <- c(t_group, v1_group, v2_group)
all_coh  <- c(rep("Train", ncol(t_expr)), rep("Valid1", ncol(v1_expr)), rep("Valid2", ncol(v2_expr)))

z <- t(scale(t(all_expr))); z[z>2]<-2; z[z< -2]<- -2

ha <- HeatmapAnnotation(
  Group=all_grp, Cohort=all_coh,
  col=list(Group=c("Control"="#4DBBD5","UC"="#E64B35"),
           Cohort=c("Train"="grey95","Valid1"="grey70","Valid2"="grey40")),
  show_annotation_name=TRUE)

pdf(file.path(OUT_DIR, "Fig_M4_Diagnostic_Heatmap.pdf"), width=16, height=8)
draw(Heatmap(z, name="Z-score",
        col=colorRamp2(c(-2,0,2), c("#3C5488","white","#E64B35")),
        top_annotation=ha, show_column_names=FALSE,
        row_names_gp=gpar(fontsize=9),
        cluster_columns=TRUE, cluster_rows=TRUE,
        column_title="Fig M4: Diagnostic Gene Expression (Train + Dual Validation)",
        column_title_gp=gpar(fontsize=12, fontface="bold"),
        column_split=all_coh,
        heatmap_legend_param=list(direction="horizontal", title_position="topcenter")))
dev.off()

# ============================================================
# Part 10: 汇总
# ============================================================
cat("\n========================================================\n")
cat("  RUNX1 ML 诊断模型 — 全部完成\n")
cat("========================================================\n")
cat(sprintf("输出目录: %s\n", OUT_DIR))
cat("  M0_LASSO_CV.pdf              LASSO交叉验证\n")
cat("  Fig_M1_ROC_Importance.pdf    ROC + 特征重要性\n")
cat("  Fig_M2_Nomogram_Calibration.pdf  Nomogram\n")
cat("  Fig_M3_scRNA_Validation.pdf  单细胞基因验证\n")
cat("  Fig_M4_Diagnostic_Heatmap.pdf  诊断热图\n")
cat("  DEG_results.rds / DEG_results.txt         DEG结果\n")
cat("  LASSO_genes.rds / LASSO_genes.txt         LASSO基因\n")
cat("  ML_final.rds / ML_final.txt               最终模型\n")
cat("  ML_results.rds / ML_results.txt           详细AUC\n\n")

cat("=== 外部验证 AUC ===\n")
for(nm in sort(names(results)))
  cat(sprintf("  %s: %.3f\n", nm, results[[nm]]$auc))

cat(sprintf("\n诊断基因 (%d): %s\n", length(lasso_genes),
            paste(lasso_genes, collapse=", ")))
cat(sprintf("RUNX1 RF重要性排名: %d/%d\n",
            which(names(rf_imp)=="RUNX1"), length(rf_imp)))
cat("========================================================\n")
