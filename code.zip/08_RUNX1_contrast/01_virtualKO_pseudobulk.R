# ============================================================
# RUNX1 虚拟敲除 — Pseudobulk (单细胞聚合)
# 11个样本 → RUNX1连续表达 → limma DEG → CHD风格图
# ============================================================
rm(list = ls())
setwd("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析")

# ============================================================
# Part 0: 包
# ============================================================
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")
pkgs <- c("limma","dplyr","ggplot2","patchwork","viridis","ggrepel",
          "clusterProfiler","org.Hs.eg.db","ReactomePA","enrichplot",
          "ComplexHeatmap","circlize","RColorBrewer","Seurat")
for (pkg in pkgs) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    if (pkg %in% c("limma","clusterProfiler","org.Hs.eg.db","ReactomePA","enrichplot","ComplexHeatmap")) {
      BiocManager::install(pkg, update = FALSE, ask = FALSE)
    } else {
      tryCatch(install.packages(pkg, repos = "https://cloud.r-project.org"),
               error = function(e) NULL)
    }
    suppressPackageStartupMessages(library(pkg, character.only = TRUE))
  }
}
dir.create("VirtualKO_output", showWarnings = FALSE)
cat("=== Part 0 ===\n")

# ============================================================
# Part 1: 构建 Pseudobulk
# ============================================================
cat("\n>>> Pseudobulk\n")

loaded_obj <- load("Seurat.Rdata")
scRNA <- get(loaded_obj[1])

cell_ann <- read.table("04.cellAnn.txt", header = TRUE, row.names = 1, sep = "\t")
scRNA$celltype <- cell_ann[colnames(scRNA), "labels"]
DefaultAssay(scRNA) <- "RNA"

# 提取成纤维细胞
sc_fib <- subset(scRNA, subset = celltype == "Fibroblasts")
cat(sprintf("成纤维: %d cells\n", ncol(sc_fib)))

# Pseudobulk: 每个样本聚合
counts <- GetAssayData(sc_fib, assay = "RNA", layer = "counts")
samples <- sc_fib$orig.ident
sample_list <- unique(samples)

pseudo_list <- list()
for (s in sample_list) {
  cells_s <- colnames(sc_fib)[samples == s]
  if (length(cells_s) > 10) {
    pseudo_list[[s]] <- rowSums(counts[, cells_s, drop = FALSE])
  }
}
pseudo_mat <- do.call(cbind, pseudo_list)
cat(sprintf("Pseudobulk: %d genes × %d samples\n", nrow(pseudo_mat), ncol(pseudo_mat)))

# 标准化 (CPM)
lib_sizes <- colSums(pseudo_mat)
pseudo_cpm <- t(t(pseudo_mat) / lib_sizes * 1e6)
pseudo_log <- log2(pseudo_cpm + 1)

# 过滤低表达基因
gene_means <- rowMeans(pseudo_log)
pseudo_log <- pseudo_log[gene_means > 1, ]
cat(sprintf("过滤后: %d genes\n", nrow(pseudo_log)))

# ============================================================
# Part 2: RUNX1 高低分组 → limma
# ============================================================
cat("\n>>> RUNX1 虚拟KO\n")

runx1 <- pseudo_log["RUNX1", ]
cat(sprintf("RUNX1: [%.2f, %.2f], median=%.2f\n",
            min(runx1), max(runx1), median(runx1)))

med <- median(runx1)
hi  <- names(runx1)[runx1 >= med]
lo  <- names(runx1)[runx1 < med]
cat(sprintf("High: %d  Low: %d\n", length(hi), length(lo)))

# limma
group_vec <- rep("Hi", ncol(pseudo_log))
names(group_vec) <- colnames(pseudo_log)
group_vec[lo] <- "Lo"
group_vec <- factor(group_vec, levels = c("Lo", "Hi"))

design <- model.matrix(~ group_vec)
fit    <- lmFit(pseudo_log, design) %>% eBayes()
deg    <- topTable(fit, coef = 2, number = Inf)

deg$sig <- "NS"
deg$sig[deg$adj.P.Val < 0.05 & deg$logFC > 0.25]  <- "Up"
deg$sig[deg$adj.P.Val < 0.05 & deg$logFC < -0.25] <- "Down"

# 排除 RUNX1 自身
deg_ko <- deg[rownames(deg) != "RUNX1", ]
sig_ko <- deg_ko[deg_ko$sig != "NS", ]

cat(sprintf("RUNX1 FC=%.3f  P=%.2e\n", deg["RUNX1","logFC"], deg["RUNX1","adj.P.Val"]))
cat(sprintf("扰动基因: %d (↑%d, ↓%d)\n",
            nrow(sig_ko), sum(sig_ko$sig=="Up"), sum(sig_ko$sig=="Down")))

if (nrow(sig_ko) == 0) {
  # 放宽阈值看有没有差异
  sig_loose <- deg_ko[deg_ko$adj.P.Val < 0.2 & abs(deg_ko$logFC) > 0.1, ]
  cat(sprintf("放宽阈值: %d genes (P<0.2, |FC|>0.1)\n", nrow(sig_loose)))
  if (nrow(sig_loose) > 0) sig_ko <- sig_loose
}

# ============================================================
# Part 3: Fig VK1 — 4面板 (CHD Fig 8 风格)
# ============================================================
cat(">>> Fig VK1\n")

n_sig <- nrow(sig_ko)
n_all <- nrow(deg_ko)
prop_df <- data.frame(
  Category = c("Non-significant", "Significant"),
  Count = c(n_all - n_sig, n_sig),
  Pct = c((n_all-n_sig)/n_all*100, n_sig/n_all*100))

p_a <- ggplot(prop_df, aes(x = "", y = Count, fill = Category)) +
  geom_bar(stat = "identity", width = 1) + coord_polar("y", start = 0) +
  scale_fill_manual(values = c("Significant" = "#E64B35", "Non-significant" = "grey85")) +
  labs(title = "Perturbed Genes",
       subtitle = paste0("Sig: ", n_sig, "/", n_all, " (", round(n_sig/n_all*100, 1), "%)")) +
  theme_void() + theme(plot.title = element_text(size = 11, face = "bold", hjust = 0.5),
                        plot.subtitle = element_text(size = 9, hjust = 0.5),
                        legend.position = "bottom")

# Volcano
known <- c("CEBPB","YY1","SKIL","GZMK","FGD3","HINT1",
           "COL1A1","COL1A2","COL3A1","FN1","TGFB1","SMAD3",
           "ACTA2","TAGLN","SERPINE1","CTGF","SPP1","MMP1","MMP3",
           "MKI67","TOP2A","PCNA","TIMP1","IL6","CXCL8","NFKB1","STAT3")
deg_ko$logP  <- -log10(deg_ko$adj.P.Val)
deg_ko$logP[is.infinite(deg_ko$logP)] <- max(deg_ko$logP[is.finite(deg_ko$logP)])
deg_ko$label <- ifelse(rownames(deg_ko) %in% known & deg_ko$sig != "NS",
                         rownames(deg_ko), "")

p_b <- ggplot(deg_ko, aes(x = logFC, y = logP)) +
  geom_point(aes(color = sig), size = 0.7, alpha = 0.6) +
  scale_color_manual(values = c("Up" = "#E64B35", "Down" = "#3C5488", "NS" = "grey88")) +
  geom_text_repel(aes(label = label), size = 2.5, max.overlaps = 60,
                   box.padding = 0.2, color = "black", fontface = "italic") +
  geom_vline(xintercept = c(-0.25, 0.25), lty = "dashed", color = "grey50") +
  geom_hline(yintercept = -log10(0.05), lty = "dashed", color = "grey50") +
  labs(title = "Volcano Plot", x = "log2 FC (RUNX1-Hi / RUNX1-Lo)", y = "-log10(adj.P)") +
  theme_bw(9) + theme(legend.position = "none", plot.title = element_text(face = "bold"))

# Top genes
if (nrow(sig_ko) > 0) {
  top_fc <- sig_ko[order(abs(sig_ko$logFC), decreasing = TRUE), ]
  top20  <- head(top_fc, 20)
  top20$Gene <- factor(rownames(top20), levels = rev(rownames(top20)))
  top20$Dir  <- ifelse(top20$logFC > 0, "Up", "Down")

  p_c <- ggplot(top20, aes(x = Gene, y = logFC, fill = Dir)) +
    geom_bar(stat = "identity") + coord_flip() +
    scale_fill_manual(values = c("Up" = "#E64B35", "Down" = "#3C5488")) +
    labs(title = "Top 20 Perturbed Genes", x = "", y = "log2 FC") +
    theme_bw(9) + theme(legend.position = "none", plot.title = element_text(face = "bold"))
} else {
  top_fc <- deg_ko[order(abs(deg_ko$logFC), decreasing = TRUE), ]
  top20  <- head(top_fc, 20)
  top20$Gene <- factor(rownames(top20), levels = rev(rownames(top20)))
  top20$Dir  <- ifelse(top20$logFC > 0, "Up", "Down")
  p_c <- ggplot(top20, aes(x = Gene, y = logFC, fill = Dir)) +
    geom_bar(stat = "identity") + coord_flip() +
    scale_fill_manual(values = c("Up" = "#E64B35", "Down" = "#3C5488")) +
    labs(title = "Top 20 Genes (by |FC|)", x = "", y = "log2 FC") +
    theme_bw(9) + theme(legend.position = "none", plot.title = element_text(face = "bold"))
}

# GO enrichment
all_genes <- rownames(deg_ko)[order(abs(deg_ko$logFC), decreasing = TRUE)]
ego <- tryCatch(
  enrichGO(gene = head(all_genes, 500), OrgDb = org.Hs.eg.db,
           keyType = "SYMBOL", ont = "BP",
           pAdjustMethod = "BH", pvalueCutoff = 0.05, qvalueCutoff = 0.3),
  error = function(e) NULL)

if (!is.null(ego) && nrow(ego) > 0) {
  top_go <- ego@result %>% arrange(p.adjust) %>% head(10)
  p_d <- ggplot(top_go, aes(x = -log10(p.adjust),
                             y = reorder(Description, -log10(p.adjust)),
                             size = Count, fill = -log10(p.adjust))) +
    geom_point(shape = 21) + scale_fill_viridis_c(option = "C", direction = -1) +
    labs(title = "GO BP Enrichment", x = "-log10(adj.P)", y = "") +
    theme_bw(9) + theme(plot.title = element_text(face = "bold"))
} else {
  p_d <- ggplot() + labs(title = "GO: No enrichment") + theme_void()
}

p_vk1 <- p_a + p_b + p_c + p_d +
  plot_layout(ncol = 2, nrow = 2) +
  plot_annotation(
    title = "Fig VK1: RUNX1 In Silico Perturbation (Pseudobulk scRNA-seq)",
    subtitle = paste0("Fibroblast pseudobulk (", ncol(pseudo_log), " samples). ",
                      "RUNX1-Hi (n=", length(hi), ") vs RUNX1-Lo (n=", length(lo), ")"),
    theme = theme(plot.title = element_text(size = 15, face = "bold"),
                  plot.subtitle = element_text(size = 10, color = "grey30")))
ggsave("VirtualKO_output/Fig_VK1_RUNX1_Perturbation_4Panel.pdf", p_vk1, width = 14, height = 12)

# ============================================================
# Part 4: Fig VK2 — Reactome + 通路交叉验证
# ============================================================
cat(">>> Fig VK2\n")

eid <- tryCatch(bitr(head(all_genes, 500), "SYMBOL", "ENTREZID", org.Hs.eg.db)$ENTREZID,
                error = function(e) NULL)

if (!is.null(eid) && length(eid) >= 10) {
  erea <- tryCatch(
    enrichPathway(gene = eid, organism = "human", pAdjustMethod = "BH",
                  pvalueCutoff = 0.05, qvalueCutoff = 0.3, readable = TRUE),
    error = function(e) NULL)

  if (!is.null(erea) && nrow(erea) > 0) {
    top_reac <- erea@result %>% arrange(p.adjust) %>% head(15)
    p_vk2a <- ggplot(top_reac, aes(x = -log10(p.adjust),
                                    y = reorder(Description, -log10(p.adjust)),
                                    size = Count, fill = -log10(p.adjust))) +
      geom_point(shape = 21) + scale_fill_viridis_c(option = "B", direction = -1) +
      labs(title = "Reactome Enrichment", x = "-log10(adj.P)", y = "") +
      theme_bw(10) + theme(plot.title = element_text(face = "bold"))
  } else {
    p_vk2a <- ggplot() + labs(title = "Reactome: No enrichment") + theme_void()
  }
} else {
  p_vk2a <- ggplot() + labs(title = "No Entrez mapping") + theme_void()
}

# 通路交叉验证
pathway_sets <- list(
  "ECM & Fibrosis"       = c("COL1A1","COL1A2","COL3A1","FN1","DCN","LOX",
                               "MMP1","MMP3","TIMP1","CTGF","SERPINE1","ACTA2","TAGLN"),
  "TGFb Signaling"       = c("TGFB1","SMAD3","SKIL","ACTA2","TAGLN","SERPINE1","CTGF"),
  "Cell Cycle"           = c("MKI67","TOP2A","PCNA","CCNB1","CDK1","BIRC5","CENPF"),
  "Inflammatory"         = c("IL1B","IL6","CXCL8","TNF","NFKB1","JUN","STAT3","CCL2","SPP1"),
  "CellChat Ligands"     = c("SPP1","PDGFA","VEGFA","TIMP1","CXCL12","CCL2","FN1"),
  "SCENIC RUNX1 Targets" = c("CEBPB","YY1","SKIL","GZMK","FGD3","HINT1","RUNX1","HMGN1"))

cross_df <- do.call(rbind, lapply(names(pathway_sets), function(pw) {
  hits <- intersect(pathway_sets[[pw]], rownames(deg_ko))
  hit_up <- sum(hits %in% rownames(sig_ko)[sig_ko$sig == "Up"])
  hit_dn <- sum(hits %in% rownames(sig_ko)[sig_ko$sig == "Down"])
  data.frame(Pathway = pw, Perturbed = hit_up + hit_dn,
             Total = length(pathway_sets[[pw]]), Up = hit_up, Down = hit_dn,
             stringsAsFactors = FALSE)
}))
cross_df$Pct   <- round(cross_df$Perturbed / cross_df$Total * 100, 1)
cross_df$Label <- paste0(cross_df$Perturbed, "/", cross_df$Total)

p_vk2b <- ggplot(cross_df, aes(x = reorder(Pathway, Pct), y = Pct)) +
  geom_bar(stat = "identity", fill = "#E64B35", alpha = 0.85, width = 0.65) +
  geom_text(aes(label = Label), hjust = -0.1, size = 4.5, fontface = "bold") +
  coord_flip(ylim = c(0, max(cross_df$Pct) * 1.6)) +
  labs(title = "Pathway Cross-Validation",
       subtitle = "% Genes Perturbed by RUNX1 KO", x = "", y = "% Perturbed") +
  theme_bw(11) + theme(plot.title = element_text(face = "bold"))

p_vk2 <- p_vk2a / p_vk2b +
  plot_annotation(title = "Fig VK2: RUNX1 KO — Reactome + Pathway Validation",
                  theme = theme(plot.title = element_text(size = 14, face = "bold")))
ggsave("VirtualKO_output/Fig_VK2_Reactome_CrossValidation.pdf", p_vk2, width = 11, height = 12)

# ============================================================
# Part 5: 保存 + 汇总
# ============================================================
saveRDS(list(deg = deg_ko, sig = sig_ko, go = ego, erea = erea),
        "VirtualKO_output/KO_pseudobulk_results.rds")

cat("\n========================================================\n")
cat("  RUNX1 虚拟KO (Pseudobulk) — 完成\n")
cat("========================================================\n")
cat(sprintf("Pseudobulk样本: %d (Hi=%d, Lo=%d)\n", ncol(pseudo_log), length(hi), length(lo)))
cat(sprintf("扰动基因: %d (↑%d, ↓%d)\n",
            nrow(sig_ko), sum(sig_ko$sig=="Up"), sum(sig_ko$sig=="Down")))

cat("\n=== 通路交叉验证 ===\n")
print(cross_df, row.names = FALSE)

cat("\n=== 已知RUNX1靶基因状态 ===\n")
for (g in intersect(known, rownames(deg_ko))) {
  fc <- deg_ko[g, "logFC"]
  pv <- deg_ko[g, "adj.P.Val"]
  sg <- ifelse(pv < 0.05, ifelse(fc > 0, "↑", "↓"), "ns")
  cat(sprintf("  %-14s FC=%+.3f  P=%.2e  %s\n", g, fc, pv, sg))
}

cat("\n输出: VirtualKO_output/\n")
cat("  Fig_VK1_RUNX1_Perturbation_4Panel.pdf\n")
cat("  Fig_VK2_Reactome_CrossValidation.pdf\n")
