# ============================================================
# RUNX1 基因调控网络 (GRN) — 综合机制图
# 整合: SCENIC regulon + RSS协同TF + GSEA通路 + CellChat配体/受体
# ============================================================
setwd("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析")

library(igraph)
library(ggraph)
library(ggplot2)
library(dplyr)
library(patchwork)
library(RColorBrewer)

dir.create("GRN_output", showWarnings=FALSE)

# ============================================================
# Part 1: 构建 RUNX1 调控网络
# ============================================================

# --- 1.1 RUNX1 直接靶基因 (from SCENIC regulon) ---
runx1_targets <- c("GZMK","HINT1","ZCCHC10","C11orf73","YY1",
                    "RUNX1","SKIL","HMGN1","FGD3","CEBPB","MRPS36")

# --- 1.2 RUNX1 协同 TF (from RSS) ---
co_positive <- c("FOXA2","TAL1","FOXP1","WT1","ZNF263","GATA3","YY1","SREBF1")
co_negative <- c("ERG","CEBPD","RFX5","HIF1A","JUN","NFKB1","TCF7L2","USF1")

# --- 1.3 GSEA 通路 → 关键基因 ---
pathway_genes <- list(
  "ECM_Organization"      = c("COL1A1","COL1A2","COL3A1","FN1","DCN","LOX","MMP1","MMP3"),
  "Cell_Cycle"            = c("MKI67","TOP2A","CCNB1","CDK1","PCNA","BIRC5","KIF20A"),
  "Translation"           = c("RPL3","RPL5","RPS3","EIF4E","EIF2S1","EEF1A1"),
  "Inflammatory_Response" = c("IL1B","IL6","CXCL8","TNF","NFKB1","JUN","STAT3"),
  "TGFb_Signaling"        = c("TGFB1","SMAD3","SKIL","ACTA2","TAGLN","SERPINE1"),
  "WNT_Signaling"         = c("WNT5A","TCF7L2","LEF1","AXIN2","CTNNB1"),
  "Immune_Regulation"     = c("HLA-DRA","CD74","C3","CFD","B2M","PDL1")
)

# --- 1.4 CellChat 配体-受体 (RUNX1相关) ---
lr_pairs <- data.frame(
  Ligand   = c("TGFB1","PDGFA","VEGFA","CXCL12","CCL2","SPP1","IL6","FN1","COL1A1","WNT5A"),
  Receptor = c("TGFBR1","PDGFRA","KDR","CXCR4","CCR2","ITGAV","IL6R","ITGB1","ITGA2","FZD5"),
  Pathway  = c("TGFb","PDGF","VEGF","CXCL","CCL","SPP1","IL6","ECM","ECM","WNT"),
  Source_CellType  = c("Fibroblast","Fibroblast","Fibroblast","Inflammatory_Fib",
                        "Inflammatory_Fib","Myofibroblast","Senescent_Fib",
                        "Matrix_Fib","Matrix_Fib","Fibroblast"),
  Target_CellType  = c("Epithelial","Myocyte","Endothelial","Immune",
                        "Immune","Epithelial","Epithelial",
                        "Myocyte","Epithelial","Epithelial"),
  stringsAsFactors = FALSE
)

# --- 1.5 细胞类型 RUNX1 活性背景 ---
runx1_ct <- data.frame(
  CellType = c("Contractile_Fib","Myofibroblast","Complement_Fib","Matrix_Fib",
                "Proliferative_Fib","Inflammatory_Fib","Senescent_Fib",
                "Epithelial","Myocyte","Neuroepithelial"),
  RUNX1_Level = c("Highest","High↑","High↓(Control)","Stable","Stable",
                   "Moderate↓","Low→Moderate↑","Low↓(UC)","Stable_High","↑(UC)"),
  stringsAsFactors = FALSE
)

# ============================================================
# Part 2 修复: 构建 igraph [去重节点名]
# ============================================================

# Build all nodes with priority types
node_list <- list()
add_node <- function(name, type, category) {
  type_priority <- c("TF_Hub"=1, "CoTF_Pos"=2, "CoTF_Neg"=2, "TargetGene"=3,
                     "Pathway"=4, "Ligand"=5, "CellType"=6)
  if (is.null(node_list[[name]]) || type_priority[type] < type_priority[node_list[[name]]$type]) {
    node_list[[name]] <<- list(name=name, type=type, category=category)
  }
}

add_node("RUNX1", "TF_Hub", "Core")
for (g in runx1_targets) add_node(g, "TargetGene", "Target")
for (tf in co_positive) add_node(tf, "CoTF_Pos", "Co_TF")
for (tf in co_negative) add_node(tf, "CoTF_Neg", "Co_TF")
for (pw_name in names(pathway_genes)) add_node(pw_name, "Pathway", "Pathway")
for (lig in unique(lr_pairs$Ligand)) add_node(lig, "Ligand", "CellChat")
for (ct in unique(c(lr_pairs$Source_CellType, lr_pairs$Target_CellType))) add_node(ct, "CellType", "CellType")

nodes <- do.call(rbind, lapply(node_list, as.data.frame, stringsAsFactors=FALSE))
rownames(nodes) <- NULL
cat(sprintf("节点总数: %d (去重)\n", nrow(nodes)))

# Build edges (same as before)
edges <- data.frame(from=character(), to=character(), relationship=character(),
                    stringsAsFactors=FALSE)

for (g in intersect(runx1_targets, nodes$name)) {
  edges <- rbind(edges, data.frame(from="RUNX1", to=g, relationship="regulates"))
}
for (tf in intersect(co_positive, nodes$name)) {
  edges <- rbind(edges, data.frame(from="RUNX1", to=tf, relationship="co_activates"))
}
for (tf in intersect(co_negative, nodes$name)) {
  edges <- rbind(edges, data.frame(from="RUNX1", to=tf, relationship="co_represses"))
}

# Specific target→pathway mappings
manual_edges <- data.frame(
  from = c("CEBPB","SKIL","YY1","FGD3","GZMK","MRPS36","YY1","CEBPB"),
  to   = c("Inflammatory_Response","TGFb_Signaling","Cell_Cycle","ECM_Organization",
           "Inflammatory_Response","Translation","WNT_Signaling","TGFb_Signaling"),
  relationship = "enriches",
  stringsAsFactors = FALSE
)
edges <- rbind(edges, manual_edges)

# Pathway → Ligand
pw_to_lig <- data.frame(
  from = c("TGFb_Signaling","ECM_Organization","ECM_Organization",
           "Inflammatory_Response","Inflammatory_Response","Inflammatory_Response",
           "Inflammatory_Response","Cell_Cycle","WNT_Signaling"),
  to   = c("TGFB1","COL1A1","FN1","IL6","CCL2","CXCL12","SPP1","PDGFA","WNT5A"),
  relationship = "produces",
  stringsAsFactors = FALSE
)
edges <- rbind(edges, pw_to_lig)

# Ligand ↔ CellType
for (i in 1:nrow(lr_pairs)) {
  edges <- rbind(edges,
                 data.frame(from=lr_pairs$Ligand[i], to=lr_pairs$Source_CellType[i],
                            relationship="secreted_by", stringsAsFactors=FALSE))
  edges <- rbind(edges,
                 data.frame(from=lr_pairs$Ligand[i], to=lr_pairs$Target_CellType[i],
                            relationship="targets", stringsAsFactors=FALSE))
}

edges <- unique(edges)
cat(sprintf("边总数: %d\n", nrow(edges)))

# Create graph
g <- graph_from_data_frame(edges, vertices=nodes, directed=TRUE)
cat(sprintf("Graph: %d nodes, %d edges\n", vcount(g), ecount(g)))

# Colors & sizes
type_colors <- c("TF_Hub"="#E64B35","TargetGene"="#F39B7F",
                 "CoTF_Pos"="#F07B3F","CoTF_Neg"="#3C5488",
                 "Pathway"="#00A087","Ligand"="#7E6148","CellType"="#4DBBD5")
type_sizes  <- c("TF_Hub"=9,"TargetGene"=4.5,"CoTF_Pos"=5.5,"CoTF_Neg"=5.5,
                 "Pathway"=6.5,"Ligand"=4.5,"CellType"=6)

V(g)$color <- type_colors[V(g)$type]
V(g)$size  <- type_sizes[V(g)$type]
V(g)$label <- V(g)$name
V(g)$label.cex <- 0.5
V(g)$label.color <- "grey10"
V(g)$frame.color <- NA

edge_colors <- c("regulates"="#E64B3580","co_activates"="#F07B3F60",
                 "co_represses"="#3C548860","enriches"="#00A08760",
                 "produces"="#7E614860","secreted_by"="#4DBBD590","targets"="#4DBBD560")
E(g)$color <- edge_colors[E(g)$relationship]
E(g)$arrow.size <- 0.15
E(g)$width <- ifelse(E(g)$relationship=="regulates", 1.0, 0.5)

# Fig G1: Full network
set.seed(42)
pdf("GRN_output/Fig_G1_RUNX1_Full_GRN_Network.pdf", width=16, height=14)
plot(g, layout=layout_with_fr(g, niter=2000),
     vertex.label.cex=0.55, vertex.label.color="grey10",
     vertex.frame.color=NA, edge.arrow.size=0.2, edge.curved=0.2,
     main="Fig G1: RUNX1 Gene Regulatory Network in UC")
legend("bottomleft", legend=names(type_colors), col=type_colors,
       pch=19, pt.cex=2, bty="n", cex=0.8, title="Node Type")
dev.off()
cat("Fig G1 done\n")

# Fig G2: Core mechanism
core_names <- c("RUNX1", intersect(runx1_targets, V(g)$name),
                "TGFb_Signaling","ECM_Organization","Inflammatory_Response","Cell_Cycle",
                "TGFB1","COL1A1","IL6","PDGFA","SPP1",
                "Myofibroblast","Contractile_Fib","Epithelial")
core_idx <- which(V(g)$name %in% core_names)
g_core <- induced_subgraph(g, core_idx)

pdf("GRN_output/Fig_G2_RUNX1_Core_Mechanism.pdf", width=12, height=10)
set.seed(123)
plot(g_core, layout=layout_with_kk(g_core),
     vertex.label.cex=0.65, vertex.label.color="grey10",
     vertex.frame.color=NA, edge.arrow.size=0.25, edge.curved=0.15,
     main="Fig G2: RUNX1 Core Regulatory Mechanism in UC")
dev.off()
cat("Fig G2 done\n")

# Fig G3: Target gene → Pathway matrix
library(ComplexHeatmap)
library(circlize)

target_pathway_mat <- matrix(0, nrow=length(runx1_targets), ncol=length(names(pathway_genes)))
rownames(target_pathway_mat) <- runx1_targets
colnames(target_pathway_mat) <- names(pathway_genes)

manual_tp <- list(
  "CEBPB" = c("Inflammatory_Response","TGFb_Signaling","Immune_Regulation"),
  "SKIL"  = c("TGFb_Signaling"),
  "YY1"   = c("Cell_Cycle","WNT_Signaling"),
  "FGD3"  = c("ECM_Organization"),
  "GZMK"  = c("Inflammatory_Response"),
  "MRPS36"= c("Translation"),
  "RUNX1" = c("Immune_Regulation"),
  "HINT1" = c("Metabolic"),
  "HMGN1" = c("Chromatin")
)
for (g in names(manual_tp)) {
  for (pw in manual_tp[[g]]) {
    if (pw %in% colnames(target_pathway_mat)) target_pathway_mat[g, pw] <- 1
  }
}

pdf("GRN_output/Fig_G3_TargetGene_Pathway_Heatmap.pdf", width=10, height=5)
Heatmap(target_pathway_mat, name="Association", col=c("white","#E64B35"),
        rect_gp=gpar(col="grey90", lwd=0.5),
        row_names_gp=gpar(fontsize=10),
        column_names_gp=gpar(fontsize=10, fontface="bold"),
        cluster_rows=FALSE, cluster_columns=FALSE,
        column_title="Fig G3: RUNX1 Target Genes → Downstream Pathways",
        column_title_gp=gpar(fontsize=12, fontface="bold"),
        heatmap_legend_param=list(direction="horizontal", title_position="topcenter"))
dev.off()
cat("Fig G3 done\n")

# Fig G4: CellChat LR network
lr_nodes <- unique(c(lr_pairs$Ligand, lr_pairs$Receptor,
                     lr_pairs$Source_CellType, lr_pairs$Target_CellType))
lr_edges <- data.frame(from=character(), to=character(), stringsAsFactors=FALSE)
for (i in 1:nrow(lr_pairs)) {
  lr_edges <- rbind(lr_edges,
                    data.frame(from=lr_pairs$Ligand[i], to=lr_pairs$Receptor[i]))
  lr_edges <- rbind(lr_edges,
                    data.frame(from=lr_pairs$Source_CellType[i], to=lr_pairs$Ligand[i]))
  lr_edges <- rbind(lr_edges,
                    data.frame(from=lr_pairs$Receptor[i], to=lr_pairs$Target_CellType[i]))
}
lr_edges <- unique(lr_edges)
g_lr <- graph_from_data_frame(lr_edges, directed=TRUE)

lr_types <- ifelse(V(g_lr)$name %in% lr_pairs$Ligand, "Ligand",
                   ifelse(V(g_lr)$name %in% lr_pairs$Receptor, "Receptor", "CellType"))
V(g_lr)$color <- ifelse(lr_types=="Ligand","#7E6148",
                        ifelse(lr_types=="Receptor","#00A087","#4DBBD5"))
V(g_lr)$size  <- ifelse(lr_types=="CellType", 6, 4)
V(g_lr)$label.cex <- 0.55
V(g_lr)$frame.color <- NA

pdf("GRN_output/Fig_G4_CellChat_LR_Network.pdf", width=12, height=10)
set.seed(42)
plot(g_lr, layout=layout_with_kk(g_lr),
     vertex.label.cex=0.6, vertex.label.color="grey10",
     vertex.frame.color=NA, edge.arrow.size=0.2,
     main="Fig G4: RUNX1-Driven Ligand-Receptor Network")
legend("topleft", legend=c("Ligand","Receptor","CellType"),
       col=c("#7E6148","#00A087","#4DBBD5"), pch=19, pt.cex=2, bty="n", cex=0.9)
dev.off()
cat("Fig G4 done\n")

cat("\n========================================================\n")
cat("GRN 全部分析完成 — GRN_output/\n")
cat("========================================================\n")