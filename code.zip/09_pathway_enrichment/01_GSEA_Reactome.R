# ============================================================
# UC 单细胞通路富集 — Reactome + 发表级组图
# 替换 KEGG，整合多面板 Figure
# ============================================================
setwd("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析")

library(Seurat)
library(clusterProfiler)
library(org.Hs.eg.db)
library(ReactomePA)
library(enrichplot)
library(dplyr)
library(ggplot2)
library(patchwork)
library(ggrepel)
library(viridis)
library(ComplexHeatmap)
library(circlize)
library(RColorBrewer)

dir.create("GSEA_output", showWarnings = FALSE)

# ============================================================
# Part 1: 加载数据和差异基因（复用已算好的 DEG）
# ============================================================
deg_list <- readRDS("GSEA_output/DEG_list_by_celltype.rds")
all_ct <- names(deg_list)

# ============================================================
# Part 2: Reactome 富集（替代 KEGG）+ GO 三类本体
# ============================================================
reactome_results <- list()
go_bp_results <- list()
go_mf_results <- list()

for (ct in all_ct) {
  cat(sprintf("\n>>> Reactome + GO 富集: %s\n", ct))
  deg <- deg_list[[ct]]

  up_genes   <- deg$SYMBOL[deg$avg_log2FC > 0.25 & deg$p_val_adj < 0.05]
  down_genes <- deg$SYMBOL[deg$avg_log2FC < -0.25 & deg$p_val_adj < 0.05]
  all_degs   <- c(up_genes, down_genes)
  bg_genes   <- deg$SYMBOL

  # --- Symbol → Entrez ID ---
  entrez_all  <- bitr(all_degs, "SYMBOL", "ENTREZID", org.Hs.eg.db)$ENTREZID
  entrez_up   <- bitr(up_genes, "SYMBOL", "ENTREZID", org.Hs.eg.db)$ENTREZID
  entrez_down <- bitr(down_genes, "SYMBOL", "ENTREZID", org.Hs.eg.db)$ENTREZID
  entrez_bg   <- bitr(bg_genes, "SYMBOL", "ENTREZID", org.Hs.eg.db)$ENTREZID

  cat(sprintf("  Entrez: up=%d down=%d bg=%d\n",
              length(entrez_up), length(entrez_down), length(entrez_bg)))

  # --- Reactome (上调) ---
  reac_up <- NULL
  if (length(entrez_up) >= 10) {
    reac_up <- tryCatch(
      enrichPathway(gene = entrez_up, universe = entrez_bg,
                    organism = "human", pAdjustMethod = "BH",
                    pvalueCutoff = 0.05, qvalueCutoff = 0.3, readable = TRUE),
      error = function(e) NULL
    )
  }

  # --- Reactome (下调) ---
  reac_down <- NULL
  if (length(entrez_down) >= 10) {
    reac_down <- tryCatch(
      enrichPathway(gene = entrez_down, universe = entrez_bg,
                    organism = "human", pAdjustMethod = "BH",
                    pvalueCutoff = 0.05, qvalueCutoff = 0.3, readable = TRUE),
      error = function(e) NULL
    )
  }

  reactome_results[[ct]] <- list(up = reac_up, down = reac_down)

  # --- GO MF (上调/下调合并) ---
  go_mf <- NULL
  if (length(all_degs) >= 5) {
    go_mf <- tryCatch(
      enrichGO(gene = all_degs, universe = bg_genes,
               OrgDb = org.Hs.eg.db, keyType = "SYMBOL",
               ont = "MF", pAdjustMethod = "BH",
               pvalueCutoff = 0.05, qvalueCutoff = 0.2),
      error = function(e) NULL
    )
    if (!is.null(go_mf) && nrow(go_mf) > 0) {
      go_mf@result$celltype <- ct
    }
  }
  go_mf_results[[ct]] <- go_mf

  # --- GO BP (复用之前算好的) ---
  go_old <- readRDS("GSEA_output/GO_results_list.rds")
  go_bp_results[[ct]] <- go_old[[ct]]

  n_reac_up   <- if(is.null(reac_up)) 0 else nrow(reac_up)
  n_reac_down <- if(is.null(reac_down)) 0 else nrow(reac_down)
  n_go_mf     <- if(is.null(go_mf)) 0 else nrow(go_mf)
  cat(sprintf("  Reactome: up=%d down=%d  GO_MF=%d\n", n_reac_up, n_reac_down, n_go_mf))
}

saveRDS(reactome_results, "GSEA_output/Reactome_results.rds")
saveRDS(go_mf_results,    "GSEA_output/GO_MF_results.rds")

# ============================================================
# Part 3: 组图 Fig 1 — Reactome 全部细胞类型汇总热图
# ============================================================
all_reac <- data.frame()
for (ct in all_ct) {
  reac_up <- reactome_results[[ct]]$up
  if (is.null(reac_up) || nrow(reac_up) == 0) next
  top <- reac_up@result %>% arrange(p.adjust) %>% head(5)
  top$Direction <- "Up"
  top$CellType  <- ct
  all_reac <- rbind(all_reac, top[, c("Description", "p.adjust", "Direction", "CellType")])
}
for (ct in all_ct) {
  reac_down <- reactome_results[[ct]]$down
  if (is.null(reac_down) || nrow(reac_down) == 0) next
  top <- reac_down@result %>% arrange(p.adjust) %>% head(5)
  top$Direction <- "Down"
  top$CellType  <- ct
  all_reac <- rbind(all_reac, top[, c("Description", "p.adjust", "Direction", "CellType")])
}

if (nrow(all_reac) > 0) {
  all_reac$logP <- -log10(all_reac$p.adjust)
  all_reac$logP[all_reac$logP > 10] <- 10
  all_reac$Description <- factor(all_reac$Description,
                                  levels = rev(unique(all_reac$Description)))

  p_fig1 <- ggplot(all_reac, aes(x = CellType, y = Description,
                                  size = logP, color = Direction)) +
    geom_point() +
    scale_color_manual(values = c("Up" = "#E64B35", "Down" = "#3C5488")) +
    scale_size_continuous(range = c(2, 8), name = "-log10(P)") +
    facet_wrap(~Direction, ncol = 2, scales = "free_y") +
    labs(title = "Fig 1: Reactome Pathway Enrichment (Disease vs Control)",
         x = "", y = "") +
    theme_bw(base_size = 11) +
    theme(axis.text.x = element_text(angle = 40, hjust = 1, size = 9),
          strip.text = element_text(face = "bold", size = 12),
          plot.title = element_text(size = 14, face = "bold"))

  ggsave("GSEA_output/Fig1_Reactome_Summary_DotPlot.pdf",
         p_fig1, width = 16, height = 12)
}

# ============================================================
# Part 4: 组图 Fig 2 — RUNX1 关键三细胞 Reactome + GO BP 综合
# ============================================================
key_ct <- c("Epithelial cells", "Fibroblasts", "Myocytes")
key_ct <- intersect(key_ct, all_ct)

fig2_list <- list()

for (ct in key_ct) {
  reac_up   <- reactome_results[[ct]]$up
  go_bp_up  <- go_bp_results[[ct]]$up

  # 合并每条通路来源标签
  combined <- data.frame()
  if (!is.null(reac_up) && nrow(reac_up) > 0) {
    r <- reac_up@result %>% arrange(p.adjust) %>% head(6)
    r$Database <- "Reactome"
    combined <- rbind(combined, r[, c("Description","p.adjust","Count","Database")])
  }
  if (!is.null(go_bp_up) && nrow(go_bp_up) > 0) {
    g <- go_bp_up@result %>% arrange(p.adjust) %>% head(6)
    g$Database <- "GO BP"
    combined <- rbind(combined, g[, c("Description","p.adjust","Count","Database")])
  }

  if (nrow(combined) == 0) next

  combined <- combined %>% arrange(p.adjust) %>% head(12)

  p <- ggplot(combined,
              aes(x = -log10(p.adjust),
                  y = reorder(Description, -log10(p.adjust)),
                  size = Count, fill = Database)) +
    geom_point(shape = 21, color = "black") +
    scale_fill_manual(values = c("Reactome" = "#E64B35", "GO BP" = "#4DBBD5")) +
    labs(title = paste(ct),
         x = "-log10(adj.P)", y = "") +
    theme_bw(base_size = 9) +
    theme(plot.title = element_text(size = 11, face = "bold"))

  fig2_list[[ct]] <- p
}

if (length(fig2_list) > 0) {
  p_fig2 <- wrap_plots(fig2_list, ncol = 1) +
    plot_annotation(
      title    = "Fig 2: Upregulated Pathways in RUNX1-Key Cell Types",
      subtitle = "Reactome + GO BP (Disease vs Control)",
      theme    = theme(plot.title = element_text(size = 14, face = "bold"),
                       plot.subtitle = element_text(size = 11))
    )

  ggsave("GSEA_output/Fig2_RUNX1_Key_CellTypes_Reactome_GO.pdf",
         p_fig2, width = 12, height = 14)
}

# ============================================================
# Part 5: 组图 Fig 3 — 全局 GO BP 上调/下调 对比气泡图（所有细胞类型）
# ============================================================

# 5a. GO BP Up summary
all_go_up <- data.frame()
for (ct in all_ct) {
  go_up <- go_bp_results[[ct]]$up
  if (is.null(go_up) || nrow(go_up) == 0) next
  top <- go_up@result %>% arrange(p.adjust) %>% head(6)
  top$CellType <- ct
  all_go_up <- rbind(all_go_up, top[, c("Description","p.adjust","Count","CellType")])
}
all_go_up$Direction <- "Up"

# 5b. GO BP Down summary
all_go_down <- data.frame()
for (ct in all_ct) {
  go_down <- go_bp_results[[ct]]$down
  if (is.null(go_down) || nrow(go_down) == 0) next
  top <- go_down@result %>% arrange(p.adjust) %>% head(6)
  top$CellType <- ct
  all_go_down <- rbind(all_go_down, top[, c("Description","p.adjust","Count","CellType")])
}
all_go_down$Direction <- "Down"

all_go <- rbind(all_go_up, all_go_down)
if (nrow(all_go) > 0) {
  all_go$logP <- -log10(all_go$p.adjust)
  all_go$logP[all_go$logP > 10] <- 10

  # 去除太长的描述
  all_go$Description <- sapply(all_go$Description, function(x) {
    if (nchar(x) > 65) paste0(substr(x, 1, 62), "...") else x
  })

  p_fig3 <- ggplot(all_go, aes(x = CellType, y = Description,
                                size = logP, color = Direction)) +
    geom_point(alpha = 0.85) +
    scale_color_manual(values = c("Up" = "#E64B35", "Down" = "#3C5488")) +
    scale_size_continuous(range = c(2, 9), name = "-log10(P)") +
    facet_wrap(~Direction, ncol = 1, scales = "free_y") +
    labs(title = "Fig 3: GO BP — Up vs Down in UC",
         x = "", y = "") +
    theme_bw(base_size = 11) +
    theme(axis.text.x = element_text(angle = 35, hjust = 1, size = 9),
          axis.text.y = element_text(size = 8),
          strip.text   = element_text(face = "bold", size = 13),
          plot.title   = element_text(size = 14, face = "bold"))

  ggsave("GSEA_output/Fig3_GO_BP_UpDown_Summary.pdf",
         p_fig3, width = 14, height = 18)
}

# ============================================================
# Part 6: 组图 Fig 4 — Epithelial 全景面板（4合1）
# ============================================================
if ("Epithelial cells" %in% all_ct) {
  deg_epi <- deg_list[["Epithelial cells"]]

  # 4A. 火山图（上皮功能标注）
  inflammation_genes <- c("IL1B","TNF","IL6","CXCL1","CXCL8","CCL2","CCL5",
                           "IL10","TGFB1","MMP1","MMP3","MMP9","TIMP1","S100A8",
                           "S100A9","NFKB1","RELA","STAT3","JUN","FOS")
  barrier_genes <- c("CLDN1","CLDN2","CLDN4","OCLN","TJP1","TJP2","CDH1",
                      "MUC2","MUC5AC","REG3A","REG1A","DEFA5","DEFA6","LYZ","NOX1","DUOX2")
  repair_genes <- c("EGF","TGFB1","TGFB2","FGF2","FGF7","HGF","VEGFA",
                     "WNT5A","NOTCH1","HES1","MYC","CCND1","PCNA","MKI67")

  deg_epi$category <- "Other"
  deg_epi$category[deg_epi$gene %in% inflammation_genes] <- "Inflammation"
  deg_epi$category[deg_epi$gene %in% barrier_genes]      <- "Barrier"
  deg_epi$category[deg_epi$gene %in% repair_genes]        <- "Repair"

  deg_epi_label <- deg_epi[deg_epi$category != "Other" &
                            abs(deg_epi$avg_log2FC) > 0.25 &
                            deg_epi$p_val_adj < 0.05, ]

  p4a <- ggplot(deg_epi, aes(x = avg_log2FC, y = -log10(p_val_adj))) +
    geom_point(aes(color = category), size = 0.7, alpha = 0.7) +
    scale_color_manual(values = c("Inflammation"="firebrick",
                                   "Barrier"="steelblue",
                                   "Repair"="forestgreen",
                                   "Other"="grey85")) +
    geom_text_repel(data = deg_epi_label, aes(label=gene, color=category),
                     size = 2.5, max.overlaps = 25, show.legend = FALSE) +
    geom_vline(xintercept = c(-0.25, 0.25), lty = "dashed", color = "grey50") +
    geom_hline(yintercept = -log10(0.05), lty = "dashed", color = "grey50") +
    labs(subtitle = "Volcano: Disease vs Control") +
    theme_bw(base_size = 9) +
    theme(legend.position = "right")

  # 4B. Reactome 上调
  reac_epi_up <- reactome_results[["Epithelial cells"]]$up
  if (!is.null(reac_epi_up) && nrow(reac_epi_up) > 0) {
    top_reac <- reac_epi_up@result %>% arrange(p.adjust) %>% head(10)
    p4b <- ggplot(top_reac, aes(x = -log10(p.adjust),
                                 y = reorder(Description, -log10(p.adjust)),
                                 size = Count, fill = -log10(p.adjust))) +
      geom_point(shape = 21, color = "black") +
      scale_fill_viridis_c(option = "C", direction = -1) +
      labs(subtitle = "Reactome Up in Disease") +
      theme_bw(base_size = 9) +
      theme(legend.position = "right")
  } else {
    p4b <- ggplot() + labs(subtitle = "Reactome: no sig terms") + theme_void()
  }

  # 4C. GO BP 下调
  go_epi_down <- go_bp_results[["Epithelial cells"]]$down
  if (!is.null(go_epi_down) && nrow(go_epi_down) > 0) {
    top_go_d <- go_epi_down@result %>% arrange(p.adjust) %>% head(10)
    p4c <- ggplot(top_go_d, aes(x = -log10(p.adjust),
                                 y = reorder(Description, -log10(p.adjust)),
                                 size = Count, fill = -log10(p.adjust))) +
      geom_point(shape = 21, color = "black") +
      scale_fill_viridis_c(option = "D", direction = -1) +
      labs(subtitle = "GO BP Down in Disease") +
      theme_bw(base_size = 9) +
      theme(legend.position = "right")
  } else {
    p4c <- ggplot() + labs(subtitle = "GO BP: no sig terms") + theme_void()
  }

  # 4D. GO MF
  go_epi_mf <- go_mf_results[["Epithelial cells"]]
  if (!is.null(go_epi_mf) && nrow(go_epi_mf) > 0) {
    top_mf <- go_epi_mf@result %>% arrange(p.adjust) %>% head(10)
    p4d <- ggplot(top_mf, aes(x = -log10(p.adjust),
                               y = reorder(Description, -log10(p.adjust)),
                               size = Count, fill = -log10(p.adjust))) +
      geom_point(shape = 21, color = "black") +
      scale_fill_viridis_c(option = "B", direction = -1) +
      labs(subtitle = "GO Molecular Function") +
      theme_bw(base_size = 9) +
      theme(legend.position = "right")
  } else {
    p4d <- ggplot() + labs(subtitle = "GO MF: no sig terms") + theme_void()
  }

  # 拼合 4 面板
  design <- "
    11
    23
    24
  "
  p_fig4 <- p4a + p4b + p4c + p4d +
    plot_layout(design = design) +
    plot_annotation(
      title = "Fig 4: Epithelial Cells — UC Disease Hallmarks",
      subtitle = paste("RUNX1 log2FC = -0.73, the most downregulated TF in UC epithelium"),
      theme = theme(plot.title = element_text(size = 15, face = "bold"),
                    plot.subtitle = element_text(size = 11, color = "grey30"))
    )

  ggsave("GSEA_output/Fig4_Epithelial_4Panel.pdf",
         p_fig4, width = 16, height = 14)
}

# ============================================================
# Part 7: 组图 Fig 5 — Fibroblast + Myocyte 对比面板
# ============================================================
fig5_ct <- c("Fibroblasts", "Myocytes")
fig5_ct <- intersect(fig5_ct, all_ct)

fig5_list <- list()
for (ct in fig5_ct) {
  deg <- deg_list[[ct]]
  reac_up <- reactome_results[[ct]]$up
  reac_down <- reactome_results[[ct]]$down

  # 火山图（简化）
  deg$sig <- "NS"
  deg$sig[deg$avg_log2FC > 0.25 & deg$p_val_adj < 0.05] <- "Up"
  deg$sig[deg$avg_log2FC < -0.25 & deg$p_val_adj < 0.05] <- "Down"
  top_lab <- deg %>% filter(sig != "NS") %>% arrange(p_val_adj) %>% head(8)

  n_up   <- sum(deg$sig == "Up")
  n_down <- sum(deg$sig == "Down")

  p_volc <- ggplot(deg, aes(x = avg_log2FC, y = -log10(p_val_adj))) +
    geom_point(aes(color = sig), size = 0.4, alpha = 0.5) +
    scale_color_manual(values = c("Up"="red3", "Down"="royalblue3", "NS"="grey85")) +
    geom_text_repel(data = top_lab, aes(label = gene), size = 2.3, max.overlaps = 12) +
    geom_vline(xintercept = c(-0.25, 0.25), lty = "dashed", color = "grey50") +
    geom_hline(yintercept = -log10(0.05), lty = "dashed", color = "grey50") +
    labs(subtitle = paste0(ct, "  (Up:", n_up, " Down:", n_down, ")")) +
    theme_bw(base_size = 8) + theme(legend.position = "none")

  # Reactome Up
  if (!is.null(reac_up) && nrow(reac_up) > 0) {
    top <- reac_up@result %>% arrange(p.adjust) %>% head(8)
    p_reac <- ggplot(top, aes(x = -log10(p.adjust),
                               y = reorder(Description, -log10(p.adjust)),
                               size = Count)) +
      geom_point(color = "#E64B35") +
      labs(subtitle = "Reactome Up", x = "-log10(P)", y = "") +
      theme_bw(base_size = 8) +
      theme(axis.text.y = element_text(size = 7))
  } else {
    p_reac <- ggplot() + theme_void()
  }

  fig5_list[[paste0(ct,"_volc")]] <- p_volc
  fig5_list[[paste0(ct,"_reac")]] <- p_reac
}

if (length(fig5_list) >= 4) {
  p_fig5 <- (fig5_list[[1]] | fig5_list[[3]]) /
            (fig5_list[[2]] | fig5_list[[4]]) +
    plot_annotation(
      title = "Fig 5: Fibroblasts vs Myocytes — Disease Response Patterns",
      subtitle = "Fibroblasts (RUNX1 stable high) vs Myocytes (RUNX1 highest, proliferation activated)",
      theme = theme(plot.title = element_text(size = 14, face = "bold"),
                    plot.subtitle = element_text(size = 10, color = "grey30"))
    )

  ggsave("GSEA_output/Fig5_Fibroblast_Myocyte_4Panel.pdf",
         p_fig5, width = 14, height = 11)
}

# ============================================================
# Part 8: 组图 Fig 6 — 热图汇总 [修正Inf bug]
# ============================================================
library(reshape2)

summary_mat <- data.frame()
for (ct in all_ct) {
  go_up <- go_bp_results[[ct]]$up
  if (!is.null(go_up) && nrow(go_up) > 0) {
    top <- go_up@result %>% arrange(p.adjust) %>% head(3)
    top$Source   <- "GO"
    top$CellType <- ct
    summary_mat <- rbind(summary_mat, top[, c("Description","p.adjust","CellType","Source")])
  }
  reac_up <- reactome_results[[ct]]$up
  if (!is.null(reac_up) && nrow(reac_up) > 0) {
    top <- reac_up@result %>% arrange(p.adjust) %>% head(2)
    top$Source   <- "Reactome"
    top$CellType <- ct
    summary_mat <- rbind(summary_mat, top[, c("Description","p.adjust","CellType","Source")])
  }
}

# 去重：同一 Description × CellType 取最显著
summary_mat <- summary_mat %>%
  group_by(Description, CellType) %>%
  slice_min(p.adjust, n = 1) %>%
  ungroup() %>%
  as.data.frame()

# 手动构建矩阵，避免 dcast Inf 问题
desc_list <- unique(summary_mat$Description)
ct_list   <- unique(summary_mat$CellType)

mat_log <- matrix(0, nrow = length(desc_list), ncol = length(ct_list))
rownames(mat_log) <- desc_list
colnames(mat_log) <- ct_list

for (i in seq_len(nrow(summary_mat))) {
  r <- summary_mat$Description[i]
  c <- summary_mat$CellType[i]
  p <- summary_mat$p.adjust[i]
  mat_log[r, c] <- -log10(p)
}

mat_log[mat_log > 15] <- 15
mat_log[mat_log < 0] <- 0
mat_log[!is.finite(mat_log)] <- 0

# 去掉全是 0 的行/列
mat_log <- mat_log[rowSums(mat_log) > 0, colSums(mat_log) > 0, drop = FALSE]

if (nrow(mat_log) < 2) {
  cat("矩阵太小，跳过热图\n")
} else {
  row_source <- summary_mat$Source[match(rownames(mat_log), summary_mat$Description)]
  
  row_anno <- rowAnnotation(
    Source = row_source,
    col = list(Source = c("GO" = "#4DBBD5", "Reactome" = "#E64B35")),
    show_annotation_name = FALSE,
    annotation_legend_param = list(title = "Database")
  )
  
  pdf("GSEA_output/Fig6_Summary_Heatmap_All_CellTypes.pdf", width = 14, height = 12)
  draw(Heatmap(mat_log,
               name = "-log10(adj.P)",
               col = colorRamp2(c(0, 2, 5, 15),
                                c("white","#FFF5E0","#F07B3F","#B22222")),
               right_annotation = row_anno,
               row_names_gp = gpar(fontsize = 7.5),
               column_names_gp = gpar(fontsize = 10, fontface = "bold"),
               cluster_rows = TRUE, cluster_columns = TRUE,
               column_title = "Fig 6: Pathway Enrichment Summary — UC Disease vs Control",
               column_title_gp = gpar(fontsize = 13, fontface = "bold"),
               heatmap_legend_param = list(direction = "horizontal",
                                           title_position = "topcenter")),
       heatmap_legend_side = "bottom")
  dev.off()
  cat("Fig 6 saved!\n")
}

# ============================================================
# 完成确认
# ============================================================
cat("\n========== 全部 6 张组图 ==========\n")
print(list.files("GSEA_output", pattern = "^Fig"))

# ============================================================
# Part 9: 完成确认
# ============================================================
cat("\n全部 6 张组图生成完毕! GSEA_output/ 目录:\n")
print(list.files("GSEA_output", pattern = "^Fig"))
# ============================================================
# Part 9: 定量统计表输出
# ============================================================
cat("\n========================================================\n")
cat("  Reactome 富集 & 组图 — 全部完成\n")
cat("========================================================\n\n")
cat("输出目录: GSEA_output/\n\n")
cat("组图清单:\n")
cat("  Fig1_Reactome_Summary_DotPlot.pdf          全细胞类型Reactome汇总\n")
cat("  Fig2_RUNX1_Key_CellTypes_Reactome_GO.pdf   RUNX1三细胞Reactome+GO\n")
cat("  Fig3_GO_BP_UpDown_Summary.pdf              GO BP上调/下调全局\n")
cat("  Fig4_Epithelial_4Panel.pdf                 上皮细胞4合1面板\n")
cat("  Fig5_Fibroblast_Myocyte_4Panel.pdf         成纤维vs肌细胞对比\n")
cat("  Fig6_Summary_Heatmap_All_CellTypes.pdf     全细胞类型通路热图\n")
cat("========================================================\n")
