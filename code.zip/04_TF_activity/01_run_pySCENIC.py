#!/usr/bin/env python3
"""
pySCENIC pipeline for Ulcerative Colitis scRNA-seq data.
Replicates the transcription factor analysis from:
  Yang et al. "Single-cell and machine learning analyses identify a PFKFB3-centered
  regulatory network and potential salidroside interaction in coronary heart disease"

Steps: GRN inference (GRNBoost2) → cisTarget regulon generation → AUCell scoring

Requirements:
  pip install pyscenic scanpy loompy ctxcore pandas numpy
  pip install arboreto  # for GRNBoost2

Database files needed (download from https://resources.aertslab.org/cistarget/):
  1. TF list:     https://resources.aertslab.org/cistarget/tf_lists/allTFs_hg38.txt
  2. Rankings:    https://resources.aertslab.org/cistarget/motif2tf/motifs-v10nr_clust-nr.hgnc-m0.001-o0.0.tbl
  3. Motif-TF:    https://resources.aertslab.org/cistarget/databases/homo_sapiens/hg38/refseq_r80/mc9nr/gene_based/hg38__refseq-r80__10kb_up_and_down_tss.mc9nr.genes_vs_motifs.rankings.feather
"""

import os
import sys
import logging
import subprocess
import numpy as np
import pandas as pd
import scanpy as sc
import anndata

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# ==========================================
# 0. Configuration — EDIT THESE PATHS
# ==========================================
WORK_DIR   = r"E:\yhb\溃疡\溃疡\12.Seurat"
SEURAT_RDS = os.path.join(WORK_DIR, "Seurat.Rdata")
OUT_DIR    = os.path.join(WORK_DIR, "pySCENIC_output")

# pySCENIC database files (download from https://resources.aertslab.org/cistarget/)
TF_LIST    = os.path.join(WORK_DIR, "allTFs_hg38.txt")
RANKINGS   = os.path.join(WORK_DIR, "hg38__refseq-r80__10kb_up_and_down_tss.mc9nr.genes_vs_motifs.rankings.feather")
MOTIF_TF   = os.path.join(WORK_DIR, "motifs-v10nr_clust-nr.hgnc-m0.001-o0.0.tbl")

N_CPUS     = 8  # adjust to your machine

os.makedirs(OUT_DIR, exist_ok=True)


# ==========================================
# 1. Export expression matrix from Seurat object
# ==========================================
def export_expression_from_seurat():
    """
    Use R to extract the raw count matrix and cell metadata from the Seurat object,
    then save as 10X-style mtx or CSV that scanpy/pySCENIC can read.
    """
    logger.info("Extracting expression matrix from Seurat object via R...")

    r_script = os.path.join(OUT_DIR, "export_seurat.R")
    with open(r_script, "w") as f:
        f.write(r"""
library(Seurat)
library(Matrix)

load("%s")

# Use raw counts for SCENIC (layer='counts' in v5, or RNA@counts)
counts <- GetAssayData(pbmc, assay="RNA", layer="counts")

# Filter to expressed genes: at least 1 UMI in >= 1% of cells
gene_mask <- Matrix::rowSums(counts > 0) >= ncol(counts) * 0.01
counts <- counts[gene_mask, ]

# Save in 10X-like format
out_dir <- "%s"
dir.create(file.path(out_dir, "exported_counts"), showWarnings=FALSE, recursive=TRUE)
Matrix::writeMM(counts, file=file.path(out_dir, "exported_counts", "matrix.mtx"))

# Genes
write.table(data.frame(Gene=rownames(counts), row.names=rownames(counts)),
            file=file.path(out_dir, "exported_counts", "genes.tsv"),
            quote=FALSE, sep="\t", row.names=TRUE, col.names=FALSE)

# Barcodes
write.table(data.frame(Barcode=colnames(counts)),
            file=file.path(out_dir, "exported_counts", "barcodes.tsv"),
            quote=FALSE, sep="\t", row.names=FALSE, col.names=FALSE)

# Cell metadata
write.csv(pbmc@meta.data, file=file.path(out_dir, "exported_counts", "metadata.csv"))

cat("Export complete. Genes:", nrow(counts), "Cells:", ncol(counts), "\n")
""" % (SEURAT_RDS.replace("\\", "/"), OUT_DIR.replace("\\", "/")))

    subprocess.run(["Rscript", r_script], check=True)

    # Read into AnnData
    adata = sc.read_10x_mtx(
        os.path.join(OUT_DIR, "exported_counts"),
        var_names='gene_symbols',
        cache=False
    )
    # Make genes unique
    adata.var_names_make_unique()

    # Add metadata
    meta = pd.read_csv(os.path.join(OUT_DIR, "exported_counts", "metadata.csv"), index_col=0)
    for col in meta.columns:
        adata.obs[col] = meta.loc[adata.obs_names, col]

    logger.info(f"AnnData shape: {adata.shape}")
    return adata


# ==========================================
# 2. Alternative: Export as loom file
# ==========================================
def export_as_loom():
    """Export counts as loom file using R."""
    logger.info("Exporting to loom via R...")

    r_script = os.path.join(OUT_DIR, "export_loom.R")
    loom_path = os.path.join(OUT_DIR, "expr_matrix.loom").replace("\\", "/")

    with open(r_script, "w") as f:
        f.write(r"""
library(Seurat)
library(SCopeLoomR)

load("%s")

counts <- GetAssayData(pbmc, assay="RNA", layer="counts")
gene_mask <- Matrix::rowSums(counts > 0) >= ncol(counts) * 0.01
counts <- counts[gene_mask, ]

loom <- build_loom(file="%s", dgem=counts)
close_loom(loom)
cat("Loom export done.\n")
""" % (SEURAT_RDS.replace("\\", "/"), loom_path))

    subprocess.run(["Rscript", r_script], check=True)
    return loom_path


# ==========================================
# 3. Run pySCENIC GRN step
# ==========================================
def run_grn(expr_matrix_csv):
    """GRN inference using GRNBoost2 (arboreto)."""
    adj_csv = os.path.join(OUT_DIR, "adjacency.csv")
    logger.info("Step 1/3: GRN inference (GRNBoost2)...")

    cmd = [
        "pyscenic", "grn",
        "--num_workers", str(N_CPUS),
        "--output", adj_csv,
        expr_matrix_csv,
        TF_LIST
    ]
    logger.info(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    logger.info(f"Adjacency matrix saved to: {adj_csv}")
    return adj_csv


# ==========================================
# 4. Run cisTarget (regulon generation)
# ==========================================
def run_cistarget(adj_csv):
    """cisTarget step: identify direct TF targets using motif enrichment."""
    reg_csv = os.path.join(OUT_DIR, "regulons.csv")
    logger.info("Step 2/3: cisTarget regulon generation...")

    cmd = [
        "pyscenic", "ctx",
        "--num_workers", str(N_CPUS),
        "--output", reg_csv,
        "--annotations_fname", MOTIF_TF,
        "--expression_mtx_fname", os.path.join(OUT_DIR, "expr_matrix.csv"),
        "--mode", "dask_multiprocessing",
        adj_csv,
        RANKINGS
    ]
    logger.info(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    logger.info(f"Regulons saved to: {reg_csv}")
    return reg_csv


# ==========================================
# 5. Run AUCell (cellular enrichment)
# ==========================================
def run_aucell(expr_matrix_loom, reg_csv):
    """AUCell step: score each cell for each regulon."""
    auc_loom = os.path.join(OUT_DIR, "aucell.loom")
    logger.info("Step 3/3: AUCell scoring...")

    cmd = [
        "pyscenic", "aucell",
        "--num_workers", str(N_CPUS),
        "--output", auc_loom,
        expr_matrix_loom,
        reg_csv
    ]
    logger.info(f"Running: {' '.join(cmd)}")
    subprocess.run(cmd, check=True)
    logger.info(f"AUCell scores saved to: {auc_loom}")
    return auc_loom


# ==========================================
# 6. Convert AUCell loom to CSV for R import
# ==========================================
def aucell_to_csv(auc_loom):
    """Read AUCell loom and export as CSV + regulon metadata."""
    import loompy

    logger.info("Converting AUCell loom to CSV...")
    with loompy.connect(auc_loom) as lf:
        auc_mtx = pd.DataFrame(
            lf[:, :],
            index=lf.ra["Gene"],
            columns=lf.ca["CellID"]
        )
        # Regulon metadata
        if "Regulons" in lf.ra:
            regulon_info = pd.DataFrame({
                "Regulon": lf.ra["Regulons"],
                "Gene": lf.ra["Gene"],
                "TF": [r.split("(")[0].replace("+", "") for r in lf.ra["Regulons"]]
            })
        else:
            regulon_info = pd.DataFrame({
                "Regulon": auc_mtx.index,
                "Gene": auc_mtx.index,
                "TF": [r.split("(")[0].replace("+", "") for r in auc_mtx.index]
            })

    auc_mtx.to_csv(os.path.join(OUT_DIR, "AUCell_matrix.csv"))
    regulon_info.to_csv(os.path.join(OUT_DIR, "regulon_info.csv"), index=False)
    logger.info(f"AUCell matrix: {auc_mtx.shape[0]} regulons x {auc_mtx.shape[1]} cells")
    logger.info("Done. Ready for R visualization.")


# ==========================================
# MAIN
# ==========================================
def main():
    logger.info("=" * 60)
    logger.info("pySCENIC pipeline for UC scRNA-seq")
    logger.info("=" * 60)

    # Check databases
    for fpath, desc in [(TF_LIST, "TF list"), (RANKINGS, "Ranking DB"), (MOTIF_TF, "Motif-TF annotation")]:
        if not os.path.exists(fpath):
            logger.error(f"Missing database: {desc} ({fpath})")
            logger.error("Download from https://resources.aertslab.org/cistarget/")
            sys.exit(1)

    # Export expression matrix from Seurat
    # Method A: Try loom export (faster for pySCENIC)
    try:
        loom_path = export_as_loom()
        use_loom = True
    except Exception as e:
        logger.warning(f"Loom export failed ({e}), falling back to 10X mtx export")
        adata = export_expression_from_seurat()
        # Save as CSV for GRN step
        expr_csv = os.path.join(OUT_DIR, "expr_matrix.csv")
        pd.DataFrame(
            adata.X.toarray() if hasattr(adata.X, 'toarray') else adata.X,
            index=adata.obs_names,
            columns=adata.var_names
        ).T.to_csv(expr_csv)
        use_loom = False

    # pySCENIC pipeline
    if use_loom:
        # For loom input, we need the CSV too for GRN step
        logger.info("You have the loom file. Run CLI commands:")
        logger.info(f"  pyscenic grn --num_workers {N_CPUS} -o {OUT_DIR}/adjacency.csv \\")
        logger.info(f"      {os.path.join(OUT_DIR, 'expr_matrix.csv')} {TF_LIST}")
        logger.info(f"  pyscenic ctx {OUT_DIR}/adjacency.csv {RANKINGS} \\")
        logger.info(f"      --annotations_fname {MOTIF_TF} \\")
        logger.info(f"      --expression_mtx_fname {os.path.join(OUT_DIR, 'expr_matrix.csv')} \\")
        logger.info(f"      --output {OUT_DIR}/regulons.csv --num_workers {N_CPUS}")
        logger.info(f"  pyscenic aucell {os.path.join(OUT_DIR, 'expr_matrix.loom')} \\")
        logger.info(f"      {OUT_DIR}/regulons.csv --output {OUT_DIR}/aucell.loom --num_workers {N_CPUS}")
    else:
        # Run GRN
        adj_csv = run_grn(os.path.join(OUT_DIR, "expr_matrix.csv"))
        # Run cisTarget
        reg_csv = run_cistarget(adj_csv)
        # Run AUCell
        # For AUCell, need loom - convert
        logger.info("Converting CSV to loom for AUCell step...")
        auc_loom = run_aucell(loom_path if use_loom else os.path.join(OUT_DIR, "expr_matrix.csv"), reg_csv)
        aucell_to_csv(auc_loom)

    logger.info("=" * 60)
    logger.info("pySCENIC pipeline finished!")
    logger.info(f"All outputs in: {OUT_DIR}")
    logger.info("Next: Run TF_figures.R to create the figures.")
    logger.info("=" * 60)


if __name__ == "__main__":
    main()
