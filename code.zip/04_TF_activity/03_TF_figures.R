##############################################################################
# TF_figures.R — Transcription Factor Regulon Activity Visualization
# Ulcerative Colitis scRNA-seq
#
# Replicates Figure 6 from:
#   Yang et al. "Single-cell and machine learning analyses identify a PFKFB3-
#   centered regulatory network and potential salidroside interaction in CHD"
#
# Approach: pySCENIC AUCell scores → Seurat integration → t-SNE + violin plots
#
# If pySCENIC output not available, falls back to in-R SCENIC (slower).
##############################################################################

library(Seurat)
library(dplyr)
library(ggplot2)
library(patchwork)
library(gridExtra)
library(Matrix)
library(viridis)

# ==========================================
# 0. Configuration
# ==========================================
WORK_DIR  <- "E:/yhb/溃疡/溃疡/12.Seurat"
setwd(WORK_DIR)

PYSCENIC_DIR <- file.path(WORK_DIR, "pySCENIC_output")
AUC_CSV       <- file.path(PYSCENIC_DIR, "AUCell_matrix.csv")
REGULON_CSV   <- file.path(PYSCENIC_DIR, "regulon_info.csv")
SEURAT_RDS    <- file.path(WORK_DIR, "Seurat.Rdata")

OUT_PDF       <- file.path(WORK_DIR, "TF_regulon_activity.pdf")
OUT_PNG       <- file.path(WORK_DIR, "TF_regulon_activity.png")

# Which TFs to highlight (top variable regulons, adjust as needed)
N_TOP_TFS <- 4   # Number of top TFs to make individual panels for

# ==========================================
# 1. Load Seurat object
# ==========================================
cat("Loading Seurat object...\n")
load(SEURAT_RDS)

# Ensure t-SNE is present
if (!"tsne" %in% names(pbmc@reductions)) {
  stop("t-SNE not found in Seurat object. Run RunTSNE() first.")
}

# Extract t-SNE coordinates
tsne_coords <- Embeddings(pbmc, "tsne")
cell_barcodes <- colnames(pbmc)

# Get cell type labels (from SingleR annotation)
# cellAnn was saved in Seurat.Rdata
cell_types <- cellAnn
names(cell_types) <- cell_barcodes

# Get group (Control / Disease)
sample_groups <- pbmc$Type
names(sample_groups) <- cell_barcodes

cat(sprintf("  Cells: %d, Cell types: %d\n", length(cell_barcodes),
            length(unique(cell_types))))

# ==========================================
# 2. Load or compute TF regulon activity (AUCell scores)
# ==========================================

auc_mtx <- NULL
regulon_info <- NULL

if (file.exists(AUC_CSV)) {
  # --- Option A: Load pre-computed pySCENIC results ---
  cat("Loading pre-computed pySCENIC AUCell scores...\n")
  auc_mtx <- as.matrix(read.csv(AUC_CSV, row.names = 1, check.names = FALSE))
  if (file.exists(REGULON_CSV)) {
    regulon_info <- read.csv(REGULON_CSV, stringsAsFactors = FALSE)
  }
  cat(sprintf("  Loaded: %d regulons x %d cells\n", nrow(auc_mtx), ncol(auc_mtx)))

} else if (file.exists(file.path(WORK_DIR, "aucell.loom"))) {
  # --- Option A2: Read AUCell loom directly ---
  cat("Loading AUCell loom file...\n")
  if (!requireNamespace("loomR", quietly = TRUE)) {
    stop("Package 'loomR' needed. Install: devtools::install_github('mojaveazure/loomR')")
  }
  library(loomR)
  lfile <- connect(filename = file.path(WORK_DIR, "aucell.loom"), mode = "r+")
  auc_mtx <- t(lfile[["matrix"]][, ])
  colnames(auc_mtx) <- lfile[["col_attrs"]][["CellID"]][]
  rownames(auc_mtx) <- lfile[["row_attrs"]][["Gene"]][]
  lfile$close_all()

} else {
  # --- Option B: Run SCENIC in R (fallback) ---
  cat("\n============================================================\n")
  cat("  pySCENIC output not found.\n")
  cat("  R SCENIC requires cisTarget databases (several GB).\n")
  cat("  RECOMMENDATION: Use TF_activity_decoupleR.R instead!\n")
  cat("    → No database downloads, runs in minutes, same figures.\n")
  cat("\n")
  cat("  If you want the exact pySCENIC method from the paper:\n")
  cat("    1. Download 3 DB files from https://resources.aertslab.org/cistarget/\n")
  cat("    2. Run: python run_pySCENIC.py\n")
  cat("    3. Re-run this script\n")
  cat("\n")
  cat("  If you insist on R SCENIC (slow, DB-heavy):\n")
  cat("    BiocManager::install(c('SCENIC','RcisTarget','GENIE3'))\n")
  cat("    Download hg38 databases to cisTarget_databases/\n")
  cat("============================================================\n\n")

  # Only attempt R SCENIC if explicitly configured
  r_scenic_db <- file.path(WORK_DIR, "cisTarget_databases")
  if (dir.exists(r_scenic_db) && length(list.files(r_scenic_db, pattern = "\\.feather$")) > 0) {
    cat("cisTarget databases found. Attempting R SCENIC (this uses substantial memory)...\n")
    if (!requireNamespace("SCENIC", quietly = TRUE)) {
      stop("SCENIC package not available.")
    }
    library(SCENIC)

    # Keep sparse to avoid memory explosion (174k cells × genes = potentially >35 GB dense)
    expr_mat <- GetAssayData(pbmc, assay = "RNA", layer = "data")
    gene_mask <- Matrix::rowSums(expr_mat > 0) >= ncol(expr_mat) * 0.01
    expr_mat <- expr_mat[gene_mask, ]

    # Sample cells if too many (SCENIC works fine with 10k-30k cells)
    n_sample <- min(ncol(expr_mat), 20000)
    if (n_sample < ncol(expr_mat)) {
      cat(sprintf("Sampling %d / %d cells for SCENIC...\n", n_sample, ncol(expr_mat)))
      set.seed(42)
      sample_idx <- sample(ncol(expr_mat), n_sample)
      expr_mat <- expr_mat[, sample_idx]
    }

    expr_mat <- as.matrix(expr_mat)

    scenicOptions <- initializeScenic(
      org = "hgnc",
      dbDir = r_scenic_db,
      nCores = 8
    )
    saveRDS(scenicOptions, file = "scenicOptions.Rds")

    genesKept <- geneFiltering(expr_mat, scenicOptions = scenicOptions)
    runGenie3(as.matrix(expr_mat), scenicOptions)
    runSCENIC_1_coexNetwork2modules(scenicOptions)
    runSCENIC_2_createRegulons(scenicOptions)
    runSCENIC_3_scoreCells(scenicOptions, expr_mat)

    auc_mtx <- readRDS(file.path(getIntName(scenicOptions, "aucell"), "AUCell_matrix.Rds"))
    regulon_info <- readRDS(file.path(getIntName(scenicOptions, "aucell"), "regulons_AUC.Rds"))
  } else {
    stop(
      "No TF activity data source available.\n",
      "Fast option:  source('TF_activity_decoupleR.R')\n",
      "Paper option:  python run_pySCENIC.py  then re-run this script\n",
      "R SCENIC:      download cisTarget DBs to ", r_scenic_db, "/ and re-run"
    )
  }
}


# ==========================================
# 3. Match AUCell matrix to Seurat cells
# ==========================================

cat("Matching AUCell scores to Seurat cells...\n")

# Handle potential barcode format differences
auc_cells <- colnames(auc_mtx)
seurat_cells <- colnames(pbmc)

# Common barcode format fixes
# If pySCENIC stripped the sample prefix, try to match by suffix
if (length(intersect(auc_cells, seurat_cells)) < 10) {
  # Try matching by removing/add sample prefix
  auc_short <- gsub(".*?_", "", auc_cells)
  seurat_short <- gsub(".*?_", "", seurat_cells)

  if (length(intersect(auc_short, seurat_short)) > 10) {
    # Remap
    names(auc_short) <- auc_cells
    match_idx <- match(seurat_short, auc_short)
    auc_cells_matched <- auc_cells[match_idx]
    auc_cells_matched[is.na(match_idx)] <- auc_cells[match(seurat_cells[is.na(match_idx)], auc_cells)]
    colnames(auc_mtx) <- NULL  # We'll use position-based indexing
    auc_mtx <- auc_mtx[, match_idx, drop = FALSE]
    colnames(auc_mtx) <- seurat_cells
  }
}

# Subset AUC matrix to matching cells
common_cells <- intersect(colnames(auc_mtx), seurat_cells)
if (length(common_cells) < ncol(pbmc) * 0.5) {
  warning(sprintf("Only %d / %d cells matched. Check barcode formats.",
                  length(common_cells), ncol(pbmc)))
}
auc_mtx <- auc_mtx[, common_cells, drop = FALSE]
auc_cells <- common_cells

cat(sprintf("  Matched cells: %d\n", length(common_cells)))


# ==========================================
# 4. Add AUCell assay to Seurat object
# ==========================================

cat("Adding SCENIC assay to Seurat object...\n")

# Subset Seurat to matched cells
pbmc_sub <- subset(pbmc, cells = common_cells)

# Create SCENIC assay
scenic_assay <- CreateAssayObject(data = auc_mtx)
pbmc_sub[["SCENIC"]] <- scenic_assay

# Set default assay to SCENIC for visualization
DefaultAssay(pbmc_sub) <- "SCENIC"

# Store TF names (regulon names) in feature metadata
tf_names <- rownames(auc_mtx)
# Clean regulon names (remove suffix like "(+)", "_extended", etc.)
tf_names_clean <- gsub("\\s*\\(\\+\\)|\\s*_extended", "", tf_names)
names(tf_names_clean) <- tf_names


# ==========================================
# 5. Select top variable TFs for visualization
# ==========================================

cat("Selecting top variable transcription factors...\n")

# Calculate variance of AUCell scores across cells
auc_var <- apply(auc_mtx, 1, var)
auc_var <- sort(auc_var, decreasing = TRUE)

# Also compute differential activity between Control and Disease for each TF
group_levels <- unique(sample_groups[common_cells])
de_results <- list()

for (tf in names(auc_var)[1:min(50, length(auc_var))]) {
  tf_scores <- auc_mtx[tf, common_cells]
  ctrl_scores <- tf_scores[sample_groups[common_cells] == unique(sample_groups)[1]]
  disease_scores <- tf_scores[sample_groups[common_cells] == unique(sample_groups)[2]]

  if (length(ctrl_scores) > 5 && length(disease_scores) > 5) {
    test_res <- tryCatch({
      wilcox.test(disease_scores, ctrl_scores)
    }, error = function(e) NULL)

    if (!is.null(test_res)) {
      de_results[[tf]] <- data.frame(
        TF         = tf,
        TF_clean   = tf_names_clean[tf],
        mean_AUC   = mean(tf_scores),
        var_AUC    = auc_var[tf],
        log2FC     = log2(mean(disease_scores) / mean(ctrl_scores)),
        p_value    = test_res$p.value,
        stringsAsFactors = FALSE
      )
    }
  }
}

de_tf_df <- do.call(rbind, de_results)
de_tf_df <- de_tf_df[order(de_tf_df$p_value), ]

# Select top TFs: combine high variance + differential activity
top_tf_candidates <- head(de_tf_df$TF, 20)

cat(sprintf("Top %d candidate TFs:\n", length(top_tf_candidates)))
for (i in seq_len(min(N_TOP_TFS + 2, nrow(de_tf_df)))) {
  cat(sprintf("  %s  |  var=%.4f  |  log2FC=%.3f  |  p=%.2e\n",
              de_tf_df$TF_clean[i], de_tf_df$var_AUC[i],
              de_tf_df$log2FC[i], de_tf_df$p_value[i]))
}

# Pick top N
top_tfs <- head(de_tf_df$TF, N_TOP_TFS)
top_tf_names <- de_tf_df$TF_clean[1:N_TOP_TFS]


# ==========================================
# 6. Visualization — t-SNE + violin for each TF
# ==========================================

cat("Creating figures...\n")

# Color scale for t-SNE (continuous)
tsne_colors <- c("grey90", "lightblue", "steelblue", "darkblue", "darkred")

# Cell type color palette (distinct colors)
n_types <- length(unique(cell_types))
cell_type_colors <- scales::hue_pal()(n_types)
names(cell_type_colors) <- sort(unique(cell_types))

theme_pub <- theme_bw(base_size = 10) +
  theme(
    panel.grid = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 0.5),
    plot.title = element_text(size = 11, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 9),
    axis.text = element_text(size = 8),
    legend.position = "right",
    legend.key.size = unit(0.3, "cm"),
    legend.text = element_text(size = 7),
    legend.title = element_text(size = 8),
    strip.text = element_text(size = 10, face = "bold"),
    strip.background = element_rect(fill = "grey95", color = "black")
  )


# ---- Function: t-SNE colored by TF regulon activity ----
plot_tsne_tf <- function(tf_name, tf_clean_name) {
  scores <- auc_mtx[tf_name, common_cells]
  plot_df <- data.frame(
    tSNE_1 = tsne_coords[common_cells, 1],
    tSNE_2 = tsne_coords[common_cells, 2],
    Activity = scores,
    CellType = cell_types[common_cells]
  )

  ggplot(plot_df, aes(x = tSNE_1, y = tSNE_2, color = Activity)) +
    geom_point(size = 0.3, alpha = 0.7) +
    scale_color_gradientn(colors = tsne_colors, name = "AUCell") +
    labs(
      title = bquote(.(tf_clean_name) ~ "regulon"),
      x = "t-SNE 1",
      y = "t-SNE 2"
    ) +
    theme_pub +
    guides(color = guide_colorbar(barwidth = 0.5, barheight = 3))
}


# ---- Function: Violin plot by cell type ----
plot_violin_tf <- function(tf_name, tf_clean_name) {
  scores <- auc_mtx[tf_name, common_cells]
  plot_df <- data.frame(
    Activity = scores,
    CellType = factor(cell_types[common_cells]),
    Group = sample_groups[common_cells]
  )

  ggplot(plot_df, aes(x = CellType, y = Activity, fill = CellType)) +
    geom_violin(scale = "width", alpha = 0.7, draw_quantiles = 0.5,
                size = 0.3, color = "grey30") +
    geom_jitter(aes(color = Group), size = 0.15, alpha = 0.3, width = 0.2) +
    scale_fill_manual(values = cell_type_colors, guide = "none") +
    scale_color_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    labs(
      x = "",
      y = paste0(tf_clean_name, " regulon activity (AUCell)")
    ) +
    theme_pub +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
      legend.position = "top"
    )
}


# ---- Function: Combined t-SNE + violin panel for one TF ----
plot_combined_tf <- function(tf_name, tf_clean_name, panel_label = "") {
  p1 <- plot_tsne_tf(tf_name, tf_clean_name)
  p2 <- plot_violin_tf(tf_name, tf_clean_name)

  combined <- p1 + p2 +
    plot_layout(widths = c(1, 1.2)) +
    plot_annotation(title = panel_label, theme = theme(plot.title = element_text(
      size = 13, face = "bold", hjust = 0
    )))

  return(combined)
}


# ==========================================
# 7. Main figure: 4 key TFs (matches Fig 6 of reference)
# ==========================================

cat("Generating main Figure 6-style composite...\n")

# Create individual combined panels
panel_list <- list()
for (i in seq_along(top_tfs)) {
  panel_label <- paste0("(", letters[i], ")")
  panel_list[[i]] <- plot_combined_tf(top_tfs[i], top_tf_names[i], panel_label)
}

# Arrange all panels vertically (2 columns x 2 rows)
final_figure <- wrap_plots(panel_list, ncol = 2, nrow = 2)

pdf(OUT_PDF, width = 16, height = 12)
print(final_figure)
dev.off()

png(OUT_PNG, width = 16, height = 12, units = "in", res = 300)
print(final_figure)
dev.off()

cat(sprintf("Main figure saved: %s, %s\n", OUT_PDF, OUT_PNG))


# ==========================================
# 8. Supplementary: Heatmap of all TF regulon activities
# ==========================================

cat("Generating regulon activity heatmap...\n")

# Compute mean AUCell per cell type
top_n_regulons <- min(30, nrow(auc_mtx))
top_var_regulons <- names(sort(auc_var, decreasing = TRUE))[1:top_n_regulons]

cell_type_mean <- matrix(NA, nrow = length(top_var_regulons), ncol = n_types)
rownames(cell_type_mean) <- top_var_regulons
colnames(cell_type_mean) <- sort(unique(cell_types))

for (ct in colnames(cell_type_mean)) {
  ct_cells <- common_cells[cell_types[common_cells] == ct]
  if (length(ct_cells) > 0) {
    cell_type_mean[, ct] <- rowMeans(auc_mtx[top_var_regulons, ct_cells, drop = FALSE])
  }
}

# Clean row names for display
rownames(cell_type_mean) <- tf_names_clean[top_var_regulons]

heatmap_pdf <- file.path(WORK_DIR, "TF_regulon_heatmap.pdf")
heatmap_png <- file.path(WORK_DIR, "TF_regulon_heatmap.png")

pdf(heatmap_pdf, width = 10, height = 12)
pheatmap::pheatmap(
  cell_type_mean,
  scale = "row",
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  color = colorRampPalette(c("navy", "white", "firebrick3"))(100),
  fontsize = 8,
  main = "Mean TF Regulon Activity by Cell Type (AUCell)",
  border_color = NA
)
dev.off()

png(heatmap_png, width = 10, height = 12, units = "in", res = 300)
pheatmap::pheatmap(
  cell_type_mean,
  scale = "row",
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  color = colorRampPalette(c("navy", "white", "firebrick3"))(100),
  fontsize = 8,
  main = "Mean TF Regulon Activity by Cell Type (AUCell)",
  border_color = NA
)
dev.off()

cat(sprintf("Heatmap saved: %s, %s\n", heatmap_pdf, heatmap_png))


# ==========================================
# 9. Supplementary: Group comparison violins
# ==========================================

cat("Generating Control vs Disease comparison...\n")

group_pdf <- file.path(WORK_DIR, "TF_group_comparison.pdf")
pdf(group_pdf, width = 14, height = 4 * ceiling(N_TOP_TFS / 2))

par(mfrow = c(ceiling(N_TOP_TFS / 2), 2))
for (i in seq_along(top_tfs)) {
  tf <- top_tfs[i]
  scores <- auc_mtx[tf, common_cells]
  plot_df <- data.frame(
    Activity = scores,
    CellType = cell_types[common_cells],
    Group = sample_groups[common_cells]
  )

  p <- ggplot(plot_df, aes(x = CellType, y = Activity, fill = Group)) +
    geom_boxplot(outlier.size = 0.3, size = 0.3, alpha = 0.7) +
    scale_fill_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    labs(
      title = paste0(top_tf_names[i], " regulon"),
      x = "",
      y = "AUCell activity"
    ) +
    theme_pub +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7))
  print(p)
}
dev.off()

cat(sprintf("Group comparison saved: %s\n", group_pdf))


# ==========================================
# 10. Export results table
# ==========================================

cat("Exporting TF activity summary...\n")

summary_csv <- file.path(WORK_DIR, "TF_regulon_summary.csv")
write.csv(de_tf_df, summary_csv, row.names = FALSE)
cat(sprintf("TF summary table: %s\n", summary_csv))

# Save Seurat object with SCENIC assay
cat("Saving updated Seurat object...\n")
pbmc <- pbmc_sub
save(pbmc, cellAnn, clusterAnn, sig.markers, file = "Seurat_SCENIC.Rdata")
cat("Done! Seurat_SCENIC.Rdata saved.\n")

cat("\n===========================================\n")
cat("Transcription factor analysis complete!\n")
cat("===========================================\n")
cat("Output files:\n")
cat(sprintf("  %s  — Main figure (t-SNE + violin panels)\n", OUT_PDF))
cat(sprintf("  %s  — Heatmap of all TF regulons\n", heatmap_pdf))
cat(sprintf("  %s  — Control vs Disease boxplots\n", group_pdf))
cat(sprintf("  %s  — TF activity summary table\n", summary_csv))
