##############################################################################
# TF_activity_decoupleR.R — Fast TF activity inference (no pySCENIC DB needed)
# Ulcerative Colitis scRNA-seq
#
# Alternative to pySCENIC. Uses decoupleR + CollecTRI to infer TF activities
# from gene expression. Creates identical-style figures.
#
# Install once:
#   BiocManager::install(c("decoupleR", "OmnipathR"))
#
# CollecTRI: comprehensive TF-target gene interaction database
# Method: weighted mean (wmean) or multivariate linear model (mlm)
##############################################################################

library(Seurat)
library(dplyr)
library(ggplot2)
library(patchwork)
library(Matrix)

# ==========================================
# 0. Configuration
# ==========================================
WORK_DIR  <- "E:/yhb/溃疡/溃疡/12.Seurat"
setwd(WORK_DIR)

SEURAT_RDS <- file.path(WORK_DIR, "Seurat.Rdata")
OUT_PDF    <- file.path(WORK_DIR, "TF_activity_decoupleR.pdf")
OUT_PNG    <- file.path(WORK_DIR, "TF_activity_decoupleR.png")
OUT_CSV    <- file.path(WORK_DIR, "TF_activity_decoupleR.csv")

N_TOP_TFS <- 4

# ==========================================
# 1. Load packages and data
# ==========================================

if (!requireNamespace("decoupleR", quietly = TRUE)) {
  stop("Please install decoupleR: BiocManager::install('decoupleR')")
}
library(decoupleR)

cat("Loading Seurat object...\n")
load(SEURAT_RDS)

# Get normalized expression matrix — KEEP SPARSE to avoid memory explosion
# (174k cells × 27k genes = 35+ GiB if converted to dense)
expr_mat <- GetAssayData(pbmc, assay = "RNA", layer = "data")

# Get t-SNE and cell metadata
tsne_coords <- Embeddings(pbmc, "tsne")
cell_barcodes <- colnames(pbmc)
cell_types <- cellAnn
sample_groups <- pbmc$Type

cat(sprintf("  Expression: %d genes x %d cells (sparse)\n", nrow(expr_mat), ncol(expr_mat)))

# ==========================================
# 2. Get CollecTRI TF regulon network
# ==========================================

cat("Downloading CollecTRI network...\n")

# Use decoupleR's built-in CollecTRI (no OmnipathR needed in newer versions)
# If get_collectri fails, load the bundled version
net <- tryCatch({
  decoupleR::get_collectri(organism = "human", split_complexes = FALSE)
}, error = function(e) {
  cat("  get_collectri() failed. Trying bundled networks...\n")
  # Try collecting from all available decoupleR built-in sources
  dfs <- list()
  # dorothea is often bundled without needing OmnipathR
  for (src in c("collectri", "dorothea")) {
    res <- tryCatch({
      if (src == "collectri") {
        suppressMessages(decoupleR::get_collectri(organism = "human", split_complexes = FALSE))
      } else {
        suppressMessages(decoupleR::get_dorothea(organism = "human", levels = c("A", "B", "C", "D")))
      }
    }, error = function(e2) NULL)
    if (!is.null(res) && nrow(res) > 100) {
      dfs[[src]] <- res
      cat(sprintf("  Got %s: %d rows\n", src, nrow(res)))
    }
  }
  if (length(dfs) > 0) {
    do.call(rbind, dfs)
  } else {
    stop("No TF network available. Install OmnipathR:\n  BiocManager::install('OmnipathR')")
  }
})

cat(sprintf("  Network: %d interactions, %d TFs -> %d targets\n",
            nrow(net), length(unique(net$source)), length(unique(net$target))))

# Filter to TFs and targets present in our expression data
common_genes <- intersect(unique(c(net$source, net$target)), rownames(expr_mat))
net <- net[net$source %in% common_genes & net$target %in% common_genes, ]
cat(sprintf("  After filtering: %d interactions, %d TFs\n",
            nrow(net), length(unique(net$source))))

# ==========================================
# 3. Run TF activity inference (wmean method)
# ==========================================

cat("Inferring TF activities with weighted mean method...\n")

acts <- decoupleR::run_wmean(
  mat = expr_mat,
  network = net,
  .source = "source",
  .target = "target",
  .mor = "mor",
  .likelihood = "likelihood",
  times = 100,
  minsize = 5
)

cat(sprintf("  Inferred activities for %d TFs\n", length(unique(acts$source))))

# Reshape to TF x cell matrix (like AUCell output)
acts_wide <- acts %>%
  dplyr::select(source, condition, score) %>%
  tidyr::pivot_wider(names_from = condition, values_from = score) %>%
  as.data.frame()

rownames(acts_wide) <- acts_wide$source
acts_wide$source <- NULL
act_mtx <- as.matrix(acts_wide)

# Ensure column order matches Seurat
common_cells <- intersect(colnames(act_mtx), cell_barcodes)
act_mtx <- act_mtx[, common_cells, drop = FALSE]

cat(sprintf("  Final matrix: %d TFs x %d cells\n", nrow(act_mtx), ncol(act_mtx)))


# ==========================================
# 4. Add TF activity assay to Seurat
# ==========================================

cat("Adding TF activity assay to Seurat...\n")

pbmc_sub <- subset(pbmc, cells = common_cells)
tf_assay <- CreateAssayObject(data = act_mtx)
pbmc_sub[["TF"]] <- tf_assay
DefaultAssay(pbmc_sub) <- "TF"

# ==========================================
# 5. Select top differential TFs
# ==========================================

cat("Selecting top differential TFs...\n")

tf_var <- apply(act_mtx, 1, var)
tf_var <- sort(tf_var, decreasing = TRUE)

de_results <- list()
for (tf in names(tf_var)[1:min(100, length(tf_var))]) {
  tf_scores <- act_mtx[tf, common_cells]
  ctrl_cells <- common_cells[sample_groups[common_cells] %in%
                              grep("Control", sample_groups[common_cells], value = TRUE)[1]]
  disease_cells <- common_cells[sample_groups[common_cells] %in%
                                grep("Disease", sample_groups[common_cells], value = TRUE)[1]]

  ctrl_idx <- sample_groups[common_cells] %in% unique(grep("Control", sample_groups[common_cells], value = TRUE))
  disease_idx <- sample_groups[common_cells] %in% unique(grep("Disease", sample_groups[common_cells], value = TRUE))

  if (sum(ctrl_idx) > 5 && sum(disease_idx) > 5) {
    test_res <- wilcox.test(tf_scores[disease_idx], tf_scores[ctrl_idx])
    de_results[[tf]] <- data.frame(
      TF         = tf,
      mean_activity = mean(tf_scores),
      var_activity  = tf_var[tf],
      log2FC     = log2(mean(tf_scores[disease_idx]) / mean(tf_scores[ctrl_idx])),
      p_value    = test_res$p.value,
      stringsAsFactors = FALSE
    )
  }
}

de_tf_df <- do.call(rbind, de_results)
de_tf_df$p_adj <- p.adjust(de_tf_df$p_value, method = "BH")
de_tf_df <- de_tf_df[order(de_tf_df$p_value), ]

cat("Top TFs by differential activity:\n")
for (i in seq_len(min(N_TOP_TFS + 4, nrow(de_tf_df)))) {
  cat(sprintf("  %-20s  log2FC=%+.3f  p=%.2e  padj=%.2e\n",
              de_tf_df$TF[i], de_tf_df$log2FC[i],
              de_tf_df$p_value[i], de_tf_df$p_adj[i]))
}

top_tfs <- head(de_tf_df$TF, N_TOP_TFS)

# ==========================================
# 6. Visualization (identical style to reference paper Fig 6)
# ==========================================

cat("Creating figures...\n")

tsne_colors <- c("grey90", "lightblue", "steelblue", "darkblue", "darkred")

n_types <- length(unique(cell_types))
cell_type_colors <- scales::hue_pal()(n_types)

theme_pub <- theme_bw(base_size = 10) +
  theme(
    panel.grid = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, size = 0.5),
    plot.title = element_text(size = 10, face = "bold", hjust = 0.5),
    axis.title = element_text(size = 9),
    axis.text = element_text(size = 8),
    legend.position = "right",
    legend.key.size = unit(0.3, "cm"),
    legend.text = element_text(size = 7),
    legend.title = element_text(size = 8)
  )


plot_tsne_tf <- function(tf_name) {
  scores <- act_mtx[tf_name, common_cells]
  plot_df <- data.frame(
    tSNE_1 = tsne_coords[common_cells, 1],
    tSNE_2 = tsne_coords[common_cells, 2],
    Activity = scores,
    CellType = cell_types[common_cells]
  )
  ggplot(plot_df, aes(x = tSNE_1, y = tSNE_2, color = Activity)) +
    geom_point(size = 0.3, alpha = 0.7) +
    scale_color_gradientn(colors = tsne_colors, name = "Activity") +
    labs(title = bquote(.(tf_name) ~ "activity"), x = "t-SNE 1", y = "t-SNE 2") +
    theme_pub +
    guides(color = guide_colorbar(barwidth = 0.4, barheight = 3))
}


plot_violin_tf <- function(tf_name) {
  scores <- act_mtx[tf_name, common_cells]
  plot_df <- data.frame(
    Activity = scores,
    CellType = factor(cell_types[common_cells]),
    Group = sample_groups[common_cells]
  )
  ggplot(plot_df, aes(x = CellType, y = Activity, fill = CellType)) +
    geom_violin(scale = "width", alpha = 0.7, draw_quantiles = 0.5,
                size = 0.3, color = "grey30") +
    geom_jitter(aes(color = Group), size = 0.15, alpha = 0.3, width = 0.2) +
    scale_fill_manual(values = cell_type_colors, guide = "none") +
    scale_color_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    labs(x = "", y = paste0(tf_name, " activity score")) +
    theme_pub +
    theme(axis.text.x = element_text(angle = 45, hjust = 1, size = 7),
          legend.position = "top")
}


plot_combined <- function(tf_name, panel_label = "") {
  p1 <- plot_tsne_tf(tf_name)
  p2 <- plot_violin_tf(tf_name)
  p1 + p2 + plot_layout(widths = c(1, 1.2)) +
    plot_annotation(title = panel_label,
                    theme = theme(plot.title = element_text(size = 13, face = "bold", hjust = 0)))
}

# Generate panels
panel_list <- list()
for (i in seq_along(top_tfs)) {
  panel_list[[i]] <- plot_combined(top_tfs[i], paste0("(", letters[i], ")"))
}

final_figure <- wrap_plots(panel_list, ncol = 2, nrow = 2)

pdf(OUT_PDF, width = 16, height = 12)
print(final_figure)
dev.off()

png(OUT_PNG, width = 16, height = 12, units = "in", res = 300)
print(final_figure)
dev.off()

cat(sprintf("Figure saved: %s, %s\n", OUT_PDF, OUT_PNG))

# ==========================================
# 7. Export results
# ==========================================

write.csv(de_tf_df, OUT_CSV, row.names = FALSE)
cat(sprintf("Results: %s\n", OUT_CSV))

# Save updated Seurat
pbmc <- pbmc_sub
save(pbmc, cellAnn, clusterAnn, sig.markers, file = "Seurat_TF.Rdata")

cat("\n===========================================\n")
cat("TF activity analysis (decoupleR) complete!\n")
cat("===========================================\n")
cat(sprintf("Main figure: %s\n", OUT_PDF))
cat(sprintf("TF activity table: %s\n", OUT_CSV))

BiocManager::install("OmnipathR", force = TRUE)

library(dorothea)

# 提取 A+B+C 高置信度 regulon
data("dorothea_hs", package = "dorothea")

# 转成 decoupleR 需要的格式
net <- dorothea_hs %>%
  filter(confidence %in% c("A", "B", "C")) %>%
  select(source = tf, target, mor)

cat(sprintf("DoRothEA: %d interactions, %d TFs, %d targets\n",
            nrow(net), length(unique(net$source)), length(unique(net$target))))


# ==========================================
# 3. Run decoupleR TF activity inference
# ==========================================

cat("Running decoupleR (wmean, ulm, mlm)...\n")

# 准备输入：确保基因名匹配
common_genes <- intersect(rownames(expr_mat), unique(c(net$target, net$source)))
cat(sprintf("  Common genes: %d\n", length(common_genes)))

# Run decoupleR — 三个方法
res <- decouple(
  mat = expr_mat,
  network = net,
  .source = source,
  .target = target,
  .mor = mor,
  statistics = c("wmean", "ulm", "mlm"),
  minsize = 5
)

cat(sprintf("  Results: %d rows\n", nrow(res)))

# ==========================================
# 4. Plot top TFs
# ==========================================

# 按每种方法的 score 排序，取 top TFs
res_summary <- res %>%
  group_by(statistic) %>%
  slice_max(order_by = abs(score), n = N_TOP_TFS) %>%
  ungroup()

cat("\nTop TFs by method:\n")
print(as.data.frame(res_summary))

# 提取 TF 活性矩阵用于可视化
act_wmean <- res %>%
  filter(statistic == "wmean") %>%
  select(source, condition, score) %>%
  tidyr::pivot_wider(names_from = condition, values_from = score, values_fill = 0) %>%
  tibble::column_to_rownames("source") %>%
  as.matrix()

cat(sprintf("\nTF activity matrix (wmean): %d TFs x %d conditions\n",
            nrow(act_wmean), ncol(act_wmean)))

# 保存结果
write.csv(res, OUT_CSV, row.names = FALSE)
cat(sprintf("\nResults saved to: %s\n", OUT_CSV))


# 退出调试器后，先设置 SSL 绕过（你的网络环境 Ensembl 证书过期）
httr::set_config(httr::config(ssl_verifypeer = FALSE))

# 然后直接下载 CollecTRI CSV（不需要 OmnipathR）
net <- read.csv("https://raw.githubusercontent.com/saezlab/CollecTRI/main/collectri.csv")
# 或者是 decoupleR 内置的：
# net <- read.csv("https://raw.githubusercontent.com/saezlab/decoupleR/main/inst/extdata/collectri.csv")

# 查看结构
head(net)

# 搜索 OmnipathR 的安装目录和缓存
omnipath_dir <- system.file(package = "OmnipathR")
cat("OmnipathR dir:", omnipath_dir, "\n")

# 列出所有 CSV/RDS/RDA 文件
files <- list.files(omnipath_dir, pattern = "\\.(csv|rds|rda)$", recursive = TRUE, full.names = TRUE)
cat("Data files found:\n")
print(files)

# 也查 decoupleR 的
decouple_dir <- system.file(package = "decoupleR")
files2 <- list.files(decouple_dir, pattern = "\\.(csv|rds|rda)$", recursive = TRUE, full.names = TRUE)
cat("\ndecoupleR data files:\n")
print(files2)

# 查 temp 缓存
temp_files <- list.files(tempdir(), pattern = "collectri|omnipath", ignore.case = TRUE, full.names = TRUE)
cat("\nTemp files:\n")
print(temp_files)

source("E:/yhb/溃疡/溃疡/12.Seurat/TF_analysis_local.R")

# 安装 (只需一次)
install.packages("reticulate")
library(reticulate)
py_install("arboreto")

# 替换 runSCENIC_1 这一步，用 GRNBoost2：
library(SCENIC)
scenicOptions <- initializeScenic(org = "hgnc", dbDir = "cisTarget_databases", nCores = 8)

# 关键：用 arboreto 的 GRNBoost2 代替默认相关性
library(reticulate)
arboreto <- import("arboreto")

exprMatrix <- as.matrix(GetAssayData(seurat_obj, slot = "data"))
tf_names <- getDbTfs(scenicOptions)

# GRNBoost2 跑 regulon (5-15分钟 vs 几小时)
grn <- arboreto$algo$grnboost2(
  expression_data = as.data.frame(t(exprMatrix)),
  tf_names = tf_names
)



# 设置更长的超时和换下载方式
options(timeout = 1800)  # 30分钟超时
options(download.file.method = "libcurl")
options(download.file.extra = "--retry 3 --retry-delay 5 -L")

# 重新下载
download.file(
  "https://resources.aertslab.org/cistarget/motif2tf/motifs-v9-nr.hgnc-m0.001-o0.0.tbl",
  file.path(dbDir, "motifs-v9-nr.hgnc-m0.001-o0.0.tbl")
)
