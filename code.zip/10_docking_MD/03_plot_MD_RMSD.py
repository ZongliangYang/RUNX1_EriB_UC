#!/usr/bin/env python3
"""
分子动力学模拟数据绘图脚本
适用于GROMACS输出文件(.xvg)的可视化
版本：2.0
功能：自动绘制RMSD、Rg、RMSF、SASA、氢键等分析图表
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import glob

# 设置中文字体支持（如果需要显示中文标签）
# plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
# plt.rcParams['axes.unicode_minus'] = False

def read_xvg_file(filename):
    """
    读取.xvg文件，自动处理注释行，并返回时间和数据
    自动检测时间单位并转换为纳秒(ns)
    """
    time_data = []
    value_data = []
    
    try:
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                # 跳过注释行和空行
                if not line or line.startswith('#') or line.startswith('@'):
                    continue
                
                # 分割数据行
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        time_ps = float(parts[0])  # 假设第一列是时间，单位可能是ps
                        value = float(parts[1])    # 假设第二列是数据值
                        time_data.append(time_ps)
                        value_data.append(value)
                    except ValueError:
                        continue
    except FileNotFoundError:
        print(f"错误：文件 {filename} 不存在")
        return None, None
    except Exception as e:
        print(f"读取文件 {filename} 时出错: {e}")
        return None, None
    
    if not time_data:
        print(f"警告：文件 {filename} 中没有有效数据")
        return None, None
    
    # 将时间从皮秒(ps)转换为纳秒(ns)
    time_ns = np.array(time_data) / 1000.0
    values = np.array(value_data)
    
    return time_ns, values

def plot_md_analysis(file_patterns, output_dir="md_plots"):
    """
    批量绘制分子动力学分析图表
    
    参数：
    file_patterns: 字典，键为图表类型，值为文件匹配模式
    output_dir: 输出图片的目录
    """
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 定义每种分析的自定义设置
    plot_settings = {
        'rmsd': {
            'title': 'Root Mean Square Deviation',
            'ylabel': 'RMSD (nm)',
            'colors': ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728'],
            'linewidth': 1.5
        },
        'gyrate': {
            'title': 'Radius of Gyration',
            'ylabel': 'Rg (nm)',
            'colors': ['#9467bd'],
            'linewidth': 1.5
        },
        'rmsf': {
            'title': 'Root Mean Square Fluctuation',
            'ylabel': 'RMSF (nm)',
            'xlabel': 'Residue Number',
            'colors': ['#8c564b'],
            'linewidth': 1.0
        },
        'sasa': {
            'title': 'Solvent Accessible Surface Area',
            'ylabel': 'SASA (nm²)',
            'colors': ['#e377c2'],
            'linewidth': 1.5
        },
        'hbond': {
            'title': 'Hydrogen Bonds',
            'ylabel': 'Number of H-bonds',
            'colors': ['#7f7f7f'],
            'linewidth': 1.5
        }
    }
    
    # 遍历每种分析类型
    for analysis_type, file_pattern in file_patterns.items():
        # 查找匹配的文件
        file_list = glob.glob(file_pattern)
        
        if not file_list:
            print(f"未找到匹配 {file_pattern} 的文件")
            continue
        
        print(f"\n处理 {analysis_type.upper()} 分析...")
        print(f"找到文件: {file_list}")
        
        # 创建图形
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # 绘制每个文件的数据
        for i, filename in enumerate(sorted(file_list)):
            time_ns, values = read_xvg_file(filename)
            
            if time_ns is None or values is None:
                continue
            
            # 获取文件名（不含路径和扩展名）
            base_name = os.path.splitext(os.path.basename(filename))[0]
            
            # 选择颜色
            color_idx = i % len(plot_settings.get(analysis_type, {}).get('colors', ['#1f77b4']))
            color = plot_settings.get(analysis_type, {}).get('colors', ['#1f77b4'])[color_idx]
            
            # 绘制曲线
            if analysis_type == 'rmsf':
                # RMSF通常以残基编号为X轴
                ax.plot(range(1, len(values) + 1), values, 
                       color=color, linewidth=plot_settings.get(analysis_type, {}).get('linewidth', 1.5),
                       label=base_name)
                ax.set_xlabel(plot_settings.get(analysis_type, {}).get('xlabel', 'Residue Number'))
            else:
                # 其他分析以时间为X轴
                ax.plot(time_ns, values, 
                       color=color, linewidth=plot_settings.get(analysis_type, {}).get('linewidth', 1.5),
                       label=base_name)
                ax.set_xlabel('Time (ns)')
            
            # 打印统计信息
            print(f"  {base_name}:")
            print(f"    数据点数: {len(values)}")
            print(f"    平均值: {np.mean(values):.4f}")
            print(f"    标准差: {np.std(values):.4f}")
            print(f"    最小值: {np.min(values):.4f}")
            print(f"    最大值: {np.max(values):.4f}")
        
        # 设置图表属性
        ax.set_ylabel(plot_settings.get(analysis_type, {}).get('ylabel', 'Value'))
        ax.set_title(plot_settings.get(analysis_type, {}).get('title', 'MD Analysis'))
        
        # 添加网格
        ax.grid(True, alpha=0.3, linestyle='--')
        
        # 添加图例
        if len(file_list) > 1:
            ax.legend(loc='best', fontsize=10)
        
        # 自动调整布局
        plt.tight_layout()
        
        # 保存图片
        output_filename = os.path.join(output_dir, f"{analysis_type}_analysis.png")
        plt.savefig(output_filename, dpi=300, bbox_inches='tight')
        print(f"  图表已保存: {output_filename}")
        
        # 显示图片
        plt.show()
        
        # 关闭图形，释放内存
        plt.close(fig)
    
    print(f"\n所有分析完成！图表已保存到 {output_dir} 目录")

def quick_plot_single_file(filename, analysis_type=None):
    """
    快速绘制单个.xvg文件
    """
    if not os.path.exists(filename):
        print(f"错误：文件 {filename} 不存在")
        return
    
    time_ns, values = read_xvg_file(filename)
    
    if time_ns is None or values is None:
        return
    
    # 创建图形
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 判断是否是RMSF（以残基编号为X轴）
    if analysis_type == 'rmsf' or 'rmsf' in filename.lower():
        ax.plot(range(1, len(values) + 1), values, 'b-', linewidth=1.5)
        ax.set_xlabel('Residue Number')
        title = 'Residue RMSF'
        ylabel = 'RMSF (nm)'
    else:
        ax.plot(time_ns, values, 'b-', linewidth=1.5)
        ax.set_xlabel('Time (ns)')
        title = 'MD Analysis'
        
        # 根据文件名猜测分析类型
        if 'rmsd' in filename.lower():
            title = 'Root Mean Square Deviation'
            ylabel = 'RMSD (nm)'
        elif 'gyrate' in filename.lower():
            title = 'Radius of Gyration'
            ylabel = 'Rg (nm)'
        elif 'sasa' in filename.lower():
            title = 'Solvent Accessible Surface Area'
            ylabel = 'SASA (nm²)'
        elif 'hbond' in filename.lower():
            title = 'Hydrogen Bonds'
            ylabel = 'Number of H-bonds'
        else:
            ylabel = 'Value'
    
    # 设置图表属性
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, alpha=0.3, linestyle='--')
    
    # 添加统计信息文本
    stats_text = (f"Mean: {np.mean(values):.4f}\n"
                  f"Std: {np.std(values):.4f}\n"
                  f"Min: {np.min(values):.4f}\n"
                  f"Max: {np.max(values):.4f}")
    
    # 将文本放在右上角
    ax.text(0.98, 0.98, stats_text,
            transform=ax.transAxes,
            verticalalignment='top',
            horizontalalignment='right',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8),
            fontsize=9)
    
    plt.tight_layout()
    
    # 生成输出文件名
    base_name = os.path.splitext(os.path.basename(filename))[0]
    output_filename = f"{base_name}_plot.png"
    plt.savefig(output_filename, dpi=300, bbox_inches='tight')
    
    print(f"图表已保存: {output_filename}")
    plt.show()

def main():
    """
    主函数：定义要分析的文件模式并执行绘图
    """
    print("=" * 60)
    print("分子动力学模拟数据绘图工具")
    print("=" * 60)
    
    # 定义要绘制的文件模式
    # 您可以根据需要修改这些文件模式
    file_patterns = {
        'rmsd': '*rmsd*.xvg',        # 所有RMSD文件
        'gyrate': '*gyrate*.xvg',    # 回旋半径文件
        'rmsf': '*rmsf*.xvg',        # 残基涨落文件
        'sasa': '*sasa*.xvg',        # 溶剂可及表面积文件
        'hbond': '*hbond*.xvg',      # 氢键文件
    }
    
    print("\n将处理以下类型的分析文件：")
    for analysis_type, pattern in file_patterns.items():
        print(f"  {analysis_type}: {pattern}")
    
    # 执行批量绘图
    plot_md_analysis(file_patterns, output_dir="md_analysis_plots")
    
    print("\n" + "=" * 60)
    print("如需快速绘制单个文件，请使用 quick_plot_single_file() 函数")
    print("示例: quick_plot_single_file('rmsd_protein_new.xvg')")
    print("=" * 60)

if __name__ == "__main__":
    # 运行主函数
    main()
    
    # 如果需要快速绘制单个文件，取消下面一行的注释并修改文件名
    # quick_plot_single_file("rmsd_protein_new.xvg")