# Run in Supporting_data. Archived model scores and documented biological labels.
m <- read.csv("Sample_manifest.csv")
a <- readRDS("ML_final.rds")
stopifnot("NNMT" %in% a$genes, !"RUNX1" %in% a$genes,
          identical(a$genes, rownames(a$rf$importance)))
expected <- read.csv("Corrected_AUC.csv")
for (model in names(a$results)) {
  z <- a$results[[model]]$roc
  cohort <- if (endsWith(model,"V1")) "GSE96698" else "GSE134025"
  cols <- colnames(read.delim(paste0(cohort,".normalize.txt"),nrows=1,check.names=FALSE))[-1]
  if (!is.null(names(z$response))) stopifnot(identical(names(z$response),cols))
  y <- m$Positive[match(cols,m$Matrix_column)]
  score <- as.numeric(z$predictor)
  delta <- outer(score[y==1],score[y==0],"-")
  auc <- mean((delta>0)+0.5*(delta==0))
  stopifnot(isTRUE(all.equal(auc,expected$Fixed_direction_AUC[expected$model==model])))
  print(c(model=model,AUC=auc))
}
d <- readRDS("KO_result.rds")$result$diffRegulation
sup <- read.csv("RUNX1_contrast_deg.csv")
stopifnot(identical(d$gene,sup$gene),isTRUE(all.equal(d$p.value,sup$BH_adjusted_P)),
          all(abs(d$foldChange)>0.5),all(d$p.value<0.01))
