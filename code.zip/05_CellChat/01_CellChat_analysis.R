# ==========================================
# CellChat — SEQUENTIAL, no parallel overhead
# ==========================================
library(Seurat)
library(CellChat)
library(dplyr)
library(ggplot2)
library(patchwork)

WORK_DIR  <- "E:/yhb/溃疡/溃疡/12.Seurat"
setwd(WORK_DIR)

SEURAT_RDS <- file.path(WORK_DIR, "Seurat.Rdata")
OUT_DIR    <- file.path(WORK_DIR, "CellChat_Results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

# CRITICAL: sequential — avoids Windows worker-spawning overhead
plan("sequential")

# ==========================================
# 1. Load + downsample
# ==========================================
cat("Loading...\n")
load(SEURAT_RDS)
pbmc$CellType <- cellAnn
DefaultAssay(pbmc) <- "RNA"

cat(sprintf("Cells: %d, Types: %d\n", ncol(pbmc), length(unique(pbmc$CellType))))

# Aggressive downsample: 200 cells per type (7 types × 200 = 1400 cells)
N_MAX <- 200
set.seed(42)
cells_use <- c()
for (ct in unique(pbmc$CellType)) {
  idx <- which(pbmc$CellType == ct)
  n <- min(length(idx), N_MAX)
  cells_use <- c(cells_use, sample(idx, n))
}
pbmc_sub <- pbmc[, cells_use]
cat(sprintf("Subset: %d cells\n", ncol(pbmc_sub)))

# ==========================================
# 2. Split by condition
# ==========================================
cells_ctrl    <- colnames(pbmc_sub)[pbmc_sub$Type == "Control"]
cells_disease <- colnames(pbmc_sub)[pbmc_sub$Type == "Disease"]
cat(sprintf("Control: %d, Disease: %d\n", length(cells_ctrl), length(cells_disease)))

# ==========================================
# 3. Create CellChat objects
# ==========================================
cat("Creating CellChat objects...\n")

cc_ctrl <- createCellChat(
  object   = GetAssayData(pbmc_sub[, cells_ctrl], assay = "RNA", layer = "data"),
  meta     = pbmc_sub@meta.data[cells_ctrl, , drop = FALSE],
  group.by = "CellType"
)
cc_disease <- createCellChat(
  object   = GetAssayData(pbmc_sub[, cells_disease], assay = "RNA", layer = "data"),
  meta     = pbmc_sub@meta.data[cells_disease, , drop = FALSE],
  group.by = "CellType"
)

cc_ctrl@DB    <- CellChatDB.human
cc_disease@DB <- CellChatDB.human

# ==========================================
# 4. Fast pipeline (sequential, no population.size)
# ==========================================
run_fast <- function(cc, label) {
  cat(sprintf("\n--- %s ---\n", label))

  cat("  subsetData\n")
  cc <- subsetData(cc)

  cat("  identifyOverExpressedGenes\n")
  cc <- identifyOverExpressedGenes(cc)

  cat("  identifyOverExpressedInteractions\n")
  cc <- identifyOverExpressedInteractions(cc)

  cat("  computeCommunProb (sequential, ~1-2 min)\n")
  cc <- computeCommunProb(cc, type = "truncatedMean", trim = 0.1,
                          population.size = FALSE, raw.use = TRUE)

  cat("  filterCommunication\n")
  cc <- filterCommunication(cc, min.cells = 10)

  cat("  computeCommunProbPathway\n")
  cc <- computeCommunProbPathway(cc)

  cat("  aggregateNet\n")
  cc <- aggregateNet(cc)

  cat(sprintf("  %s DONE\n", label))
  return(cc)
}

cc_ctrl    <- run_fast(cc_ctrl,    "Control")
cc_disease <- run_fast(cc_disease, "Disease")

# ==========================================
# 5. FIX_V2 — 用公共细胞类型重建CellChat对象
# ==========================================
cat("\nRebuilding with common cell types...\n")

# 确定公共细胞类型
common <- intersect(unique(cc_ctrl@idents), unique(cc_disease@idents))
cat(sprintf("Common: %s\n", paste(common, collapse = ", ")))

# 只保留公共细胞类型的细胞
cells_ctrl_c    <- cells_ctrl[cc_ctrl@meta$CellType %in% common]
cells_disease_c <- cells_disease[cc_disease@meta$CellType %in% common]
cat(sprintf("Control cells: %d, Disease cells: %d\n",
            length(cells_ctrl_c), length(cells_disease_c)))

# 用公共类型重新创建CellChat对象
cc_ctrl_new <- createCellChat(
  object   = GetAssayData(pbmc_sub[, cells_ctrl_c], assay = "RNA", layer = "data"),
  meta     = pbmc_sub@meta.data[cells_ctrl_c, , drop = FALSE],
  group.by = "CellType"
)
cc_disease_new <- createCellChat(
  object   = GetAssayData(pbmc_sub[, cells_disease_c], assay = "RNA", layer = "data"),
  meta     = pbmc_sub@meta.data[cells_disease_c, , drop = FALSE],
  group.by = "CellType"
)

cc_ctrl_new@DB    <- CellChatDB.human
cc_disease_new@DB <- CellChatDB.human

# 重新跑快速pipeline（之前已验证很快）
run_fast <- function(cc, label) {
  cat(sprintf("--- %s ---\n", label))
  cc <- subsetData(cc)
  cc <- identifyOverExpressedGenes(cc)
  cc <- identifyOverExpressedInteractions(cc)
  cat("  computeCommunProb...\n")
  cc <- computeCommunProb(cc, type = "truncatedMean", trim = 0.1,
                          population.size = FALSE, raw.use = TRUE)
  cc <- filterCommunication(cc, min.cells = 10)
  cc <- computeCommunProbPathway(cc)
  cc <- aggregateNet(cc)
  cat(sprintf("  %s DONE\n", label))
  return(cc)
}

cc_ctrl_new    <- run_fast(cc_ctrl_new,    "Control")
cc_disease_new <- run_fast(cc_disease_new, "Disease")

# Now merge should work — both have identical cell type sets
cc_merged <- mergeCellChat(
  list(Control = cc_ctrl_new, Disease = cc_disease_new),
  add.names = c("Control", "Disease")
)
cat("Merged successfully.\n")

# Centrality
cat("Centrality...\n")
cc_ctrl_new    <- netAnalysis_computeCentrality(cc_ctrl_new,    slot.name = "netP")
cc_disease_new <- netAnalysis_computeCentrality(cc_disease_new, slot.name = "netP")

# Save
save(cc_ctrl_new, cc_disease_new, cc_merged,
     file = file.path(OUT_DIR, "CellChat_Objects.Rdata"))
cat("Objects saved.\n")

# ==========================================
# 6. FIGURES
# ==========================================
all_pathways <- unique(c(cc_ctrl_new@netP$pathway_name, cc_disease_new@netP$pathway_name))
cat(sprintf("Pathways: %s\n", paste(all_pathways, collapse = ", ")))

# --- Fig 7a ---
cat("Fig 7a: Information flow...\n")
pdf(file.path(OUT_DIR, "Fig7a_Information_Flow.pdf"), 14, 8)
rankNet(cc_merged, mode = "comparison", stacked = TRUE, do.stat = TRUE,
        font.size = 9, title = "Relative Information Flow: Control vs Disease")
dev.off()
png(file.path(OUT_DIR, "Fig7a_Information_Flow.png"), 14, 8, units = "in", res = 300)
rankNet(cc_merged, mode = "comparison", stacked = TRUE, do.stat = TRUE,
        font.size = 9, title = "Relative Information Flow: Control vs Disease")
dev.off()

# --- Fig 7b: SPP1 network ---
if ("SPP1" %in% all_pathways) {
  cat("Fig 7b: SPP1 network...\n")
  pdf(file.path(OUT_DIR, "Fig7b_SPP1_Network.pdf"), 16, 8)
  par(mfrow = c(1, 2), mar = c(1, 1, 2, 1))
  netVisual_aggregate(cc_ctrl_new, signaling = "SPP1", layout = "circle",
                      vertex.weight = "inDegree", pt.title = 14,
                      title = "Control: SPP1")
  netVisual_aggregate(cc_disease_new, signaling = "SPP1", layout = "circle",
                      vertex.weight = "inDegree", pt.title = 14,
                      title = "Disease: SPP1")
  dev.off()
  png(file.path(OUT_DIR, "Fig7b_SPP1_Network.png"), 16, 8, units = "in", res = 300)
  par(mfrow = c(1, 2), mar = c(1, 1, 2, 1))
  netVisual_aggregate(cc_ctrl_new, signaling = "SPP1", layout = "circle",
                      vertex.weight = "inDegree", pt.title = 14,
                      title = "Control: SPP1")
  netVisual_aggregate(cc_disease_new, signaling = "SPP1", layout = "circle",
                      vertex.weight = "inDegree", pt.title = 14,
                      title = "Disease: SPP1")
  dev.off()
}

# --- Fig 7c: Outgoing ---
cat("Fig 7c: Outgoing...\n")
pathways_sel <- c("SPP1", "VISFATIN", "MIF", "CCL", "CXCL", "VEGF")
pathways_avail <- intersect(pathways_sel, all_pathways)
if (length(pathways_avail) == 0) pathways_avail <- all_pathways[1:min(6, length(all_pathways))]
nc <- min(3, length(pathways_avail))
nr <- ceiling(length(pathways_avail) / nc)
pdf(file.path(OUT_DIR, "Fig7c_Outgoing_Signaling.pdf"), 6 * nc, 5 * nr)
par(mfrow = c(nr, nc))
for (pw in pathways_avail) {
  netAnalysis_signalingRole_network(cc_disease_new, signaling = pw,
                                    width = 5, height = 4, font.size = 8, title = paste0("Disease: ", pw))
}
dev.off()

# --- Fig 7d: Bubble ---
cat("Fig 7d: Bubble...\n")
cell_types_all <- unique(cc_disease_new@idents)
macro_name <- grep("macro|Macro|MACRO|mono|Mono", cell_types_all, value = TRUE)
if (length(macro_name) == 0) macro_name <- cell_types_all[1:min(2, length(cell_types_all))]
pdf(file.path(OUT_DIR, "Fig7d_LR_Bubble.pdf"), 14, 10)
netAnalysis_bubble(cc_disease_new, sources.use = macro_name,
                   targets.use = setdiff(cell_types_all, macro_name),
                   remove.isolate = FALSE,
                   title = "Ligand-Receptor Interactions (Disease)")
dev.off()

# --- Fig 7e: SPP1 expression ---
cat("Fig 7e: SPP1 expression...\n")
spp1_genes <- c("SPP1", "CD44", "ITGAV", "ITGA4", "ITGA9", "ITGA5", "ITGB1", "ITGB5")
genes_plot <- intersect(spp1_genes, rownames(pbmc_sub))
if (length(genes_plot) > 0) {
  p_dot <- DotPlot(pbmc_sub, features = genes_plot, group.by = "CellType",
                   split.by = "Type", cols = c("lightgrey", "darkred"), dot.scale = 8) +
    RotatedAxis() + labs(title = "SPP1 & Receptor Expression") +
    theme(axis.text.x = element_text(angle = 45, hjust = 1),
          panel.border = element_rect(color = "black", fill = NA, linewidth = 0.5))
  ggsave(file.path(OUT_DIR, "Fig7e_SPP1_DotPlot.pdf"), p_dot,
         width = max(10, length(genes_plot) * 1.3), height = 7, dpi = 300)
  n_c <- min(4, length(genes_plot))
  n_r <- ceiling(length(genes_plot) / n_c)
  p_vln <- VlnPlot(pbmc_sub, features = genes_plot, group.by = "CellType",
                   split.by = "Type", pt.size = 0, ncol = n_c) &
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  ggsave(file.path(OUT_DIR, "Fig7e_SPP1_VlnPlot.pdf"), p_vln,
         width = 4 * n_c, height = 3.5 * n_r, dpi = 300, limitsize = FALSE)
}

save(cc_ctrl_new, cc_disease_new, cc_merged,
     file = file.path(OUT_DIR, "CellChat_Objects.Rdata"))

cat("\n=== DONE ===\n")
for (f in list.files(OUT_DIR)) cat(sprintf("  %s\n", f))



source("C:/Users/www18/Desktop/CellChat_fix.R")


cat("Fig 7d: Bubble...\n")
pdf(file.path(OUT_DIR, "Fig7d_LR_Bubble.pdf"), 14, 10)
print(netVisual_bubble(cc_disease_new,
                       sources.use = NULL, targets.use = NULL,
                       remove.isolate = FALSE))
dev.off()

# Check size
sz <- file.info(file.path(OUT_DIR, "Fig7d_LR_Bubble.pdf"))$size
cat(sprintf("Fig7d: %d bytes\n", sz))

# === Re-save ===
cc_merged <- mergeCellChat(
  list(Control = cc_ctrl_new, Disease = cc_disease_new),
  add.names = c("Control", "Disease"))
save(cc_ctrl_new, cc_disease_new, cc_merged,
     file = file.path(OUT_DIR, "CellChat_Objects.Rdata"))

cat("\n=== ALL FILES ===\n")
for (f in list.files(OUT_DIR, pattern = "\\.pdf$")) {
  sz <- file.info(file.path(OUT_DIR, f))$size
  tag <- if (sz > 1000) "OK" else "EMPTY"
  cat(sprintf("  %s  %8d  %s\n", tag, sz, f))
}
cat("=== DONE ===\n")