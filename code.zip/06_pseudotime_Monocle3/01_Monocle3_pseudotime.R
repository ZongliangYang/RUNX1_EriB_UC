# ============================================================
# Part 1: 包安装与加载 [monocle3 GitHub 安装修复]
# ============================================================
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")

# monocle3 必须从 GitHub 安装
if (!require("monocle3", quietly = TRUE)) {
  if (!require("devtools", quietly = TRUE)) install.packages("devtools")
  if (!require("remotes", quietly = TRUE)) install.packages("remotes")
  devtools::install_github("cole-trapnell-lab/monocle3", upgrade = "never")
  library(monocle3)
}

pkgs <- c("Seurat", "SeuratWrappers", "dplyr",
          "ggplot2", "patchwork", "viridis", "ggrepel", "RColorBrewer")
for (pkg in pkgs) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org")
    library(pkg, character.only = TRUE)
  }
}

print(">>> Part 1 完成: 所有包已加载")

# ============================================================
# UC 单细胞拟时序轨迹分析 — Monocle3 + RUNX1 聚焦
# 分析上皮/成纤维/肌细胞在 UC 中的分化与疾病轨迹
# ============================================================
setwd("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析")

# ============================================================
# Part 1: 包安装与加载
# ============================================================
if (!require("BiocManager", quietly = TRUE)) install.packages("BiocManager")

pkgs <- c("monocle3", "Seurat", "SeuratWrappers", "dplyr",
          "ggplot2", "patchwork", "viridis", "ggrepel", "RColorBrewer")
for (pkg in pkgs) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    if (pkg == "monocle3") {
      BiocManager::install("monocle3", update = FALSE, ask = FALSE)
    } else if (pkg == "SeuratWrappers") {
      BiocManager::install("SeuratWrappers", update = FALSE, ask = FALSE)
    } else {
      install.packages(pkg, repos = "https://cloud.r-project.org")
    }
    library(pkg, character.only = TRUE)
  }
}

print(">>> Part 1 完成: 所有包已加载")

# ============================================================
# Part 2: 加载数据
# ============================================================
loaded_obj <- load("Seurat.Rdata")
obj_name <- loaded_obj[1]
scRNA <- get(obj_name)

cell_ann <- read.table("04.cellAnn.txt", header = TRUE, row.names = 1, sep = "\t")
scRNA$celltype <- cell_ann[colnames(scRNA), "labels"]
scRNA$Type <- ifelse(grepl("^Control", scRNA$orig.ident), "Control", "Disease")

DefaultAssay(scRNA) <- "RNA"
dir.create("Trajectory_output", showWarnings = FALSE)

# ============================================================
# Part 3: 工具函数 — Seurat → Monocle3 CDS
# ============================================================
seurat_to_cds <- function(seurat_obj) {
  expr_matrix <- GetAssayData(seurat_obj, assay = "RNA", layer = "counts")
  cell_meta   <- seurat_obj@meta.data
  gene_meta   <- data.frame(
    gene_short_name = rownames(expr_matrix),
    row.names       = rownames(expr_matrix)
  )
  cds <- new_cell_data_set(
    expression_data = expr_matrix,
    cell_metadata   = cell_meta,
    gene_metadata   = gene_meta
  )
  if ("tsne" %in% names(seurat_obj@reductions)) {
    tsne_coords <- Embeddings(seurat_obj, "tsne")
    reducedDims(cds)[["TSNE"]] <- tsne_coords[colnames(cds), ]
  }
  return(cds)
}

print(">>> Part 2-3 完成")

 > # ============================================================
> # Part 4: 上皮细胞轨迹 [修正根节点选择]
  > # ============================================================
> cat("\n========== 拟时序 1: Epithelial cells ==========\n")

========== 拟时序 1: Epithelial cells ==========
  > sc_epi <- subset(scRNA, subset = celltype == "Epithelial cells")
> cds_epi <- seurat_to_cds(sc_epi)
>
  > cds_epi <- preprocess_cds(cds_epi, num_dim = 50, method = "PCA")
> cds_epi <- reduce_dimension(cds_epi, preprocess_method = "PCA", reduction_method = "UMAP")
> cds_epi <- cluster_cells(cds_epi, resolution = 1e-4)
> cds_epi <- learn_graph(cds_epi, use_partition = FALSE, close_loop = FALSE)
>
  > # 稳健根节点选择：选 Control 细胞最多的 PR 节点
  > ctrl_cells <- colnames(sc_epi)[sc_epi$Type == "Control"]
> pr_mat <- cds_epi@principal_graph_aux$UMAP$pr_graph_cell_proj_closest_vertex
> ctrl_vertices <- pr_mat[ctrl_cells, , drop = FALSE]
> all_vertices  <- unique(pr_mat[, 1])
>
  > # 每个PR节点中Control细胞的数量
  > vertex_ctrl_count <- table(ctrl_vertices[, 1])
> # 从Control最多的节点开始尝试
  > valid_root <- names(sort(vertex_ctrl_count, decreasing = TRUE))
>
  > cds_epi <- tryCatch(
    +   order_cells(cds_epi, root_pr_nodes = valid_root[1]),
    cds_myo <- seurat_to_cds(sc_myo)
    cds_myo <- preprocess_cds(cds_myo, num_dim = 50, method = "PCA")
    cds_myo <- reduce_dimension(cds_myo, preprocess_method = "PCA", reduction_method = "UMAP")
    cds_myo <- cluster_cells(cds_myo, resolution = 1e-4)
    cds_myo <- learn_graph(cds_myo, use_partition = FALSE, close_loop = FALSE)
    
    pr_assign <- as.data.frame(cds_myo@principal_graph_aux$UMAP$pr_graph_cell_proj_closest_vertex)
    colnames(pr_assign) <- "vertex"
    pr_assign$cell <- rownames(pr_assign)
    pr_assign$ctrl <- pr_assign$cell %in% colnames(sc_myo)[sc_myo$Type == "Control"]
    
    ctrl_vertex_counts <- sort(table(pr_assign$vertex[pr_assign$ctrl]), decreasing = TRUE)
    root_vertex <- if (length(ctrl_vertex_counts) > 0) names(ctrl_vertex_counts)[1] else unique(pr_assign$vertex)[1]
    pr_nodes <- rownames(cds_myo@principal_graph_aux$UMAP$pr_graph_cell_proj_closest_vertex)
    root_pr <- pr_nodes[as.integer(root_vertex)]
    
    cds_myo <- order_cells(cds_myo, root_pr_nodes = root_pr)
    
    cat(sprintf("  肌细胞轨迹: %d cells, root=%s\n", ncol(cds_myo), root_pr))
    saveRDS(cds_myo, "Trajectory_output/CDS_Myocytes.rds")
    
    print(">>> Part 4-6 完成！")

# ============================================================
# Part 7: 组图 Fig T1 — 上皮细胞轨迹全景 (3合1)
# ============================================================
cat("\n>>> 绘制 Fig T1: 上皮细胞轨迹\n")

# T1A: 轨迹 + pseudotime 着色
p_t1a <- plot_cells(cds_epi, color_cells_by = "pseudotime",
                     label_cell_groups = FALSE,
                     label_branch_points = FALSE,
                     label_roots = TRUE,
                     label_leaves = FALSE,
                     graph_label_size = 3,
                     cell_size = 0.5) +
  scale_color_viridis_c(option = "C") +
  labs(title = "Epithelial Trajectory (Pseudotime)") +
  theme_bw()

# T1B: 轨迹 + RUNX1 表达
cds_epi$RUNX1_expr <- FetchData(sc_epi, "RUNX1")[colnames(cds_epi), "RUNX1"]
p_t1b <- plot_cells(cds_epi, genes = "RUNX1",
                     label_cell_groups = FALSE,
                     cell_size = 0.5) +
  scale_color_gradientn(colors = c("grey90", "gold", "darkorange", "red3", "darkred")) +
  labs(title = "RUNX1 Expression along Epithelial Trajectory") +
  theme_bw()

# T1C: 轨迹 + Disease/Control 分面
cds_epi$Type <- sc_epi@meta.data[colnames(cds_epi), "Type"]
p_t1c <- plot_cells(cds_epi, color_cells_by = "Type",
                     label_cell_groups = FALSE,
                     cell_size = 0.3) +
  scale_color_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
  facet_wrap(~Type) +
  labs(title = "Epithelial Trajectory: Control vs Disease") +
  theme_bw()

p_t1 <- (p_t1a | p_t1b) / p_t1c +
  plot_annotation(
    title = "Fig T1: Epithelial Cell Trajectory in UC",
    subtitle = "RUNX1 log2FC = -0.73 — Epithelial dysfunction along pseudotime",
    theme = theme(plot.title = element_text(size = 15, face = "bold"))
  )

ggsave("Trajectory_output/Fig_T1_Epithelial_Trajectory.pdf",
       p_t1, width = 16, height = 12)

# ============================================================
# Part 8: 组图 Fig T2 — 成纤维细胞轨迹
# ============================================================
cat(">>> 绘制 Fig T2: 成纤维细胞轨迹\n")

cds_fib$RUNX1_expr <- FetchData(sc_fib, "RUNX1")[colnames(cds_fib), "RUNX1"]
cds_fib$Type <- sc_fib@meta.data[colnames(cds_fib), "Type"]

p_t2a <- plot_cells(cds_fib, color_cells_by = "pseudotime",
                     label_cell_groups = FALSE,
                     label_roots = TRUE, cell_size = 0.5) +
  scale_color_viridis_c(option = "D") +
  labs(title = "Fibroblast Trajectory (Pseudotime)") + theme_bw()

p_t2b <- plot_cells(cds_fib, genes = "RUNX1",
                     label_cell_groups = FALSE, cell_size = 0.5) +
  scale_color_gradientn(colors = c("grey90", "gold", "darkorange", "red3", "darkred")) +
  labs(title = "RUNX1 Expression") + theme_bw()

p_t2c <- plot_cells(cds_fib, color_cells_by = "Type",
                     label_cell_groups = FALSE, cell_size = 0.3) +
  scale_color_manual(values = c("Control"="#4DBBD5","Disease"="#E64B35")) +
  facet_wrap(~Type) + labs(title = "Control vs Disease") + theme_bw()

p_t2 <- (p_t2a | p_t2b) / p_t2c +
  plot_annotation(
    title = "Fig T2: Fibroblast Trajectory — Activation without RUNX1 Change",
    subtitle = "RUNX1 log2FC = -0.01 — Pseudotime reflects fibroblast activation state, not RUNX1 variation",
    theme = theme(plot.title = element_text(size = 15, face = "bold"))
  )

ggsave("Trajectory_output/Fig_T2_Fibroblast_Trajectory.pdf",
       p_t2, width = 16, height = 12)

# ============================================================
# Part 9: 组图 Fig T3 — 肌细胞轨迹
# ============================================================
cat(">>> 绘制 Fig T3: 肌细胞轨迹\n")

cds_myo$RUNX1_expr <- FetchData(sc_myo, "RUNX1")[colnames(cds_myo), "RUNX1"]
cds_myo$Type <- sc_myo@meta.data[colnames(cds_myo), "Type"]

p_t3a <- plot_cells(cds_myo, color_cells_by = "pseudotime",
                     label_cell_groups = FALSE,
                     label_roots = TRUE, cell_size = 0.5) +
  scale_color_viridis_c(option = "B") +
  labs(title = "Myocyte Trajectory (Pseudotime)") + theme_bw()

p_t3b <- plot_cells(cds_myo, genes = "RUNX1",
                     label_cell_groups = FALSE, cell_size = 0.5) +
  scale_color_gradientn(colors = c("grey90", "gold", "darkorange", "red3", "darkred")) +
  labs(title = "RUNX1 Expression") + theme_bw()

p_t3c <- plot_cells(cds_myo, color_cells_by = "Type",
                     label_cell_groups = FALSE, cell_size = 0.3) +
  scale_color_manual(values = c("Control"="#4DBBD5","Disease"="#E64B35")) +
  facet_wrap(~Type) + labs(title = "Control vs Disease") + theme_bw()

p_t3 <- (p_t3a | p_t3b) / p_t3c +
  plot_annotation(
    title = "Fig T3: Myocyte Trajectory — Proliferation-driven Remodeling",
    subtitle = "RUNX1 stable high — Pseudotime captures contraction→proliferation switch",
    theme = theme(plot.title = element_text(size = 15, face = "bold"))
  )

ggsave("Trajectory_output/Fig_T3_Myocyte_Trajectory.pdf",
       p_t3, width = 16, height = 12)

# ============================================================
# Part 10: RUNX1 沿拟时序的表达变化曲线
# ============================================================
cat(">>> 绘制 Fig T4: RUNX1 沿拟时序变化\n")

plot_pseudotime_curve <- function(cds, cell_type_label) {
  df <- data.frame(
    pseudotime = pseudotime(cds),
    RUNX1      = cds$RUNX1_expr,
    Type       = cds$Type
  )
  df <- df[!is.na(df$pseudotime) & !is.na(df$RUNX1), ]

  # 分 20 个 bins 平滑
  df$bin <- cut(df$pseudotime, breaks = 20)
  summary_df <- df %>%
    group_by(bin, Type) %>%
    summarise(
      pt_mean   = mean(pseudotime),
      RUNX1_mu  = mean(RUNX1),
      RUNX1_se  = sd(RUNX1) / sqrt(n()),
      n         = n(),
      .groups   = "drop"
    )

  p <- ggplot(summary_df, aes(x = pt_mean, y = RUNX1_mu, color = Type, fill = Type)) +
    geom_ribbon(aes(ymin = RUNX1_mu - RUNX1_se, ymax = RUNX1_mu + RUNX1_se),
                alpha = 0.2, color = NA) +
    geom_line(linewidth = 1.2) +
    geom_point(size = 2) +
    scale_color_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    scale_fill_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    labs(title = paste(cell_type_label),
         x = "Pseudotime", y = "RUNX1 Expression") +
    theme_bw(base_size = 11) +
    theme(plot.title = element_text(face = "bold"))
  return(p)
}

p_t4a <- plot_pseudotime_curve(cds_epi, "Epithelial cells")
p_t4b <- plot_pseudotime_curve(cds_fib, "Fibroblasts")
p_t4c <- plot_pseudotime_curve(cds_myo, "Myocytes")

p_t4 <- p_t4a / p_t4b / p_t4c +
  plot_annotation(
    title = "Fig T4: RUNX1 Expression along Pseudotime",
    subtitle = "20-bin smoothing, ribbon = SEM. Red = Disease, Blue = Control",
    theme = theme(plot.title = element_text(size = 14, face = "bold"))
  )

ggsave("Trajectory_output/Fig_T4_RUNX1_Pseudotime_Curves.pdf",
       p_t4, width = 8, height = 12)

# ============================================================
# Part 11: 沿拟时序的差异基因热图 — 上皮细胞
# ============================================================
cat(">>> 绘制 Fig T5: 拟时序差异基因热图\n")

# 上皮细胞：找沿 pseudotime 显著变化的基因
cds_epi_sub <- cds_epi[, sample(ncol(cds_epi), min(5000, ncol(cds_epi)))]
pr_test <- tryCatch(
  graph_test(cds_epi_sub, neighbor_graph = "principal_graph", cores = 8),
  error = function(e) NULL
)

if (!is.null(pr_test) && nrow(pr_test) > 0) {
  pr_test <- pr_test %>% arrange(q_value)
  pr_sig <- pr_test %>% filter(q_value < 0.01) %>% head(30)

  if (nrow(pr_sig) >= 10) {
    # 热图：沿 pseudotime 的 Top 30 基因表达
    p_t5 <- plot_pseudotime_heatmap(
      cds_epi_sub[rownames(pr_sig), ],
      num_clusters = 3,
      cores = 1,
      show_rownames = TRUE,
      return_heatmap = TRUE
    )

    pdf("Trajectory_output/Fig_T5_Epithelial_Pseudotime_Heatmap.pdf",
        width = 10, height = 8)
    print(p_t5)
    dev.off()
  }
}

# ============================================================
# Part 12: Control vs Disease 沿拟时序的分布密度
# ============================================================
cat(">>> 绘制 Fig T6: 伪时间分布密度\n")

plot_density <- function(cds, cell_type_label) {
  df <- data.frame(
    pseudotime = pseudotime(cds),
    Type       = cds$Type
  )
  df <- df[!is.na(df$pseudotime), ]

  p <- ggplot(df, aes(x = pseudotime, fill = Type, color = Type)) +
    geom_density(alpha = 0.4, linewidth = 1) +
    scale_fill_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    scale_color_manual(values = c("Control" = "#4DBBD5", "Disease" = "#E64B35")) +
    labs(title = paste(cell_type_label),
         x = "Pseudotime", y = "Cell Density") +
    theme_bw(base_size = 11) +
    theme(plot.title = element_text(face = "bold"))
  return(p)
}

p_t6a <- plot_density(cds_epi, "Epithelial cells")
p_t6b <- plot_density(cds_fib, "Fibroblasts")
p_t6c <- plot_density(cds_myo, "Myocytes")

p_t6 <- p_t6a / p_t6b / p_t6c +
  plot_annotation(
    title = "Fig T6: Pseudotime Distribution — Control vs Disease",
    subtitle = "Disease shifts cells toward later pseudotime (pathological state)",
    theme = theme(plot.title = element_text(size = 14, face = "bold"))
  )

ggsave("Trajectory_output/Fig_T6_Pseudotime_Density.pdf",
       p_t6, width = 8, height = 10)

# ============================================================
# Part 13: 汇总输出
# ============================================================
cat("\n========================================================\n")
cat("  拟时序轨迹分析 — 全部完成\n")
cat("========================================================\n\n")
cat("输出目录: Trajectory_output/\n\n")
cat("组图:\n")
cat("  Fig T1: 上皮细胞轨迹全景 (3合1)\n")
cat("  Fig T2: 成纤维细胞轨迹\n")
cat("  Fig T3: 肌细胞轨迹\n")
cat("  Fig T4: RUNX1 沿拟时序变化曲线 (3细胞类型)\n")
cat("  Fig T5: 上皮拟时序差异基因热图\n")
cat("  Fig T6: Control vs Disease 伪时间分布密度\n")
cat("========================================================\n")
