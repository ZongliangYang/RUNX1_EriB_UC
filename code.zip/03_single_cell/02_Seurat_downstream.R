# 1. 加载包
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(harmony)
library(gridExtra)

# 可选：开启多线程进一步加速（根据你的 CPU 调整 workers 数量）
# library(future)
# plan("multisession", workers = 8)

# 2. 参数与工作目录
logFCfilter <- 1
adjPvalFilter <- 0.05
workDir <- "C:\\Users\\www18\\Desktop\\溃疡\\12.Seurat"
setwd(workDir)

# 3. 读取样本并合并（很快）
dirs_sample <- list.dirs(workDir, recursive = FALSE)
sample_names <- basename(dirs_sample)

seurat_list <- lapply(dirs_sample, function(path) {
  counts <- Read10X(data.dir = path)
  CreateSeuratObject(counts = counts, project = basename(path),
                     min.cells = 5, min.features = 100)
})
pbmc <- merge(seurat_list[[1]], y = seurat_list[-1],
              add.cell.ids = sample_names)
rm(seurat_list); gc()

# 4. QC、标准化、高变基因（几分钟）
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")
pbmc <- subset(pbmc, subset = nFeature_RNA > 100 & percent.mt < 10)

pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)
pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 1500)

# 5. 降维聚类（跳过 JackStraw，速度大幅提升）
pbmc <- ScaleData(pbmc)
pbmc <- RunPCA(pbmc, npcs = 20, features = VariableFeatures(pbmc))
pbmc <- RunHarmony(pbmc, "orig.ident")

pcSelect <- 20
pbmc <- FindNeighbors(pbmc, dims = 1:pcSelect)
pbmc <- FindClusters(pbmc, resolution = 0.6)
pbmc <- RunTSNE(pbmc, dims = 1:pcSelect)

# 6. 合并数据层（Seurat v5 必须）
pbmc <- JoinLayers(pbmc)

# 7. 计算所有 cluster 的标记基因（presto 已安装，会自动启用，极快）
pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)

sig.markers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                              (pbmc.markers$p_val_adj < adjPvalFilter), ]
write.table(sig.markers, file = "03.clusterMarkers.txt", sep = "\t",
            row.names = FALSE, quote = FALSE)

# 如果需要之前生成的那些 QC 图和 PCA 图，可以把画图代码加上
# 例如：
# pdf("01.featureViolin.pdf", width=10, height=6.5) ... dev.off()

# 1. 加载包
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(harmony)
library(gridExtra)

# 可选：开启多线程进一步加速（根据你的 CPU 调整 workers 数量）
# library(future)
# plan("multisession", workers = 4)

# 2. 参数与工作目录
logFCfilter <- 1
adjPvalFilter <- 0.05
workDir <- "C:\\Users\\www18\\Desktop\\溃疡\\12.Seurat"
setwd(workDir)

# 3. 读取样本并合并（很快）
dirs_sample <- list.dirs(workDir, recursive = FALSE)
sample_names <- basename(dirs_sample)

seurat_list <- lapply(dirs_sample, function(path) {
  counts <- Read10X(data.dir = path)
  CreateSeuratObject(counts = counts, project = basename(path),
                     min.cells = 5, min.features = 100)
})
pbmc <- merge(seurat_list[[1]], y = seurat_list[-1],
              add.cell.ids = sample_names)
rm(seurat_list); gc()

# 4. QC、标准化、高变基因（几分钟）
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")
pbmc <- subset(pbmc, subset = nFeature_RNA > 100 & percent.mt < 10)

pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)
pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 1500)

# 5. 降维聚类（跳过 JackStraw，速度大幅提升）
pbmc <- ScaleData(pbmc)
pbmc <- RunPCA(pbmc, npcs = 20, features = VariableFeatures(pbmc))
pbmc <- RunHarmony(pbmc, "orig.ident")

pcSelect <- 20
pbmc <- FindNeighbors(pbmc, dims = 1:pcSelect)
pbmc <- FindClusters(pbmc, resolution = 0.6)
pbmc <- RunTSNE(pbmc, dims = 1:pcSelect)

# 6. 合并数据层（Seurat v5 必须）
pbmc <- JoinLayers(pbmc)

# 7. 计算所有 cluster 的标记基因（presto 已安装，会自动启用，极快）
pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)

sig.markers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                              (pbmc.markers$p_val_adj < adjPvalFilter), ]
write.table(sig.markers, file = "03.clusterMarkers.txt", sep = "\t",
            row.names = FALSE, quote = FALSE)

# 如果需要之前生成的那些 QC 图和 PCA 图，可以把画图代码加上
# 例如：
# pdf("01.featureViolin.pdf", width=10, height=6.5) ... dev.off()


# 从这里继续（与你的原代码相同）
pbmc_for_SingleR <- GetAssayData(pbmc, layer = "data")
clusters <- pbmc$seurat_clusters
# 加载参考数据集（确保文件在工作目录下）
ref1 <- get(load("ref_Human_all.RData"))
...


# 1. 关闭多线程计划
plan("sequential")

# 2. 重新运行 NormalizeData 这步（因为之前这步失败了）
pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)

# 3. 继续往下执行剩余的代码（高变基因、PCA、聚类等）
pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 1500)
# ... 后面就是 02.PCA、03.Clustering 以及 JoinLayers 和 FindAllMarkers



# =================================================
# 02. 降维与整合
# =================================================
pbmc <- ScaleData(pbmc)                          # 标准化后必须做
pbmc <- RunPCA(pbmc, npcs = 20, features = VariableFeatures(pbmc))  # 用高变基因跑 PCA
pbmc <- RunHarmony(pbmc, "orig.ident")           # 去除样本批次效应

# 如果想快速保存 PCA 图（可选）
# pdf("02.PCA.pdf", width=7.5, height=5)
# DimPlot(pbmc, reduction="pca")
# dev.off()

# =================================================
# 03. 聚类与可视化
# =================================================
pcSelect <- 20
pbmc <- FindNeighbors(pbmc, dims = 1:pcSelect)   # 构建 KNN 图
pbmc <- FindClusters(pbmc, resolution = 0.6)      # 直接用 0.6（不再用多个分辨率测试）
pbmc <- RunTSNE(pbmc, dims = 1:pcSelect)          # t-SNE 降维

# 保存 t-SNE 图（可选）
pdf("03.cluster.pdf", width=7.5, height=6)
TSNEPlot(pbmc, pt.size=2, label=TRUE)
dev.off()

# 保存聚类结果
write.table(pbmc$seurat_clusters, file="03.Cluster.txt", quote=FALSE, sep="\t", col.names=FALSE)

# =================================================
# 04. 差异分析（presto 加速）
# =================================================
pbmc <- JoinLayers(pbmc)                         # 必须！合并 Seurat v5 的多层数据

# 计算所有 cluster 的差异基因（presto 自动启用，很快）
pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)

# 筛选显著的标记基因（logFC > 1 且 校正 p < 0.05）
sig.markers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                              (pbmc.markers$p_val_adj < adjPvalFilter), ]
write.table(sig.markers, file="03.clusterMarkers.txt", sep="\t", row.names=FALSE, quote=FALSE)

# 如果你还想画热图（耗时但可选）
 top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
 pdf("03.clusterHeatmap.pdf", width=15, height=15)
 DoHeatmap(pbmc, features = top10$gene) + NoLegend()
 dev.off()
 
 
 
 # =====================================================
 # 加载后续需要的包（如果尚未加载）
 # =====================================================
 library(celldex)
 library(SingleR)
 library(monocle)
 library(clustree)
 library(assertthat)
 library(SCpubr)
 
 # =====================================================
 # 04. SingleR 自动注释细胞类型
 # =====================================================
 
 # 提取标准化后的表达矩阵
 pbmc_for_SingleR <- GetAssayData(pbmc, layer = "data")
 
 # 获取每个细胞的聚类编号
 clusters <- pbmc$seurat_clusters
 
 # 加载参考数据集
 ref1 <- get(load("ref_Human_all.RData"))
 ref2 <- get(load("ref_Hematopoietic.RData"))
 ref3 <- get(load("DatabaseImmuneCellExpressionData.Rdata"))
 ref4 <- get(load("BlueprintEncode_bpe.se_human.RData"))
 ref5 <- get(load("HumanPrimaryCellAtlas_hpca.se_human.RData"))
 ref6 <- get(load("MonacoImmuneData.Rdata"))
 ref7 <- get(load("NovershternHematopoieticData.Rdata"))
 
 # 用多种参考做 SingleR 注释（结果按 cluster 汇总）
 singler <- SingleR(test = pbmc_for_SingleR,
                    ref = list(ref1, ref2, ref3, ref4, ref5, ref6, ref7),
                    labels = list(ref1$label.main, ref2$label.main, ref3$label.main,
                                  ref4$label.main, ref5$label.main, ref6$label.main,
                                  ref7$label.main),
                    clusters = clusters)
 
 # 整理注释标签
 singler$labels <- gsub("_|-", " ", singler$labels)
 singler$labels <- gsub("T cells, CD4\\+", "CD4+ T cells", singler$labels)
 singler$labels <- gsub("T cells, CD8\\+", "CD8+ T cells", singler$labels)
 
 # 保存 cluster 级别的注释
 clusterAnn <- as.data.frame(singler)
 clusterAnn <- cbind(id = rownames(clusterAnn), clusterAnn)
 clusterAnn <- clusterAnn[, c("id", "labels")]
 write.table(clusterAnn, file = "04.clusterAnn.txt", quote = FALSE, sep = "\t", row.names = FALSE)
 
 # 生成每个细胞的注释
 cellAnn <- clusterAnn[match(pbmc$seurat_clusters, clusterAnn$id), "labels"]
 cellAnnOut <- cbind(Cell = colnames(pbmc), labels = cellAnn)
 write.table(cellAnnOut, file = "04.cellAnn.txt", quote = FALSE, sep = "\t", row.names = FALSE)
 
 # 将注释应用到 Seurat 对象的 ident
 newLabels <- singler$labels
 names(newLabels) <- levels(pbmc)
 pbmc <- RenameIdents(pbmc, newLabels)
 
 # 可视化细胞类型注释（t-SNE）
 pdf("04.cellAnn.pdf", width = 8, height = 6)
 TSNEPlot(pbmc, pt.size = 2, label = TRUE)
 dev.off()
 
 # 添加样本类型（Control / Disease）
 # 根据样本名前缀自动判断
 pbmc$Type <- ifelse(grepl("^Control", pbmc$orig.ident), "Control", "Disease")
 
 # 按样本类型分组的 t-SNE 图
 pdf("04.group.cellAnn.pdf", width = 12, height = 6)
 TSNEPlot(pbmc, pt.size = 1, label = TRUE, split.by = "Type")
 dev.off()
 
 # =====================================================
 # 05. 各细胞类型的差异基因（Control vs Disease）
 # =====================================================
 
 # 基于细胞类型（当前 ident）找标记基因
 pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                                logfc.threshold = logFCfilter)
 sig.cellMarkers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                                   (pbmc.markers$p_val_adj < adjPvalFilter), ]
 write.table(sig.cellMarkers, file = "04.cellMarkers.txt", sep = "\t", row.names = FALSE, quote = FALSE)
 
 # 构建分组信息：样本类型 + 细胞类型
 pbmc$group <- paste0(pbmc$Type, "_", cellAnn)
 
 # 对每种细胞类型，比较 Control 和 Disease 的差异基因
 for (cellName in unique(cellAnn)) {
   conName <- paste0("Control_", cellName)
   treatName <- paste0("Disease_", cellName)
   # 确保两组都有足够细胞数
   if (sum(pbmc$group == conName) > 5 && sum(pbmc$group == treatName) > 5) {
     markers <- FindMarkers(pbmc, ident.1 = treatName, ident.2 = conName,
                            group.by = "group", logfc.threshold = 0.1)
     sig.markersGroup <- markers[(abs(markers$avg_log2FC) > logFCfilter) &
                                   (markers$p_val_adj < adjPvalFilter), ]
     sig.markersGroup <- cbind(Gene = rownames(sig.markersGroup), sig.markersGroup)
     write.table(sig.markersGroup,
                 file = paste0("05.", cellName, ".diffGene.txt"),
                 sep = "\t", row.names = FALSE, quote = FALSE)
   } else {
     message("Skipping ", cellName, " (too few cells in one group)")
   }
 }
 
 # =====================================================
 # 保存最终结果
 # =====================================================
 save(pbmc, cellAnn, clusterAnn, sig.markers, file = "Seurat.Rdata")