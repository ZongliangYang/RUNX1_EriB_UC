#install.packages("clustree")
#install.packages("Seurat")
#install.packages("harmony")
#install.packages("gridExtra")

#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("GSVA")
#BiocManager::install("GSEABase")
#BiocManager::install("limma")
#BiocManager::install("scrapper")
#BiocManager::install("SingleR")
#BiocManager::install("celldex")
#BiocManager::install("monocle")

#install.packages("devtools")
#devtools::install_github('immunogenomics/presto')

#install.packages("assertthat")
#install.packages("SCpubr")


#######################01.????ǰ?ڴ????ͽ???#######################
#???ð?
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)
library(clustree)
library(harmony)
library(assertthat)
library(SCpubr)
library(gridExtra)

logFCfilter=1           #logFC?Ĺ???????
adjPvalFilter=0.05     #????????pvalue?Ĺ???????

#???ù???Ŀ¼
workDir="C:\\Users\\www18\\Desktop\\溃疡\\12.Seurat"
setwd(workDir)

#??ȡ????
dirs=list.dirs(workDir)
dirs_sample=dirs[-1]
names(dirs_sample)=gsub(".+\\/(.+)", "\\1", dirs_sample)
counts <- Read10X(data.dir = dirs_sample)
pbmc = CreateSeuratObject(counts, min.cells=5, min.features=100)

#ʹ??PercentageFeatureSet??????????��???????İٷֱ?
pbmc[["percent.mt"]] <- PercentageFeatureSet(object = pbmc, pattern = "^MT-")
#???ƻ?????????С????ͼ
pdf(file="01.featureViolin.pdf", width=10, height=6.5)
# ?ֱ?????3??С????ͼ???Ƴ?ÿ??ͼ??ͼ??
p1 <- VlnPlot(pbmc, features = "nFeature_RNA", raster = FALSE) + theme(legend.position = "none")
p2 <- VlnPlot(pbmc, features = "nCount_RNA", raster = FALSE) + theme(legend.position = "none")
p3 <- VlnPlot(pbmc, features = "percent.mt", raster = FALSE) + theme(legend.position = "none")
grid.arrange(p1, p2, p3, ncol = 3)
dev.off()
pbmc=subset(x = pbmc, subset = nFeature_RNA > 100 & percent.mt < 10)    #?????ݽ??й???

#???Ʋ????????????Ե?ͼ??
pdf(file="01.featureCor.pdf", width=13, height=7)
plot1 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "nFeature_RNA",pt.size=1.5)
plot2 <- FeatureScatter(object = pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt",,pt.size=1.5)
CombinePlots(plots = list(plot1, plot2))
dev.off()

#?????ݽ??б?׼??
pbmc <- NormalizeData(object=pbmc, normalization.method="LogNormalize", scale.factor=10000)
#??ȡϸ????????ϵ???ϴ??Ļ???
pbmc <- FindVariableFeatures(object=pbmc, selection.method="vst", nfeatures=1500)
#????????????ͼ
top10 <- head(x = VariableFeatures(object = pbmc), 10)
pdf(file="01.featureVar.pdf", width=10, height=6)
plot1 <- VariableFeaturePlot(object = pbmc)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
CombinePlots(plots = list(plot1, plot2))
dev.off()



#######################02.PCA???ɷַ???#######################
##PCA????
pbmc=ScaleData(pbmc)        #PCA??ά֮ǰ?ı?׼Ԥ???���??
pbmc=RunPCA(object= pbmc, npcs=20, pc.genes=VariableFeatures(object=pbmc))     #PCA????
pbmc=RunHarmony(pbmc, "orig.ident")

#????ÿ??PCA?ɷֵ?????????
pdf(file="02.pcaGene.pdf", width=10, height=8)
VizDimLoadings(object = pbmc, dims = 1:4, reduction = "pca", nfeatures=20)
dev.off()

#????PCAͼ??
pdf(file="02.PCA.pdf", width=7.5, height=5)
DimPlot(object=pbmc, reduction="pca")
dev.off()

#PCA????ͼ
pdf(file="02.pcaHeatmap.pdf", width=10, height=8)
DimHeatmap(object=pbmc, dims=1:4, cells=500, balanced=TRUE, nfeatures=30, ncol=2)
dev.off()

#?õ?ÿ??PC??pֵ?ֲ?
pbmc <- JackStraw(object=pbmc, num.replicate=100)
pbmc <- ScoreJackStraw(object = pbmc, dims = 1:20)
pdf(file="02.pcaJackStraw.pdf",width=8,height=6)
JackStrawPlot(object=pbmc, dims=1:20)
dev.off()



#######################03.ϸ????????????marker????#######################
##????????
pcSelect=20
pbmc <- FindNeighbors(object = pbmc, dims = 1:pcSelect)     #?????ڽӾ???

#??ϸ??????,??ϸ????׼ģ?黯
pbmc <- FindClusters(pbmc, resolution=seq(0.5, 1.2, by=0.1))
pbmc <- FindClusters(object = pbmc, resolution=0.6)
#????????ͼ??
pdf(file="03.cluster.pdf", width=7.5, height=6)
#pbmc <-RunUMAP(object = pbmc, dims = 1:pcSelect)        #UMAP????
#DimPlot(pbmc, reduction = "umap", pt.size = 2, label = TRUE)      #UMAP???ӻ?
pbmc <- RunTSNE(object = pbmc, dims = 1:pcSelect)             #TSNE????
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)     #TSNE???ӻ?
dev.off()
write.table(pbmc$seurat_clusters,file="03.Cluster.txt",quote=F,sep="\t",col.names=F)

##????ÿ???????Ĳ???????
pbmc.markers <- FindAllMarkers(object = pbmc,
                               only.pos = FALSE,
                               min.pct = 0.25,
                               logfc.threshold = logFCfilter)
sig.markers=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]
write.table(sig.markers,file="03.clusterMarkers.txt",sep="\t",row.names=F,quote=F)

top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
#????marker??ÿ??????????ͼ
pdf(file="03.clusterHeatmap.pdf",width=15, height=15)
DoHeatmap(object = pbmc, features = top10$gene) + NoLegend()
dev.off()



#######################04.SingleR R??ע??ϸ??????#######################
pbmc_for_SingleR <- GetAssayData(pbmc, layer="data")
clusters<-pbmc@meta.data$seurat_clusters
ref1=get(load("ref_Human_all.RData"))
ref2=get(load("ref_Hematopoietic.RData"))
ref3=get(load("DatabaseImmuneCellExpressionData.Rdata"))
ref4=get(load("BlueprintEncode_bpe.se_human.RData"))
ref5=get(load("HumanPrimaryCellAtlas_hpca.se_human.RData"))
ref6=get(load("MonacoImmuneData.Rdata"))
ref7=get(load("NovershternHematopoieticData.Rdata"))
singler=SingleR(test=pbmc_for_SingleR, ref =list(ref1, ref2, ref3, ref4, ref5, ref6, ref7),
              labels=list(ref1$label.main,ref2$label.main,ref3$label.main,ref4$label.main,ref5$label.main,ref6$label.main,ref7$label.main), clusters = clusters)

singler$labels=gsub("_|-", " ", singler$labels)
singler$labels=gsub("T cells, CD4\\+", "CD4+ T cells", singler$labels)
singler$labels=gsub("T cells, CD8\\+", "CD8+ T cells", singler$labels)
clusterAnn=as.data.frame(singler)
clusterAnn=cbind(id=row.names(clusterAnn), clusterAnn)
clusterAnn=clusterAnn[,c("id", "labels")]
write.table(clusterAnn,file="04.clusterAnn.txt",quote=F,sep="\t", row.names=F)

#????ϸ??ע?͵Ľ???
cellAnn <- clusterAnn[match(pbmc$seurat_clusters, clusterAnn[,1]), 2]
cellAnnOut=cbind(names(pbmc$seurat_clusters), cellAnn)
colnames(cellAnnOut)=c("id", "labels")
write.table(cellAnnOut, file="04.cellAnn.txt", quote=F, sep="\t", row.names=F)

#ϸ??ע?ͺ??Ŀ??ӻ?
newLabels=singler$labels
names(newLabels)=levels(pbmc)
pbmc=RenameIdents(pbmc, newLabels)
pdf(file="04.cellAnn.pdf", width=8, height=6)
#DimPlot(pbmc, reduction = "umap", pt.size = 2, label = TRUE)     #UMAP???ӻ?
TSNEPlot(object = pbmc, pt.size = 2, label = TRUE)           #TSNE???ӻ?
dev.off()
#???????ӻ?
Type=gsub("(.*?)\\..*", "\\1", colnames(pbmc))
names(Type)=colnames(pbmc)
pbmc=AddMetaData(object=pbmc, metadata=Type, col.name="Type")
pdf(file="04.group.cellAnn.pdf", width=12, height=6)
#DimPlot(pbmc, reduction = "umap", pt.size = 2, label = TRUE, split.by="Type")       #UMAP???ӻ?
TSNEPlot(object = pbmc, pt.size = 1, label = TRUE, split.by="Type")     #TSNE???ӻ?
dev.off()

#ϸ?????͵Ĳ???????
pbmc.markers=FindAllMarkers(object = pbmc,
                            only.pos = FALSE,
                            min.pct = 0.25,
                            logfc.threshold = logFCfilter)
sig.cellMarkers=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]
write.table(sig.cellMarkers,file="04.cellMarkers.txt",sep="\t",row.names=F,quote=F)

#ϸ??????????????
groups=gsub("(.*?)\\..*", "\\1", colnames(pbmc))
groups=paste0(groups, "_", cellAnn)
names(groups)=colnames(pbmc)
pbmc=AddMetaData(object=pbmc, metadata=groups, col.name="group")
for(cellName in unique(cellAnn)){
	conName=paste0("Control_", cellName)
	treatName=paste0("Disease_", cellName)
	if( (length(groups[groups==conName])>5) & (length(groups[groups==treatName])>5) ){
		pbmc.markers=FindMarkers(pbmc, ident.1=treatName, ident.2=conName, group.by='group', logfc.threshold=0.1)
		sig.markersGroup=pbmc.markers[(abs(as.numeric(as.vector(pbmc.markers$avg_log2FC)))>logFCfilter & as.numeric(as.vector(pbmc.markers$p_val_adj))<adjPvalFilter),]
		sig.markersGroup=cbind(Gene=row.names(sig.markersGroup), sig.markersGroup)
		write.table(sig.markersGroup,file=paste0("05.", cellName, ".diffGene.txt"),sep="\t",row.names=F,quote=F)
	}
}

#???浥ϸ?????ݵĶ???
save(pbmc, cellAnn, clusterAnn, sig.markers, file="Seurat.Rdata")


######??????ѧ??: https://www.biowolf.cn/
######?γ?��??1: https://shop119322454.taobao.com
######?γ?��??2: https://ke.biowolf.cn
######?γ?��??3: https://ke.biowolf.cn/mobile
######?⿡??ʦ????: seqbio@foxmail.com
######?⿡??ʦ΢??: eduBio

# Load packages
library(limma)
library(Seurat)
library(dplyr)
library(magrittr)
library(celldex)
library(SingleR)
library(monocle)
library(clustree)
library(harmony)
library(assertthat)
library(SCpubr)
library(gridExtra)

logFCfilter <- 1
adjPvalFilter <- 0.05

# Set working directory
workDir <- "C:\\Users\\www18\\Desktop\\溃疡\\12.Seurat"
setwd(workDir)

# Get sample directories (first-level subdirectories)
dirs_sample <- list.dirs(workDir, recursive = FALSE)
sample_names <- basename(dirs_sample)

# Read each sample separately and merge
seurat_list <- lapply(dirs_sample, function(path) {
  counts <- Read10X(data.dir = path)
  CreateSeuratObject(counts = counts, project = basename(path), 
                     min.cells = 5, min.features = 100)
})
pbmc <- merge(seurat_list[[1]], y = seurat_list[-1], 
              add.cell.ids = sample_names)
rm(seurat_list); gc()

# QC metrics
pbmc[["percent.mt"]] <- PercentageFeatureSet(pbmc, pattern = "^MT-")

# Violin plot
pdf("01.featureViolin.pdf", width = 10, height = 6.5)
p1 <- VlnPlot(pbmc, features = "nFeature_RNA", raster = FALSE) + NoLegend()
p2 <- VlnPlot(pbmc, features = "nCount_RNA", raster = FALSE) + NoLegend()
p3 <- VlnPlot(pbmc, features = "percent.mt", raster = FALSE) + NoLegend()
grid.arrange(p1, p2, p3, ncol = 3)
dev.off()

# Subset
pbmc <- subset(pbmc, subset = nFeature_RNA > 100 & percent.mt < 10)

# Scatter plot
pdf("01.featureCor.pdf", width = 13, height = 7)
plot1 <- FeatureScatter(pbmc, feature1 = "nCount_RNA", feature2 = "nFeature_RNA", pt.size = 1.5)
plot2 <- FeatureScatter(pbmc, feature1 = "nCount_RNA", feature2 = "percent.mt", pt.size = 1.5)
grid.arrange(plot1, plot2, ncol = 2)  # replaced CombinePlots
dev.off()

# Normalization and variable features
pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)
pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 1500)

top10 <- head(VariableFeatures(pbmc), 10)
pdf("01.featureVar.pdf", width = 10, height = 6)
plot1 <- VariableFeaturePlot(pbmc)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
grid.arrange(plot1, plot2, ncol = 2)
dev.off()

####################### 02. PCA #######################
pbmc <- ScaleData(pbmc)
pbmc <- RunPCA(pbmc, npcs = 20, features = VariableFeatures(pbmc))
pbmc <- RunHarmony(pbmc, "orig.ident")

pdf("02.pcaGene.pdf", width = 10, height = 8)
VizDimLoadings(pbmc, dims = 1:4, reduction = "pca", nfeatures = 20)
dev.off()

pdf("02.PCA.pdf", width = 7.5, height = 5)
DimPlot(pbmc, reduction = "pca")
dev.off()

pdf("02.pcaHeatmap.pdf", width = 10, height = 8)
DimHeatmap(pbmc, dims = 1:4, cells = 500, balanced = TRUE, nfeatures = 30, ncol = 2)
dev.off()

# JackStraw (may be slow; consider ElbowPlot as alternative)
pbmc <- JackStraw(pbmc, num.replicate = 100)
pbmc <- ScoreJackStraw(pbmc, dims = 1:20)
pdf("02.pcaJackStraw.pdf", width = 8, height = 6)
JackStrawPlot(pbmc, dims = 1:20)
dev.off()

####################### 03. Clustering & markers #######################
pcSelect <- 20
pbmc <- FindNeighbors(pbmc, dims = 1:pcSelect)
pbmc <- FindClusters(pbmc, resolution = seq(0.5, 1.2, by = 0.1))
pbmc <- FindClusters(pbmc, resolution = 0.6)

pdf("03.cluster.pdf", width = 7.5, height = 6)
pbmc <- RunTSNE(pbmc, dims = 1:pcSelect)
TSNEPlot(pbmc, pt.size = 2, label = TRUE)
dev.off()

write.table(pbmc$seurat_clusters, file = "03.Cluster.txt", quote = FALSE, sep = "\t", col.names = FALSE)

# Find all cluster markers
pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)
sig.markers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                              (pbmc.markers$p_val_adj < adjPvalFilter), ]
write.table(sig.markers, file = "03.clusterMarkers.txt", sep = "\t", row.names = FALSE, quote = FALSE)

top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 10, wt = avg_log2FC)
pdf("03.clusterHeatmap.pdf", width = 15, height = 15)
DoHeatmap(pbmc, features = top10$gene) + NoLegend()
dev.off()

####################### 04. SingleR annotation #######################
pbmc_for_SingleR <- GetAssayData(pbmc, layer = "data")
clusters <- pbmc$seurat_clusters

# Load reference datasets (ensure files exist in working directory)
ref1 <- get(load("ref_Human_all.RData"))
ref2 <- get(load("ref_Hematopoietic.RData"))
ref3 <- get(load("DatabaseImmuneCellExpressionData.Rdata"))
ref4 <- get(load("BlueprintEncode_bpe.se_human.RData"))
ref5 <- get(load("HumanPrimaryCellAtlas_hpca.se_human.RData"))
ref6 <- get(load("MonacoImmuneData.Rdata"))
ref7 <- get(load("NovershternHematopoieticData.Rdata"))

singler <- SingleR(test = pbmc_for_SingleR,
                   ref = list(ref1, ref2, ref3, ref4, ref5, ref6, ref7),
                   labels = list(ref1$label.main, ref2$label.main, ref3$label.main,
                                 ref4$label.main, ref5$label.main, ref6$label.main,
                                 ref7$label.main),
                   clusters = clusters)

singler$labels <- gsub("_|-", " ", singler$labels)
singler$labels <- gsub("T cells, CD4\\+", "CD4+ T cells", singler$labels)
singler$labels <- gsub("T cells, CD8\\+", "CD8+ T cells", singler$labels)

clusterAnn <- as.data.frame(singler)
clusterAnn <- cbind(id = rownames(clusterAnn), clusterAnn)
clusterAnn <- clusterAnn[, c("id", "labels")]
write.table(clusterAnn, file = "04.clusterAnn.txt", quote = FALSE, sep = "\t", row.names = FALSE)

# Cell-level annotation
cellAnn <- clusterAnn[match(pbmc$seurat_clusters, clusterAnn$id), "labels"]
cellAnnOut <- cbind(Cell = colnames(pbmc), labels = cellAnn)
write.table(cellAnnOut, file = "04.cellAnn.txt", quote = FALSE, sep = "\t", row.names = FALSE)

# Visualize annotation
newLabels <- singler$labels
names(newLabels) <- levels(pbmc)
pbmc <- RenameIdents(pbmc, newLabels)

pdf("04.cellAnn.pdf", width = 8, height = 6)
TSNEPlot(pbmc, pt.size = 2, label = TRUE)
dev.off()

# Add sample group type (using orig.ident from merged data)
pbmc$Type <- pbmc$orig.ident  # each sample name directly, no need to parse
pdf("04.group.cellAnn.pdf", width = 12, height = 6)
TSNEPlot(pbmc, pt.size = 1, label = TRUE, split.by = "Type")
dev.off()



pbmc <- JoinLayers(pbmc)

pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)
sig.markers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                              (pbmc.markers$p_val_adj < adjPvalFilter), ]
# Markers per cell type
pbmc.markers <- FindAllMarkers(pbmc, only.pos = FALSE, min.pct = 0.25,
                               logfc.threshold = logFCfilter)
sig.cellMarkers <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                                  (pbmc.markers$p_val_adj < adjPvalFilter), ]
write.table(sig.cellMarkers, file = "04.cellMarkers.txt", sep = "\t", row.names = FALSE, quote = FALSE)

# Differential expression by group within each cell type
pbmc$group <- paste0(pbmc$Type, "_", cellAnn)
for (cellName in unique(cellAnn)) {
  conName <- paste0("Control_", cellName)
  treatName <- paste0("Disease_", cellName)
  if (sum(pbmc$group == conName) > 5 && sum(pbmc$group == treatName) > 5) {
    pbmc.markers <- FindMarkers(pbmc, ident.1 = treatName, ident.2 = conName,
                                group.by = "group", logfc.threshold = 0.1)
    sig.markersGroup <- pbmc.markers[(abs(pbmc.markers$avg_log2FC) > logFCfilter) &
                                       (pbmc.markers$p_val_adj < adjPvalFilter), ]
    sig.markersGroup <- cbind(Gene = rownames(sig.markersGroup), sig.markersGroup)
    write.table(sig.markersGroup,
                file = paste0("05.", cellName, ".diffGene.txt"),
                sep = "\t", row.names = FALSE, quote = FALSE)
  }
}

# Save the final object
save(pbmc, cellAnn, clusterAnn, sig.markers, file = "Seurat.Rdata")


