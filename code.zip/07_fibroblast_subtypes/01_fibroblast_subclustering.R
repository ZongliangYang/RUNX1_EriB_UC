# ============================================================
# UC 成纤维细胞亚群细分 — 高分辨率聚类 + 功能注释
# 目的: 解析 RUNX1 驱动的成纤维异质性
# ============================================================
setwd("C:/Users/www18/Desktop/溃疡/2-1 SCENIC转录因子分析/2-1 SCENIC转录因子分析")

library(Seurat)
library(dplyr)
library(ggplot2)
library(patchwork)
library(viridis)
library(ggrepel)
library(RColorBrewer)
library(ComplexHeatmap)
library(circlize)

dir.create("Fibroblast_Subtypes", showWarnings = FALSE)

# ============================================================
# Part 1: 提取成纤维细胞 + 重聚类
# ============================================================
loaded_obj <- load("Seurat.Rdata")
obj_name <- loaded_obj[1]
scRNA <- get(obj_name)

cell_ann <- read.table("04.cellAnn.txt", header=TRUE, row.names=1, sep="\t")
scRNA$celltype <- cell_ann[colnames(scRNA), "labels"]
scRNA$Type <- ifelse(grepl("^Control", scRNA$orig.ident), "Control", "Disease")

DefaultAssay(scRNA) <- "RNA"

# 提取成纤维细胞
sc_fib <- subset(scRNA, subset = celltype == "Fibroblasts")
cat(sprintf("成纤维细胞总数: %d (Control=%d, Disease=%d)\n",
            ncol(sc_fib), sum(sc_fib$Type=="Control"), sum(sc_fib$Type=="Disease")))

# 标准化 + 高变基因 + 缩放
sc_fib <- NormalizeData(sc_fib, normalization.method = "LogNormalize")
sc_fib <- FindVariableFeatures(sc_fib, nfeatures = 2000)
sc_fib <- ScaleData(sc_fib)
sc_fib <- RunPCA(sc_fib, npcs = 30)
sc_fib <- RunUMAP(sc_fib, dims = 1:20)
sc_fib <- RunTSNE(sc_fib, dims = 1:20)
sc_fib <- FindNeighbors(sc_fib, dims = 1:20)
sc_fib <- FindClusters(sc_fib, resolution = 0.8)  # 高分辨细分

cat(sprintf("亚群数量: %d\n", length(unique(sc_fib$seurat_clusters))))
cat("各亚群细胞数:\n")
print(table(sc_fib$seurat_clusters))

print(">>> Part 1 完成: 成纤维重聚类")

# ============================================================
# Part 2: 亚群标记基因 + 功能注释
# ============================================================
Idents(sc_fib) <- "seurat_clusters"
fib_markers <- FindAllMarkers(sc_fib, only.pos = TRUE, min.pct = 0.25,
                               logfc.threshold = 0.25, test.use = "wilcox")
saveRDS(fib_markers, "Fibroblast_Subtypes/fibroblast_markers.rds")

# 每个亚群 Top 10 标记基因
top10_markers <- fib_markers %>%
  group_by(cluster) %>%
  top_n(n = 10, wt = avg_log2FC)

cat("\n各亚群 Top 5 标记基因:\n")
top5 <- fib_markers %>% group_by(cluster) %>% top_n(n=5, wt=avg_log2FC)
print(as.data.frame(top5[, c("cluster","gene","avg_log2FC")]))

● # ============================================================
# Part 3 修正版: 亚群自动命名 + 全部组图
# ============================================================

signatures <- list(
  "Inflammatory_Fib"   = c("IL1B","IL6","CXCL1","CXCL2","CXCL3","CXCL5","CXCL8",
                           "CCL2","CCL7","CCL20","TNF","NFKB1","RELA","STAT3",
                           "S100A8","S100A9","MMP1","MMP3","MMP9","TIMP1"),
  "Myofibroblast"      = c("ACTA2","TAGLN","MYH11","CNN1","DES","MYL9","TPM1",
                           "TPM2","ACTG2","CALD1","SYNPO2"),
  "Matrix_Fib"         = c("COL1A1","COL1A2","COL3A1","COL5A1","COL6A1","COL6A2",
                           "COL6A3","COL12A1","COL14A1","DCN","LUM","BGN",
                           "FN1","FBN1","ELN","LOX","LOXL1","LOXL2"),
  "Proliferative_Fib"  = c("MKI67","TOP2A","PCNA","CCNB1","CCNB2","CDK1","BIRC5",
                           "CENPF","CENPE","AURKA","AURKB","KIF20A","KIF23",
                           "UBE2C","ASPM","TPX2","CKS1B","CKS2","HMGB2","STMN1"),
  "APC_Fib"            = c("HLA-DRA","HLA-DRB1","HLA-DQA1","HLA-DQB1","HLA-DPA1",
                           "CD74","CIITA","CTSS","CTSL","B2M"),
  "Complement_Fib"     = c("C3","C7","CFD","CFB","CFH","CFI","C1R","C1S","SERPING1",
                           "SERPINE1","CLU"),
  "Contractile_Fib"    = c("MYLK","ACTN1","FLNA","FLNC","VCL","TNS1","PXN","ZYX",
                           "TLN1","ITGA5","ITGB1","ITGB3","ITGAV","SORBS1"),
  "Senescent_Fib"      = c("CDKN1A","CDKN2A","CDKN2B","TP53","RB1","GLB1","LMNB1",
                           "IGFBP3","IGFBP5","IGFBP7","CCL11","IL1A","IL8")
)

Idents(sc_fib) <- "seurat_clusters"
avg_mat <- AverageExpression(sc_fib, assays="RNA", slot="data",
                             group.by="seurat_clusters")$RNA
colnames(avg_mat) <- gsub("^g", "", colnames(avg_mat))

score_matrix <- matrix(NA, nrow=length(signatures), ncol=ncol(avg_mat))
rownames(score_matrix) <- names(signatures)
colnames(score_matrix) <- colnames(avg_mat)

for (sn in names(signatures)) {
  genes_present <- intersect(signatures[[sn]], rownames(avg_mat))
  if (length(genes_present) > 0) {
    score_matrix[sn, ] <- colMeans(avg_mat[genes_present, , drop=FALSE])
  }
}

score_norm <- t(scale(t(score_matrix)))
score_norm[is.na(score_norm)] <- -999

best_label <- character(ncol(score_norm))
names(best_label) <- colnames(score_norm)
for (i in seq_len(ncol(score_norm))) {
  best_label[i] <- rownames(score_norm)[which.max(score_norm[, i])]
}

cat("\n========== 亚群自动命名 ==========\n")
for (cl in names(best_label)) {
  top3 <- names(sort(score_norm[, cl], decreasing=TRUE))[1:3]
  cat(sprintf("Cluster %s → %s  (top3: %s)\n",
              cl, best_label[cl], paste(top3, collapse=", ")))
}

# 写入 Seurat
sc_fib$Fib_subtype <- unname(best_label[as.character(sc_fib$seurat_clusters)])
cat("\n各亚型细胞数:\n")
print(table(sc_fib$Fib_subtype))
print(">>> Part 3 完成")

# ============================================================
# Part 4: Fig F1 — 成纤维亚群全景
# ============================================================
n_sub <- length(unique(sc_fib$Fib_subtype))
sub_colors <- setNames(brewer.pal(min(n_sub, 9), "Set1")[1:n_sub],
                       sort(unique(sc_fib$Fib_subtype)))

p1a <- DimPlot(sc_fib, reduction="umap", group.by="Fib_subtype",
               label=TRUE, repel=TRUE, pt.size=0.1, cols=sub_colors) +
  labs(title="Fibroblast Subtypes", subtitle=paste(n_sub, "subtypes")) + theme_bw()

p1b <- DimPlot(sc_fib, reduction="umap", group.by="Type", pt.size=0.08) +
  scale_color_manual(values=c("Control"="#4DBBD5","Disease"="#E64B35")) +
  facet_wrap(~Type) + labs(title="Control vs Disease") + theme_bw()

comp_df <- sc_fib@meta.data %>%
  count(Fib_subtype, Type) %>%
  group_by(Type) %>%
  mutate(pct = n / sum(n) * 100) %>%
  ungroup()

p1c <- ggplot(comp_df, aes(x=Fib_subtype, y=pct, fill=Type)) +
  geom_bar(stat="identity", position="dodge", width=0.7) +
  scale_fill_manual(values=c("Control"="#4DBBD5","Disease"="#E64B35")) +
  labs(title="Subtype Proportions", x="", y="% of Fibroblasts") +
  theme_bw() + theme(axis.text.x=element_text(angle=35, hjust=1, size=9))

p_fig1 <- (p1a | p1b) / p1c +
  plot_layout(heights=c(1, 0.7)) +
  plot_annotation(title="Fig F1: Fibroblast Subtype Landscape",
                  theme=theme(plot.title=element_text(size=15, face="bold")))
ggsave("Fibroblast_Subtypes/Fig_F1_Fibroblast_Subtypes.pdf", p_fig1, width=16, height=11)

# ============================================================
# Part 5: Fig F2 — RUNX1 在各亚群中的表达
# ============================================================
p2a <- VlnPlot(sc_fib, features="RUNX1", group.by="Fib_subtype",
               split.by="Type", pt.size=0, cols=c("#4DBBD5","#E64B35")) +
  labs(title="RUNX1 Expression by Fibroblast Subtype") +
  theme_bw() + theme(axis.text.x=element_text(angle=30, hjust=1))

p2b <- DotPlot(sc_fib, features="RUNX1", group.by="Fib_subtype",
               split.by="Type", cols=c("#4DBBD5","#E64B35")) +
  RotatedAxis() + labs(title="RUNX1 — Dot Plot") + theme_bw()

runx1_summary <- FetchData(sc_fib, c("RUNX1","Fib_subtype","Type")) %>%
  group_by(Fib_subtype, Type) %>%
  summarise(mu=mean(RUNX1), se=sd(RUNX1)/sqrt(n()), .groups="drop")

p2c <- ggplot(runx1_summary, aes(x=Fib_subtype, y=mu, fill=Type)) +
  geom_bar(stat="identity", position=position_dodge(0.8), width=0.7) +
  geom_errorbar(aes(ymin=mu-se, ymax=mu+se), position=position_dodge(0.8), width=0.2) +
  scale_fill_manual(values=c("Control"="#4DBBD5","Disease"="#E64B35")) +
  labs(title="RUNX1 Mean ±SEM", x="", y="RUNX1") +
  theme_bw() + theme(axis.text.x=element_text(angle=35, hjust=1, size=9))

p_fig2 <- (p2a / (p2b | p2c)) +
  plot_annotation(title="Fig F2: RUNX1 Expression across Fibroblast Subtypes",
                  theme=theme(plot.title=element_text(size=15, face="bold")))
ggsave("Fibroblast_Subtypes/Fig_F2_RUNX1_Subtypes.pdf", p_fig2, width=14, height=12)

# ============================================================
# Part 6: Fig F3 — 标记基因热图
# ============================================================
all_top_genes <- top10_markers %>%
  group_by(cluster) %>% top_n(n=3, wt=avg_log2FC) %>%
  pull(gene) %>% unique()

key_genes <- unique(c("RUNX1","COL1A1","COL1A2","COL3A1","DCN","LUM","FN1",
                      "ACTA2","TAGLN","MYH11","IL1B","IL6","CXCL8","CCL2",
                      "MKI67","TOP2A","PCNA","HLA-DRA","CD74","C3","CFD",
                      "PDGFRA","FAP","S100A4","VIM"))
all_genes <- intersect(unique(c(all_top_genes, key_genes)), rownames(sc_fib))

avg_fib <- AverageExpression(sc_fib, features=all_genes, group.by="Fib_subtype",
                             assays="RNA", slot="data")$RNA
avg_scaled <- t(scale(t(avg_fib)))
avg_scaled[avg_scaled > 2] <- 2
avg_scaled[avg_scaled < -2] <- -2

pdf("Fibroblast_Subtypes/Fig_F3_Marker_Heatmap.pdf", width=14, height=11)
Heatmap(avg_scaled, name="Z-score",
        col=colorRamp2(c(-2,0,2), c("steelblue","white","firebrick")),
        row_names_gp=gpar(fontsize=7),
        column_names_gp=gpar(fontsize=10, fontface="bold"),
        cluster_columns=TRUE, cluster_rows=TRUE,
        column_title="Fig F3: Fibroblast Subtype Marker Genes",
        column_title_gp=gpar(fontsize=13, fontface="bold"))
dev.off()
cat("Fig F3 done\n")

# ============================================================
# Part 7: Fig F4 — Control vs Disease 亚群偏移
# ============================================================
p4a <- ggplot(comp_df, aes(x=Fib_subtype, y=n, fill=Type)) +
  geom_bar(stat="identity", position="fill", width=0.7) +
  scale_fill_manual(values=c("Control"="#4DBBD5","Disease"="#E64B35")) +
  labs(title="Proportion Stacked", x="", y="Fraction") +
  theme_bw() + theme(axis.text.x=element_text(angle=35, hjust=1, size=9))

fc_df <- comp_df %>%
  tidyr::pivot_wider(names_from=Type, values_from=c(n, pct), id_cols=Fib_subtype)
fc_df$log2FC <- log2(fc_df$pct_Disease / fc_df$pct_Control)
fc_df <- fc_df[is.finite(fc_df$log2FC), ]

p4b <- ggplot(fc_df, aes(x=reorder(Fib_subtype, log2FC), y=log2FC, fill=log2FC)) +
  geom_bar(stat="identity") +
  scale_fill_gradient2(low="#4DBBD5", mid="white", high="#E64B35", midpoint=0) +
  coord_flip() + labs(title="Disease/Control Enrichment (log2FC)", x="", y="") +
  theme_bw() + theme(legend.position="none")

runx1_fc <- runx1_summary %>%
  tidyr::pivot_wider(names_from=Type, values_from=c(mu, se), id_cols=Fib_subtype)
runx1_fc$diff <- runx1_fc$mu_Disease - runx1_fc$mu_Control

p4c <- ggplot(runx1_fc, aes(x=reorder(Fib_subtype, diff), y=diff, fill=diff)) +
  geom_bar(stat="identity") +
  scale_fill_gradient2(low="#4DBBD5", mid="white", high="#E64B35", midpoint=0) +
  coord_flip() + labs(title="RUNX1: Disease − Control", x="", y="") +
  theme_bw() + theme(legend.position="none")

p_fig4 <- p4a / (p4b | p4c) +
  plot_annotation(title="Fig F4: Fibroblast Subtype Shift in UC",
                  theme=theme(plot.title=element_text(size=15, face="bold")))
ggsave("Fibroblast_Subtypes/Fig_F4_Subtype_Shift.pdf", p_fig4, width=14, height=12)

# ============================================================
# Part 8: 保存 & 汇总
# ============================================================
saveRDS(sc_fib, "Fibroblast_Subtypes/Fibroblast_annotated.rds")

cat("\n========================================================\n")
cat("  成纤维亚群细分 — 全部完成\n")
cat("========================================================\n")
cat("亚群细胞数:\n")
print(table(sc_fib$Fib_subtype))
cat("\n输出文件: Fibroblast_Subtypes/\n")
cat("  Fig_F1_Fibroblast_Subtypes.pdf\n")
cat("  Fig_F2_RUNX1_Subtypes.pdf\n")
cat("  Fig_F3_Marker_Heatmap.pdf\n")
cat("  Fig_F4_Subtype_Shift.pdf\n")
cat("  Fibroblast_annotated.rds\n")